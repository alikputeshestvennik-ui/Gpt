package com.blackbox.offline;

import android.content.Context;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.Locale;

/**
 * Low-latency Whisper streaming adapter.
 * Audio is supplied directly from AudioRecord; no WAV round-trip is used for
 * realtime text. A small overlapping window is decoded on a single persistent
 * Whisper context and merged into the live Entry.
 */
public final class RealtimeTranscriber {
    private static final int SAMPLE_RATE = 16000;
    private static final int WINDOW_SAMPLES = SAMPLE_RATE * 3 / 2; // 1.5 s
    private static final int STEP_SAMPLES = SAMPLE_RATE * 3 / 4;   // 0.75 s
    private static final int MAX_BUFFER_SAMPLES = SAMPLE_RATE * 3; // 3 s safety buffer

    private final Context app;
    private final BlockingQueue<float[]> latest = new ArrayBlockingQueue<>(1);
    private volatile boolean running;
    private volatile boolean busy;
    private Thread worker;
    private Entry entry;
    private float[] ring = new float[MAX_BUFFER_SAMPLES];
    private int ringWrite;
    private int ringCount;
    private int samplesSinceSubmit;
    private String accumulated = "";

    public RealtimeTranscriber(Context c) {
        app = c.getApplicationContext();
    }

    public synchronized void start(Entry e) {
        if (e == null) return;
        if (running) stop();
        entry = e;
        accumulated = e.transcript == null ? "" : e.transcript;
        ringWrite = 0;
        ringCount = 0;
        samplesSinceSubmit = 0;
        running = true;
        worker = new Thread(this::workerLoop, "blackbox-whisper-realtime");
        worker.start();
    }

    public void feed(short[] pcm, int n) {
        if (!running || pcm == null || n <= 0) return;
        synchronized (this) {
            for (int i = 0; i < n; i++) {
                ring[ringWrite] = pcm[i] / 32768.0f;
                ringWrite = (ringWrite + 1) % ring.length;
                if (ringCount < ring.length) ringCount++;
            }
            samplesSinceSubmit += n;
            if (ringCount >= WINDOW_SAMPLES && samplesSinceSubmit >= STEP_SAMPLES) {
                samplesSinceSubmit = 0;
                float[] snapshot = snapshotLocked(WINDOW_SAMPLES);
                latest.poll();
                latest.offer(snapshot);
            }
        }
    }

    private float[] snapshotLocked(int count) {
        float[] out = new float[count];
        int start = (ringWrite - count + ring.length) % ring.length;
        for (int i = 0; i < count; i++) out[i] = ring[(start + i) % ring.length];
        return out;
    }

    private void workerLoop() {
        LocalAiEngine engine = new LocalAiEngine(app);
        if (!engine.whisperReady()) {
            setStatus("Нет модели Whisper");
            running = false;
            return;
        }
        while (running || !latest.isEmpty()) {
            try {
                float[] chunk = latest.poll(250, java.util.concurrent.TimeUnit.MILLISECONDS);
                if (chunk == null) continue;
                busy = true;
                String part = engine.transcribeRealtimePcm(chunk);
                busy = false;
                if (part != null && !part.trim().isEmpty()) {
                    synchronized (this) {
                        accumulated = merge(accumulated, AutoTranscriber.cleanHallucinations(part));
                        if (entry != null) {
                            entry.transcript = accumulated.trim();
                            entry.status = "Расшифровка в реальном времени…";
                            new EntryStore(app).replace(entry);
                        }
                    }
                    broadcast();
                }
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
                break;
            } catch (Throwable ignored) {
                busy = false;
            }
        }
    }

    private void setStatus(String status) {
        synchronized (this) {
            if (entry != null) {
                entry.status = status;
                new EntryStore(app).replace(entry);
            }
        }
        broadcast();
    }

    private void broadcast() {
        app.sendBroadcast(new android.content.Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
    }

    public synchronized void stop() {
        running = false;
        latest.clear();
        Thread t = worker;
        worker = null;
        if (t != null) t.interrupt();
        entry = null;
        busy = false;
    }

    public synchronized String currentText() {
        return accumulated;
    }

    public boolean isBusy() { return busy; }

    /** Merge overlapping Whisper windows without duplicating the overlap. */
    static String merge(String oldText, String newText) {
        String a = oldText == null ? "" : oldText.trim();
        String b = newText == null ? "" : newText.trim();
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;

        String[] aw = a.split("\\s+");
        String[] bw = b.split("\\s+");
        int max = Math.min(12, Math.min(aw.length, bw.length));
        int best = 0;
        for (int n = max; n >= 1; n--) {
            boolean ok = true;
            for (int i = 0; i < n; i++) {
                if (!norm(aw[aw.length - n + i]).equals(norm(bw[i]))) { ok = false; break; }
            }
            if (ok) { best = n; break; }
        }
        if (best > 0) {
            StringBuilder sb = new StringBuilder(a);
            for (int i = best; i < bw.length; i++) sb.append(' ').append(bw[i]);
            return sb.toString().trim();
        }

        // If Whisper returns exactly the same short phrase, don't append it.
        if (norm(a).equals(norm(b))) return a;
        return (a + " " + b).trim();
    }

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT)
                .replaceAll("[.,!?;:—–-]+", " ")
                .replaceAll("\\s+", " ").trim();
    }
}
