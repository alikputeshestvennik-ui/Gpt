package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import java.io.*;
import java.text.*;
import java.util.*;

/**
 * Foreground local microphone service with:
 * - Smart Audio Gate: completely suppresses capture while phone plays media (YouTube, music, app player, ringtones)
 * - Robust Dual-Stage VAD (Energy + ZCR + Attack Confirmation)
 * - Hands-free Voice Recall: answers queries like "блэкбокс, какой код..." via instant push notification
 */
public class RecordingService extends Service {
    public static final String START = "com.blackbox.offline.START_RECORDING";
    public static final String STOP = "com.blackbox.offline.STOP_RECORDING";
    public static final String STATE = "com.blackbox.offline.RECORDING_STATE";
    public static final String ENTRIES = "com.blackbox.offline.ENTRIES";

    static final int RATE = 16000;
    static final int FRAME = 1024;
    static final long QUIET_TIMEOUT_MS = 1500;
    static final long MAX_CLIP_MS = 600000;

    private static final double MIN_VOICE_RMS = 550.0;
    private static final double NOISE_ADAPT_ALPHA = 0.05;
    private static final double VAD_SNR_RATIO = 2.4;
    private static final int MIN_CONSECUTIVE_VOICED = 3;
    private static final int PRE_ROLL_FRAMES = 4;
    private static final int ZCR_MIN = 12;
    private static final int ZCR_MAX = 200;

    public static volatile boolean isRecordingActive = false;
    public static volatile boolean isAppPlayingAudio = false;

    private double noiseFloor = 350.0;
    private AudioRecord mic;
    private Thread worker;
    private volatile boolean active;
    private volatile boolean saving;
    private ByteArrayOutputStream clip;
    private long began;
    private Entry liveEntry;
    private RealtimeTranscriber realtimeTranscriber;
    private long lastVoiceTime;

    private int totalFramesInClip = 0;
    private int voicedFramesInClip = 0;

    private final byte[][] preRoll = new byte[PRE_ROLL_FRAMES][FRAME * 2];
    private int preRollIndex = 0;
    private int preRollCount = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        // Подогрев whisper в фоне — записи расшифровываются мгновенно
        new Thread(() -> LocalAiEngine.warm(this), "blackbox-whisper-warm").start();
        realtimeTranscriber = new RealtimeTranscriber(this);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("rec", "Blackbox recording", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Автономная фоновая запись");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                nm.createNotificationChannel(ch);

                // Notification channel for instant voice recall ("Блэкбокс, напомни...")
                NotificationChannel memoryCh = new NotificationChannel("memory_recall", "Blackbox Память", NotificationManager.IMPORTANCE_HIGH);
                memoryCh.setDescription("Голосовые ответы памяти Blackbox");
                memoryCh.enableVibration(true);
                nm.createNotificationChannel(memoryCh);
            }
        }
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        String action = i == null ? "" : i.getAction();
        if (START.equals(action) && !active) start();
        if (STOP.equals(action)) stop();
        return START_NOT_STICKY;
    }

    void start() {
        try {
            Intent si = new Intent(this, RecordingService.class).setAction(STOP);
            PendingIntent pi = PendingIntent.getService(this, 1, si, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, "rec")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle("Blackbox")
                    .setContentText("Фоновое прослушивание активно · «Блэкбокс, стоп»")
                    .setOngoing(true)
                    .addAction(new Notification.Action.Builder(null, "Остановить", pi).build())
                    .build();

            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(701, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(701, n);
            }

            int b = Math.max(AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), FRAME * 4);
            mic = new AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, b);
            mic.startRecording();
            active = true;
            state(true);

            worker = new Thread(this::loop);
            worker.start();
        } catch (Exception x) {
            stop();
        }
    }

    private boolean isDevicePlayingAudio() {
        if (isAppPlayingAudio) return true;
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                if (am.isMusicActive()) return true;
                int mode = am.getMode();
                if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION) {
                    return true;
                }
            }
        } catch (Throwable ignored) {}
        return false;
    }

    void loop() {
        short[] f = new short[FRAME];
        byte[] frameBytes = new byte[FRAME * 2];
        int consecutiveVoiced = 0;

        while (active) {
            // Audio Gating: If YouTube, local player or notification is currently sounding, mute mic input
            if (isDevicePlayingAudio()) {
                if (saving) {
                    abortCurrentClip();
                }
                consecutiveVoiced = 0;
                try { Thread.sleep(80); } catch (InterruptedException ignored) {}
                continue;
            }

            int n = mic != null ? mic.read(f, 0, FRAME) : -1;
            if (n <= 0) continue;

            long sumSq = 0;
            int zcr = 0;
            for (int i = 0; i < n; i++) {
                short val = f[i];
                sumSq += (long) val * val;
                frameBytes[i * 2] = (byte) (val & 255);
                frameBytes[i * 2 + 1] = (byte) ((val >> 8) & 255);
                if (i > 0 && ((f[i] >= 0 && f[i - 1] < 0) || (f[i] < 0 && f[i - 1] >= 0))) {
                    zcr++;
                }
            }

            double currentRms = Math.sqrt(sumSq / (double) n);

            if (!saving && currentRms < noiseFloor * 1.5) {
                noiseFloor = (1.0 - NOISE_ADAPT_ALPHA) * noiseFloor + NOISE_ADAPT_ALPHA * currentRms;
                if (noiseFloor < 120.0) noiseFloor = 120.0;
            }

            double requiredThreshold = Math.max(MIN_VOICE_RMS, noiseFloor * VAD_SNR_RATIO);
            boolean isVoiced = (currentRms >= requiredThreshold) && (zcr >= ZCR_MIN && zcr <= ZCR_MAX);

            long now = System.currentTimeMillis();

            if (!saving) {
                System.arraycopy(frameBytes, 0, preRoll[preRollIndex], 0, frameBytes.length);
                preRollIndex = (preRollIndex + 1) % PRE_ROLL_FRAMES;
                if (preRollCount < PRE_ROLL_FRAMES) preRollCount++;

                if (isVoiced) {
                    consecutiveVoiced++;
                    if (consecutiveVoiced >= MIN_CONSECUTIVE_VOICED) {
                        saving = true;
                        clip = new ByteArrayOutputStream();
                        began = lastVoiceTime = now;
                        totalFramesInClip = 0;
                        voicedFramesInClip = consecutiveVoiced;

                        String id = UUID.randomUUID().toString();
                        String timeStr = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
                        liveEntry = new Entry(id, "", timeStr, 0, "", "", "Заметки");
                        liveEntry.status = "Расшифровка в реальном времени…";
                        new EntryStore(this).add(liveEntry);
                        if (realtimeTranscriber != null) realtimeTranscriber.start(liveEntry);

                        int startIdx = (preRollIndex - preRollCount + PRE_ROLL_FRAMES) % PRE_ROLL_FRAMES;
                        for (int i = 0; i < preRollCount; i++) {
                            int idx = (startIdx + i) % PRE_ROLL_FRAMES;
                            clip.write(preRoll[idx], 0, preRoll[idx].length);
                            totalFramesInClip++;
                        }
                        // Feed the pre-roll immediately so the first words are not lost.
                        if (realtimeTranscriber != null) {
                            short[] pre = new short[FRAME];
                            for (int i = 0; i < preRollCount; i++) {
                                int idx = (startIdx + i) % PRE_ROLL_FRAMES;
                                byte[] b = preRoll[idx];
                                for (int j = 0; j < FRAME; j++) pre[j] = (short)((b[j*2] & 255) | (b[j*2+1] << 8));
                                realtimeTranscriber.feed(pre, FRAME);
                            }
                        }
                        sendBroadcast(new Intent(ENTRIES).setPackage(getPackageName()));
                    }
                } else {
                    consecutiveVoiced = 0;
                }
            } else {
                totalFramesInClip++;
                if (isVoiced) {
                    voicedFramesInClip++;
                    lastVoiceTime = now;
                }

                clip.write(frameBytes, 0, frameBytes.length);
                if (realtimeTranscriber != null) realtimeTranscriber.feed(f, n);

                if (totalFramesInClip >= 19 && voicedFramesInClip < 4) {
                    abortCurrentClip();
                    consecutiveVoiced = 0;
                    continue;
                }

                if (now - lastVoiceTime >= QUIET_TIMEOUT_MS || now - began >= MAX_CLIP_MS) {
                    close();
                    consecutiveVoiced = 0;
                }
            }
        }
    }

    private synchronized void abortCurrentClip() {
        saving = false;
        if (realtimeTranscriber != null) realtimeTranscriber.stop();
        if (liveEntry != null) {
            try { new EntryStore(this).delete(liveEntry.id); } catch (Exception ignored) {}
            liveEntry = null;
        }
        clip = null;
        sendBroadcast(new Intent(ENTRIES).setPackage(getPackageName()));
    }

    synchronized void close() {
        if (!saving || clip == null) return;
        saving = false;
        if (realtimeTranscriber != null) realtimeTranscriber.stop();
        try {
            byte[] p = clip.toByteArray();
            clip = null;

            if (p.length < (int) (RATE * 1.5) || voicedFramesInClip < 8) {
                if (liveEntry != null) new EntryStore(this).delete(liveEntry.id);
                liveEntry = null;
                sendBroadcast(new Intent(ENTRIES).setPackage(getPackageName()));
                return;
            }

            File d = new File(getExternalFilesDir(null), "audio");
            d.mkdirs();
            String id = liveEntry != null ? liveEntry.id : UUID.randomUUID().toString();
            File out = new File(d, id + ".wav");
            wav(out, p);

            if (!out.isFile() || out.length() < 44 + p.length) {
                out.delete();
                if (liveEntry != null) new EntryStore(this).delete(liveEntry.id);
                liveEntry = null;
                sendBroadcast(new Intent(ENTRIES).setPackage(getPackageName()));
                return;
            }

            long durationSec = Math.max(1, p.length / (RATE * 2));
            Entry e = liveEntry;
            if (e == null) {
                String timeStr = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
                e = new Entry(id, out.getPath(), timeStr, durationSec, "", "", "Заметки");
                new EntryStore(this).add(e);
            } else {
                e.path = out.getPath();
                e.duration = durationSec;
                e.status = (e.transcript != null && !e.transcript.trim().isEmpty())
                        ? "Финальная проверка…" : "Расшифровка…";
                new EntryStore(this).replace(e);
            }
            liveEntry = null;
            AutoTranscriber.enqueue(this, e);
            sendBroadcast(new Intent(ENTRIES).setPackage(getPackageName()));
        } catch (Exception ignored) {
            if (liveEntry != null) {
                try { liveEntry.status = "Ошибка сохранения записи"; new EntryStore(this).replace(liveEntry); } catch (Exception ignored2) {}
            }
            liveEntry = null;
            sendBroadcast(new Intent(ENTRIES).setPackage(getPackageName()));
        }
    }

    void wav(File f, byte[] p) throws Exception {
        try (FileOutputStream o = new FileOutputStream(f)) {
            o.write("RIFF".getBytes());
            le(o, 36 + p.length);
            o.write("WAVEfmt ".getBytes());
            le(o, 16);
            o.write(new byte[]{1, 0, 1, 0});
            le(o, RATE);
            le(o, RATE * 2);
            o.write(new byte[]{2, 0, 16, 0});
            o.write("data".getBytes());
            le(o, p.length);
            o.write(p);
            o.flush();
        }
    }

    void le(OutputStream o, int n) throws Exception {
        o.write(n);
        o.write(n >> 8);
        o.write(n >> 16);
        o.write(n >> 24);
    }

    void stop() {
        if (active && saving) close();
        active = false;
        if (realtimeTranscriber != null) realtimeTranscriber.stop();
        state(false);
        try {
            if (mic != null) {
                mic.stop();
                mic.release();
                mic = null;
            }
        } catch (Exception ignored) {}
        stopForeground(true);
        stopSelf();
    }

    void state(boolean x) {
        isRecordingActive = x;
        AutoTranscriber.notifyRecordingStateChanged();
        sendBroadcast(new Intent(STATE).setPackage(getPackageName()).putExtra("active", x));
        try {
            BlackboxWidgetProvider.updateAllWidgets(this, x);
            BlackboxSquareWidgetProvider.updateAllSquareWidgets(this, x);
        } catch (Throwable ignored) {}
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onDestroy() {
        if (active) stop();
        super.onDestroy();
    }
}
