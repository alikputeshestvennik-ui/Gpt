package com.blackbox.offline;

import android.content.Context;
import android.net.Uri;
import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Copies user-selected offline model files into app-private storage. No network access. */
public final class ModelManager {
    public static final String WHISPER = "whisper.bin";
    public static final String LLM = "qwen.gguf";
    public static final String SOUNDS = "sound-classifier.tflite";
    public static final String VOSK_DIR = "vosk-model";

    private ModelManager() {}

    public static File folder(Context c) {
        File f = new File(c.getExternalFilesDir(null), "models");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    public static File file(Context c, String name) {
        return new File(folder(c), name);
    }

    public static boolean installed(Context c, String name) {
        return file(c, name).isFile() && file(c, name).length() > 1024;
    }

    public static File voskDir(Context c) {
        return new File(folder(c), VOSK_DIR);
    }

    /** Vosk model is a directory with conf/model.conf (or am/final.mdl). */
    public static boolean voskInstalled(Context c) {
        File dir = voskDir(c);
        if (!dir.isDirectory()) return false;
        if (new File(dir, "conf/model.conf").isFile()) return true;
        if (new File(dir, "am/final.mdl").isFile()) return true;
        // Sometimes zip extracts with a single top-level folder
        File[] kids = dir.listFiles();
        if (kids != null && kids.length == 1 && kids[0].isDirectory()) {
            if (new File(kids[0], "conf/model.conf").isFile()) return true;
            if (new File(kids[0], "am/final.mdl").isFile()) return true;
        }
        return false;
    }

    /** Resolve actual model root (handles one extra nesting level from zip). */
    public static File voskModelRoot(Context c) {
        File dir = voskDir(c);
        if (new File(dir, "conf/model.conf").isFile() || new File(dir, "am/final.mdl").isFile()) {
            return dir;
        }
        File[] kids = dir.listFiles();
        if (kids != null && kids.length == 1 && kids[0].isDirectory()) {
            File nested = kids[0];
            if (new File(nested, "conf/model.conf").isFile() || new File(nested, "am/final.mdl").isFile()) {
                return nested;
            }
        }
        return dir;
    }

    public static void importFile(Context c, Uri uri, String destination) throws IOException {
        File out = file(c, destination);
        File temp = new File(out.getAbsolutePath() + ".part");
        try (InputStream in = c.getContentResolver().openInputStream(uri);
             OutputStream os = new FileOutputStream(temp)) {
            if (in == null) throw new IOException("Файл недоступен");
            byte[] b = new byte[1024 * 128];
            int n;
            while ((n = in.read(b)) != -1) os.write(b, 0, n);
        }
        if (out.exists()) out.delete();
        if (!temp.renameTo(out)) throw new IOException("Не удалось сохранить файл");
    }

    /** Import Vosk model from a .zip (official vosk-model-*-ru packs). */
    public static void importVoskZip(Context c, Uri uri) throws IOException {
        File dest = voskDir(c);
        if (dest.exists()) deleteRecursive(dest);
        dest.mkdirs();
        File tempRoot = new File(folder(c), "vosk-model.part");
        if (tempRoot.exists()) deleteRecursive(tempRoot);
        tempRoot.mkdirs();
        try (InputStream in = c.getContentResolver().openInputStream(uri);
             ZipInputStream zis = new ZipInputStream(new BufferedInputStream(in))) {
            if (in == null) throw new IOException("Файл недоступен");
            ZipEntry entry;
            byte[] buf = new byte[1024 * 128];
            while ((entry = zis.getNextEntry()) != null) {
                String name = entry.getName();
                if (name == null || name.contains("..")) continue;
                File out = new File(tempRoot, name);
                if (entry.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                try (OutputStream os = new FileOutputStream(out)) {
                    int n;
                    while ((n = zis.read(buf)) != -1) os.write(buf, 0, n);
                }
            }
        }
        if (dest.exists()) deleteRecursive(dest);
        if (!tempRoot.renameTo(dest)) {
            // fallback copy
            copyRecursive(tempRoot, dest);
            deleteRecursive(tempRoot);
        }
        if (!voskInstalled(c)) {
            throw new IOException("В архиве не найдена модель Vosk (conf/model.conf)");
        }
    }

    public static String size(Context c, String name) {
        File f = file(c, name);
        if (!f.exists()) return "не установлена";
        return String.format(java.util.Locale.getDefault(), "установлена · %.1f МБ", f.length() / 1048576.0);
    }

    public static String voskSize(Context c) {
        if (!voskInstalled(c)) return "не установлена";
        long bytes = dirSize(voskDir(c));
        return String.format(java.util.Locale.getDefault(), "установлена · %.1f МБ", bytes / 1048576.0);
    }

    private static long dirSize(File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long s = 0;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) s += dirSize(k);
        return s;
    }

    private static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursive(k);
        }
        f.delete();
    }

    private static void copyRecursive(File src, File dst) throws IOException {
        if (src.isDirectory()) {
            dst.mkdirs();
            File[] kids = src.listFiles();
            if (kids != null) {
                for (File k : kids) copyRecursive(k, new File(dst, k.getName()));
            }
        } else {
            File parent = dst.getParentFile();
            if (parent != null) parent.mkdirs();
            try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
                byte[] b = new byte[1024 * 64];
                int n;
                while ((n = in.read(b)) != -1) out.write(b, 0, n);
            }
        }
    }
}
