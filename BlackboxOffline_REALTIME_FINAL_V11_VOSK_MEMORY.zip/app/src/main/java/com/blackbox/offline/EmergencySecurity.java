package com.blackbox.offline;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.util.Locale;

/**
 * Emergency privacy controls for Blackbox.
 * The emergency action is intentionally local: stop capture, remove app-owned
 * journal/audio/realtime/model data and terminate the process. It does not
 * attempt to erase unrelated device data.
 */
public final class EmergencySecurity {
    private static final String PREFS = "blackbox_security";
    private static final String KEY_PHRASE = "emergency_phrase";
    private static final String KEY_ENABLED = "emergency_enabled";
    public static final String DEFAULT_PHRASE = "блэкбокс тревога";

    private EmergencySecurity() {}

    public static String getPhrase(Context c) {
        SharedPreferences p = c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String value = p.getString(KEY_PHRASE, DEFAULT_PHRASE);
        if (value == null || value.trim().length() < 6) return DEFAULT_PHRASE;
        return value.trim();
    }

    public static void setPhrase(Context c, String phrase) {
        String normalized = AutoTranscriber.squashForCommandMatch(phrase == null ? "" : phrase.trim());
        if (normalized.length() < 6) throw new IllegalArgumentException("Секретная фраза слишком короткая");
        c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_PHRASE, normalized).apply();
    }

    public static boolean isEnabled(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, true);
    }

    public static void setEnabled(Context c, boolean enabled) {
        c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    /** Strict matching: custom phrase must match the complete normalized utterance. */
    public static boolean matches(Context c, String text) {
        if (c == null || !isEnabled(c) || text == null) return false;
        String actual = AutoTranscriber.squashForCommandMatch(text).toLowerCase(Locale.ROOT).trim();
        String expected = AutoTranscriber.squashForCommandMatch(getPhrase(c)).toLowerCase(Locale.ROOT).trim();
        if (actual.isEmpty() || expected.isEmpty()) return false;
        if (actual.equals(expected)) return true;
        // Allow harmless ASR punctuation/filler around the secret, but never a bare "тревога".
        return actual.startsWith(expected + " ") || actual.endsWith(" " + expected);
    }

    /**
     * Best-effort wipe of Blackbox-owned local data. Android flash storage cannot
     * be reliably secure-erased by overwriting; the important protection is to
     * remove every local copy and its app-private access state.
     */
    public static void wipe(Context c) {
        Context app = c.getApplicationContext();

        // Clear structured diary state first.
        try { new EntryStore(app).save(new java.util.ArrayList<>()); } catch (Throwable ignored) {}
        try { RealtimeRingStore.clear(app); } catch (Throwable ignored) {}

        // Close shared Vosk model before removing its files.
        try { VoskEngine.releaseSharedModel(); } catch (Throwable ignored) {}

        // App-private files/cache/databases and app-specific external storage.
        try { deleteChildren(app.getFilesDir()); } catch (Throwable ignored) {}
        try { deleteChildren(app.getCacheDir()); } catch (Throwable ignored) {}
        try { deleteChildren(app.getDatabasePath("dummy").getParentFile()); } catch (Throwable ignored) {}
        try {
            File ext = app.getExternalFilesDir(null);
            if (ext != null) deleteChildren(ext);
        } catch (Throwable ignored) {}
        try {
            File extCache = app.getExternalCacheDir();
            if (extCache != null) deleteChildren(extCache);
        } catch (Throwable ignored) {}

        // Blackbox's public Downloads exports, where supported. Only files with
        // our exact export prefix are targeted.
        try { deletePublicExports(app); } catch (Throwable ignored) {}
    }

    private static void deleteChildren(File dir) {
        if (dir == null || !dir.exists()) return;
        File[] children = dir.listFiles();
        if (children != null) for (File f : children) deleteRecursive(f);
    }

    private static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File child : children) deleteRecursive(child);
        }
        try { f.delete(); } catch (Throwable ignored) {}
    }

    private static void deletePublicExports(Context c) {
        if (Build.VERSION.SDK_INT >= 29) {
            String[] projection = { MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME };
            String selection = MediaStore.Downloads.DISPLAY_NAME + " LIKE ?";
            String[] args = { "Blackbox_Journal_%" };
            try (android.database.Cursor cur = c.getContentResolver().query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection, args, null)) {
                if (cur != null) {
                    int idCol = cur.getColumnIndexOrThrow(MediaStore.Downloads._ID);
                    while (cur.moveToNext()) {
                        long id = cur.getLong(idCol);
                        Uri uri = Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI, Long.toString(id));
                        try { c.getContentResolver().delete(uri, null, null); } catch (Throwable ignored) {}
                    }
                }
            }
        } else {
            File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (downloads == null) return;
            File[] files = downloads.listFiles();
            if (files != null) {
                for (File f : files) {
                    if (f.isFile() && f.getName().startsWith("Blackbox_Journal_")) {
                        try { f.delete(); } catch (Throwable ignored) {}
                    }
                }
            }
        }
    }
}
