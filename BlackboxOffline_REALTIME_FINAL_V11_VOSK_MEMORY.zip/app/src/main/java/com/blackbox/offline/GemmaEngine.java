package com.blackbox.offline;

import android.content.Context;
import android.os.Build;

import com.google.ai.edge.litertlm.Backend;
import com.google.ai.edge.litertlm.Conversation;
import com.google.ai.edge.litertlm.ConversationConfig;
import com.google.ai.edge.litertlm.Engine;
import com.google.ai.edge.litertlm.EngineConfig;
import com.google.ai.edge.litertlm.ThinkingConfig;

import java.io.File;
import java.util.Locale;

/**
 * Blackbox local Gemma core. No network API and no Qwen fallback.
 * Uses LiteRT-LM; GPU is preferred, CPU is the safe fallback.
 */
public final class GemmaEngine {
    private static final Object LOCK = new Object();
    private static volatile Engine engine;
    private static volatile String backendName = "не запущен";
    private static volatile String lastError = "";

    private GemmaEngine() {}

    public static boolean modelPresent(Context c) {
        return ModelManager.installed(c, ModelManager.GEMMA);
    }

    public static String modelSize(Context c) {
        return ModelManager.size(c, ModelManager.GEMMA);
    }

    public static String backendName() { return backendName; }
    public static String lastError() { return lastError; }

    /** Initialize the persistent local engine. GPU first, CPU fallback. */
    public static boolean warm(Context c) {
        if (!modelPresent(c)) return false;
        synchronized (LOCK) {
            if (engine != null && engine.isInitialized()) return true;
            Context app = c.getApplicationContext();
            File model = ModelManager.file(app, ModelManager.GEMMA);

            try {
                Engine gpu = new Engine(new EngineConfig(
                        model.getAbsolutePath(),
                        new Backend.GPU()
                ));
                gpu.initialize();
                engine = gpu;
                backendName = "GPU";
                lastError = "";
                return true;
            } catch (Throwable gpuError) {
                lastError = shortError(gpuError);
                try {
                    Engine cpu = new Engine(new EngineConfig(
                            model.getAbsolutePath(),
                            new Backend.CPU()
                    ));
                    cpu.initialize();
                    engine = cpu;
                    backendName = "CPU · fallback";
                    return true;
                } catch (Throwable cpuError) {
                    lastError = shortError(cpuError);
                    backendName = "ошибка";
                    return false;
                }
            }
        }
    }

    public static boolean ready(Context c) {
        return modelPresent(c) && engine != null && engine.isInitialized();
    }

    public static String generate(Context c, String prompt, int maxTokens) {
        if (prompt == null || prompt.trim().isEmpty()) return "";
        if (!warm(c)) return "";
        synchronized (LOCK) {
            if (engine == null || !engine.isInitialized()) return "";
            Conversation conversation = null;
            try {
                ConversationConfig config = new ConversationConfig();
                conversation = engine.createConversation(config);
                com.google.ai.edge.litertlm.Message response = conversation.sendMessage(
                        prompt, java.util.Collections.emptyMap(), null, null, null,
                        maxTokens, new ThinkingConfig(false, 0), null);
                String text = response == null ? "" : response.toString();
                return text == null ? "" : text.trim();
            } catch (Throwable t) {
                lastError = shortError(t);
                return "";
            } finally {
                if (conversation != null) {
                    try { conversation.close(); } catch (Throwable ignored) {}
                }
            }
        }
    }

    /** Actual backend probe used by Diagnostics. Does not run on app startup. */
    public static String probeBackend(Context c, String backend) {
        if (!modelPresent(c)) return "Модель Gemma не установлена";
        File model = ModelManager.file(c, ModelManager.GEMMA);
        try {
            Engine test;
            if ("GPU".equalsIgnoreCase(backend)) {
                test = new Engine(new EngineConfig(model.getAbsolutePath(), new Backend.GPU()));
            } else if ("CPU".equalsIgnoreCase(backend)) {
                test = new Engine(new EngineConfig(model.getAbsolutePath(), new Backend.CPU()));
            } else {
                return "NPU: публичный Samsung System LSI delegate для LiteRT сейчас не заявлен; не запускаем рискованный probe.";
            }
            long t0 = System.currentTimeMillis();
            test.initialize();
            long ms = System.currentTimeMillis() - t0;
            test.close();
            return "Доступен · инициализация " + ms + " мс";
        } catch (Throwable t) {
            return "Недоступен · " + shortError(t);
        }
    }

    public static String deviceInfo() {
        return Build.MANUFACTURER + " " + Build.MODEL + " · Android " + Build.VERSION.RELEASE;
    }

    private static String shortError(Throwable t) {
        Throwable x = t;
        while (x.getCause() != null && x.getCause() != x) x = x.getCause();
        String msg = x.getMessage();
        if (msg == null || msg.trim().isEmpty()) msg = x.getClass().getSimpleName();
        return msg.replace('\n', ' ').trim();
    }

    public static void shutdown() {
        synchronized (LOCK) {
            if (engine != null) {
                try { engine.close(); } catch (Throwable ignored) {}
                engine = null;
            }
            backendName = "не запущен";
        }
    }
}
