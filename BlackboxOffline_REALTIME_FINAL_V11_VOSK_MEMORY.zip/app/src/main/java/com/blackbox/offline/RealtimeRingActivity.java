package com.blackbox.offline;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.*;
import java.util.ArrayList;

/** 15-minute realtime ring viewer. Opened by tapping live text on Home. */
public class RealtimeRingActivity extends Activity {
    private LinearLayout list;
    private View panel;
    private TextView empty;
    private boolean receiverRegistered;

    // Экран должен обновляться сам, пока открыт — раньше ждал только onResume,
    // поэтому фразы не появлялись, пока вы не выходили и не заходили заново.
    private final BroadcastReceiver liveReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            reload();
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        overridePendingTransition(0, 0);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xCC000000);
        root.setOnClickListener(v -> finishWithAnim());

        panel = new LinearLayout(this);
        ((LinearLayout) panel).setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xFF0C0E12);
        int pad = dp(18);
        panel.setPadding(pad, pad, pad, pad);
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(-1, -1);
        plp.topMargin = dp(48);
        plp.bottomMargin = dp(24);
        plp.leftMargin = dp(12);
        plp.rightMargin = dp(12);
        root.addView(panel, plp);
        panel.setOnClickListener(v -> { /* swallow */ });

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1f);
        header.addView(titles, tlp);

        TextView title = new TextView(this);
        title.setText("Realtime · 15 минут");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        titles.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Живая лента Vosk. Старее 15 минут удаляется по часам.");
        sub.setTextColor(0xFF8E95A2);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        sub.setPadding(0, dp(4), 0, 0);
        titles.addView(sub);

        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextColor(0xFFB8C0CC);
        close.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        close.setPadding(dp(12), dp(4), dp(4), dp(4));
        close.setOnClickListener(v -> finishWithAnim());
        header.addView(close);

        ((LinearLayout) panel).addView(header);

        TextView clearBtn = new TextView(this);
        clearBtn.setText("Очистить кольцо");
        clearBtn.setTextColor(0xFFFFA25F);
        clearBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        clearBtn.setPadding(0, dp(14), 0, dp(10));
        clearBtn.setOnClickListener(v -> {
            RealtimeRingStore.clear(this);
            reload();
        });
        ((LinearLayout) panel).addView(clearBtn);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);
        ((LinearLayout) panel).addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        empty = new TextView(this);
        empty.setText("Пока пусто.\nГоворите при активной записи — фразы появятся здесь.");
        empty.setTextColor(0xFF5D6574);
        empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(0, dp(40), 0, 0);
        list.addView(empty);

        setContentView(root);

        // Enter animation
        panel.setAlpha(0f);
        panel.setTranslationY(dp(64));
        panel.animate()
                .alpha(1f)
                .translationY(0)
                .setDuration(320)
                .setInterpolator(new DecelerateInterpolator(1.4f))
                .start();

        reload();
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
        if (!receiverRegistered) {
            IntentFilter filter = new IntentFilter(RealtimeTranscriber.LIVE_TEXT);
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(liveReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(liveReceiver, filter);
            }
            receiverRegistered = true;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (receiverRegistered) {
            try { unregisterReceiver(liveReceiver); } catch (Throwable ignored) {}
            receiverRegistered = false;
        }
    }

    private ArrayList<RealtimeRingStore.Item> lastItems = new ArrayList<>();
    private TextView topTextView;
    private TextView topTimeView;

    private void reload() {
        ArrayList<RealtimeRingStore.Item> items = RealtimeRingStore.snapshot(this);

        // Пока идёт одна и та же (растущая) фраза, размер списка не меняется —
        // RealtimeRingStore подменяет последнюю запись, а не добавляет новую.
        // В этом случае просто обновляем текст верхней карточки на месте, без
        // пересборки всего списка и без анимаций — раньше именно полная
        // пересборка на каждый partial-апдейт вызывала дрожание ленты, пока
        // фраза не закончится.
        if (topTextView != null && !items.isEmpty() && items.size() == lastItems.size()) {
            RealtimeRingStore.Item top = items.get(items.size() - 1);
            topTextView.setText(top.text);
            topTimeView.setText(top.timeLabel());
            lastItems = items;
            return;
        }

        list.removeAllViews();
        lastItems = items;
        topTextView = null;
        topTimeView = null;
        if (items.isEmpty()) {
            list.addView(empty);
            return;
        }
        // Newest first
        for (int i = items.size() - 1; i >= 0; i--) {
            RealtimeRingStore.Item it = items.get(i);
            LinearLayout card = UI.createCard(this);

            TextView time = UI.badge(this, it.timeLabel(), 0xFFFFA25F, 0xFF221710);
            card.addView(time);

            TextView tv = new TextView(this);
            tv.setText(it.text);
            tv.setTextColor(0xFFF1F3F7);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            tv.setLineSpacing(dp(3), 1.05f);
            tv.setPadding(0, dp(10), 0, 0);
            card.addView(tv);

            if (i == items.size() - 1) {
                topTextView = tv;
                topTimeView = time;
            }

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(10);
            list.addView(card, lp);

            // Stagger fade-in
            card.setAlpha(0f);
            card.setTranslationY(dp(12));
            card.animate().alpha(1f).translationY(0).setStartDelay((items.size() - 1 - i) * 30L)
                    .setDuration(220).start();
        }
    }

    private void finishWithAnim() {
        if (panel == null) {
            finish();
            return;
        }
        panel.animate()
                .alpha(0f)
                .translationY(dp(48))
                .setDuration(200)
                .withEndAction(() -> {
                    finish();
                    overridePendingTransition(0, 0);
                })
                .start();
    }

    @Override
    public void onBackPressed() {
        finishWithAnim();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
