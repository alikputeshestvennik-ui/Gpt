package com.blackbox.offline;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Typeface;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.vosk.Model;
import org.vosk.Recognizer;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Arrays;

/**
 * Самодиагностика Vosk без adb/logcat: показывает дерево файлов модели,
 * пытается создать Model+Recognizer напрямую и прогоняет 3 секунды живого
 * микрофона через распознаватель, выводя сырой JSON-ответ на экран.
 * Результат можно скопировать одной кнопкой и переслать для разбора.
 */
public final class VoskDiagnostics {
    private VoskDiagnostics() {}

    public static void run(Activity activity) {
        AlertDialog progress = new AlertDialog.Builder(activity)
                .setTitle("Диагностика Vosk")
                .setMessage("Собираю информацию. После сигнала-диалога говорите что-нибудь в микрофон 3 секунды...")
                .setCancelable(false)
                .create();
        progress.show();

        new Thread(() -> {
            StringBuilder sb = new StringBuilder();

            sb.append("=== 1. Файлы модели ===\n");
            File dir = ModelManager.voskDir(activity);
            sb.append("Путь хранения: ").append(dir.getAbsolutePath()).append("\n");
            appendTree(sb, dir, 0);
            File root = ModelManager.voskModelRoot(activity);
            sb.append("\nОпределённый корень модели: ").append(root.getAbsolutePath()).append("\n");
            sb.append("voskInstalled(): ").append(ModelManager.voskInstalled(activity)).append("\n\n");

            sb.append("=== 2. Загрузка модели ===\n");
            Model model = null;
            Recognizer rec = null;
            try {
                model = new Model(root.getAbsolutePath());
                sb.append("Model() — OK\n");
                rec = new Recognizer(model, 16000.0f);
                sb.append("Recognizer() — OK\n\n");
            } catch (Throwable t) {
                sb.append("ОШИБКА: ").append(t).append("\n");
                StringWriter sw = new StringWriter();
                t.printStackTrace(new PrintWriter(sw));
                sb.append(sw).append("\n\n");
            }

            if (rec != null) {
                sb.append("=== 3. Тест на живом микрофоне (3 сек) ===\n");
                try {
                    if (activity.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                            != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        sb.append("Нет разрешения RECORD_AUDIO — пропускаю запись.\n");
                    } else {
                        int rate = 16000;
                        int minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                        AudioRecord ar = new AudioRecord(MediaRecorder.AudioSource.MIC, rate,
                                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(minBuf, 4096));
                        ar.startRecording();
                        short[] buf = new short[1024];
                        long end = System.currentTimeMillis() + 3000;
                        long maxAbs = 0;
                        int chunks = 0;
                        while (System.currentTimeMillis() < end) {
                            int n = ar.read(buf, 0, buf.length);
                            if (n > 0) {
                                chunks++;
                                for (int i = 0; i < n; i++) {
                                    int a = Math.abs((int) buf[i]);
                                    if (a > maxAbs) maxAbs = a;
                                }
                                byte[] bytes = new byte[n * 2];
                                for (int i = 0; i < n; i++) {
                                    bytes[i * 2] = (byte) (buf[i] & 0xff);
                                    bytes[i * 2 + 1] = (byte) ((buf[i] >> 8) & 0xff);
                                }
                                rec.acceptWaveForm(bytes, bytes.length);
                            }
                        }
                        ar.stop();
                        ar.release();
                        String finalJson = rec.getFinalResult();
                        sb.append("Прочитано чанков: ").append(chunks)
                          .append(", макс. амплитуда сэмпла: ").append(maxAbs).append(" (из 32767)\n");
                        sb.append("Сырой JSON результата Vosk:\n").append(finalJson).append("\n");
                    }
                } catch (Throwable t) {
                    sb.append("ОШИБКА записи/распознавания: ").append(t).append("\n");
                }
            }

            try { if (rec != null) rec.close(); } catch (Throwable ignored) {}
            try { if (model != null) model.close(); } catch (Throwable ignored) {}

            String report = sb.toString();
            new Handler(Looper.getMainLooper()).post(() -> {
                progress.dismiss();
                showReport(activity, report);
            });
        }, "blackbox-vosk-diagnostic").start();
    }

    private static void appendTree(StringBuilder sb, File f, int depth) {
        if (f == null) return;
        String indent = repeat("  ", depth);
        if (!f.exists()) {
            sb.append(indent).append(f.getName()).append(" [не существует]\n");
            return;
        }
        if (f.isDirectory()) {
            sb.append(indent).append(f.getName()).append("/\n");
            File[] kids = f.listFiles();
            if (kids != null) {
                Arrays.sort(kids, (a, b) -> a.getName().compareTo(b.getName()));
                for (File k : kids) appendTree(sb, k, depth + 1);
            }
        } else {
            sb.append(indent).append(f.getName()).append(" (").append(f.length()).append(" байт)\n");
        }
    }

    private static String repeat(String s, int n) {
        StringBuilder r = new StringBuilder();
        for (int i = 0; i < n; i++) r.append(s);
        return r.toString();
    }

    private static void showReport(Activity activity, String report) {
        TextView tv = new TextView(activity);
        tv.setText(report);
        tv.setTextIsSelectable(true);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        int pad = (int) (12 * activity.getResources().getDisplayMetrics().density);
        tv.setPadding(pad, pad, pad, pad);
        ScrollView scroll = new ScrollView(activity);
        scroll.addView(tv);

        new AlertDialog.Builder(activity)
                .setTitle("Отчёт диагностики Vosk")
                .setView(scroll)
                .setPositiveButton("Копировать всё", (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("vosk-report", report));
                    Toast.makeText(activity, "Скопировано в буфер обмена", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Закрыть", null)
                .show();
    }
}
