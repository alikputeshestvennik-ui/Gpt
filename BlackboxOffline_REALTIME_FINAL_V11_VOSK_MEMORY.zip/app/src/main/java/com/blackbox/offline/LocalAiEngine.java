package com.blackbox.offline;

import android.content.Context;
import java.io.File;

/**
 * Fully local Whisper + AI Core (Gemini Nano style on-device LLM) bridge.
 * Application has NO android.permission.INTERNET.
 */
public class LocalAiEngine {
    private final Context app;
    private final QwenEngine qwenEngine;
    private static volatile boolean whisperLoaded = false;
    private static volatile boolean attempted = false;
    private static final Object WARM_LOCK = new Object();
    private static volatile boolean warmed = false;

    /** System prompt for post-ASR editing via AI Core / Gemini Nano. */
    public static final String EDITOR_PROMPT =
            "Ты профессиональный редактор. Твоя задача — взять расшифровку устной речи, "
            + "исправить ошибки ASR-распознавания, убрать слова-паразиты, сгладить заикания "
            + "и оформить текст в читаемый вид с правильной пунктуацией, сохраняя исходный смысл. "
            + "Выдавай только готовый текст без пояснений.";

    public LocalAiEngine(Context c) {
        this.app = c.getApplicationContext();
        this.qwenEngine = new QwenEngine(app);
    }

    private static synchronized void ensureNative() {
        if (!attempted) {
            attempted = true;
            try {
                System.loadLibrary("blackbox_ai");
                whisperLoaded = true;
            } catch (Throwable t) {
                whisperLoaded = false;
            }
        }
    }

    public boolean whisperReady() {
        ensureNative();
        return whisperLoaded && ModelManager.installed(app, ModelManager.WHISPER);
    }

    public boolean qwenReady() {
        return qwenEngine.isModelPresent();
    }

    public boolean ready() {
        return whisperReady();
    }

    public boolean aiCoreReady() {
        return LlmEngine.available() && ModelManager.installed(app, ModelManager.LLM);
    }

        private static native boolean nativeWarm(String modelPath);

    /** Подогрев: загружает whisper-контекст заранее, чтобы первая расшифровка
     *  после старта приложения была мгновенной. Безопасно вызывать в фоне. */
    public static boolean warm(Context c) {
        try {
            Context app = c.getApplicationContext();
            ensureNative();
            if (!whisperLoaded || !ModelManager.installed(app, ModelManager.WHISPER)) return false;
            if (warmed) return true;
            synchronized (WARM_LOCK) {
                if (warmed) return true;
                boolean ok = nativeWarm(ModelManager.file(app, ModelManager.WHISPER).getAbsolutePath());
                if (ok) warmed = true;
                return ok;
            }
        } catch (Throwable t) {
            return false;
        }
    }

public String transcribe(String path) throws Exception {
        if (!ModelManager.installed(app, ModelManager.WHISPER)) {
            throw new IllegalStateException("Импортируйте ggml-base.bin в разделе AI-модели.");
        }
        ensureNative();
        if (!whisperLoaded) {
            throw new IllegalStateException("Нативная библиотека whisper не загружена.");
        }
        File model = ModelManager.file(app, ModelManager.WHISPER);
        return nativeTranscribePcm(PcmDecoder.decode16kMono(path), model.getAbsolutePath());
    }

    /**
     * Final post-Whisper polish via AI Core (Gemini Nano / on-device LLM).
     * Uses the professional editor prompt. Falls back to rule-based polish if LLM unavailable.
     */
    public String editTranscript(String rawAsr) {
        if (rawAsr == null || rawAsr.trim().isEmpty()) return "";
        String clean = rawAsr.trim();
        if (aiCoreReady()) {
            try {
                int maxTok = Math.max(96, Math.min(384, clean.length() / 2 + 40));
                String prompt = EDITOR_PROMPT + "\n\nТекст:\n" + clean;
                String out = LlmEngine.generate(app, prompt, maxTok, 0.1f);
                if (out != null && !out.startsWith("LLM-") && out.trim().length() >= 3) {
                    return out.trim();
                }
            } catch (Throwable ignored) {}
        }
        // Fallback: rule-based polish
        return QwenEngine.polishSpokenRussian(clean);
    }

    /**
     * Shorten / condense a long summary text via AI Core.
     */
    public String shortenSummary(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        if (!aiCoreReady()) {
            // simple truncation fallback
            String t = text.trim();
            if (t.length() <= 280) return t;
            return t.substring(0, 277) + "…";
        }
        try {
            String prompt = "Сократи следующий текст до 2–4 коротких предложений, сохранив только ключевые факты и смысл. "
                    + "Выдай только сокращённый текст без пояснений.\n\n" + text.trim();
            String out = LlmEngine.generate(app, prompt, 160, 0.2f);
            if (out != null && !out.startsWith("LLM-") && out.trim().length() >= 3) {
                return out.trim();
            }
        } catch (Throwable ignored) {}
        return text.trim();
    }

    /**
     * Hourly analytical report over last 24 hours of history via AI Core.
     */
    public String hourlyReport24h(java.util.List<Entry> entries) {
        if (entries == null || entries.isEmpty()) {
            return "За последние 24 часа готовых записей нет.";
        }
        StringBuilder ctx = new StringBuilder();
        for (Entry e : entries) {
            if (e.transcript == null || e.transcript.trim().isEmpty()) continue;
            ctx.append("[").append(e.created != null ? e.created : "?").append("] ")
               .append(e.transcript.trim()).append("\n");
        }
        if (ctx.length() == 0) return "За последние 24 часа готовых записей нет.";

        if (aiCoreReady()) {
            try {
                String prompt = "Ты аналитик. Сделай краткий пересказ всех записей за последние 24 часа, "
                        + "сгруппировав по часам где возможно. Выдели ключевые темы, задачи и договорённости. "
                        + "Выдай только готовый пересказ без пояснений.\n\n" + ctx;
                String out = LlmEngine.generate(app, prompt, 480, 0.25f);
                if (out != null && !out.startsWith("LLM-") && out.trim().length() >= 10) {
                    return out.trim();
                }
            } catch (Throwable ignored) {}
        }
        // Fallback template summary
        return qwenEngine.summarizePeriod(ctx.toString(), "последние 24 часа");
    }

    public String answer(String question, String context) {
        // 1) Настоящий локальный LLM (AI Core / Gemini Nano style), если собран и модель установлена
        try {
            if (LlmEngine.available() && ModelManager.installed(app, ModelManager.LLM)) {
                String prompt = QwenEngine.buildLlmPrompt(question, context);
                String out = LlmEngine.generate(app, prompt, 320, 0.3f);
                if (out != null && !out.startsWith("LLM-") && !out.trim().isEmpty()) {
                    return out.trim();
                }
            }
        } catch (Throwable ignored) {}
        // 2) Шаблонный движок — всегда работает, даже без нативного ядра
        return qwenEngine.answerQuestion(question, context);
    }

    public QwenEngine.DaySummary summarizeDay(java.util.List<Entry> entries, String date) {
        return qwenEngine.buildStructuredSummary(entries, date);
    }

    /** Runs the real on-device LLM for a higher-level semantic day brief. */
    public String neuralDayBrief(java.util.List<Entry> entries, String date) {
        if (!qwenReady() || !LlmEngine.available()) return "";
        return qwenEngine.neuralDayBrief(entries, date);
    }

    public String summarize(String context, String date) {
        return qwenEngine.summarizePeriod(context, date);
    }

    public String summarize(String context) {
        return summarize(context, null);
    }

    /**
     * Low-latency transcription entry point used by RealtimeTranscriber.
     * The native side keeps one persistent Whisper context, so this call does
     * not reload the model for every short audio window.
     */
    public String transcribeRealtimePcm(float[] pcm) {
        if (pcm == null || pcm.length == 0) return "";
        ensureNative();
        if (!whisperLoaded || !ModelManager.installed(app, ModelManager.WHISPER)) return "";
        try {
            File model = ModelManager.file(app, ModelManager.WHISPER);
            return nativeTranscribeRealtimePcm(pcm, model.getAbsolutePath());
        } catch (Throwable ignored) {
            return "";
        }
    }

    private native String nativeTranscribePcm(float[] pcm, String whisperModel);
    private static native String nativeTranscribeRealtimePcm(float[] pcm, String whisperModel);
}
