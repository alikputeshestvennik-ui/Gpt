package com.blackbox.offline;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Obsidian & Solar Amber Design Studio System — v2.
 *
 * Принцип: янтарь остаётся единственным фирменным акцентом (это цвет самой
 * иконки-сейфа), но одинокий яркий акцент на почти чёрном фоне — это ровно
 * тот "generic AI dark theme" паттерн, который легко считывается как
 * шаблонный. Разница здесь — в слоистости (5 ступеней поверхности вместо 2),
 * настоящей тени через View.setElevation с тёплым оттенком вместо чёрной,
 * и во второстепенном холодном акценте (сталь), который используется ТОЛЬКО
 * для realtime/live-элементов — чтобы "живое сейчас" визуально отличалось
 * от "записанное давно" (янтарь), а не заливать всё одним цветом.
 */
public final class UI {
    // Canvas & Elevation — 5 ступеней вместо плоских 2, для настоящей глубины
    public static final int COLOR_BG = 0xFF07080B;
    public static final int COLOR_SURFACE = 0xFF121319;
    public static final int COLOR_SURFACE_ELEVATED = 0xFF181A22;
    public static final int COLOR_SURFACE_HIGH = 0xFF1E212B;
    public static final int COLOR_SURFACE_HOVER = 0xFF262A37;
    public static final int COLOR_BORDER = 0xFF232733;
    public static final int COLOR_BORDER_BRIGHT = 0xFF3A4256;

    // Тёплый оттенок тени вместо стандартной чёрной — тень выглядит так,
    // будто карточка освещена тем же янтарным светом, что и бренд-иконка.
    public static final int SHADOW_WARM = 0xFF1F0E00;

    // Signature Solar Amber — основной, единственный "громкий" акцент
    public static final int COLOR_ORANGE = 0xFFF47721;
    public static final int COLOR_ORANGE_LIGHT = 0xFFFF9344;
    public static final int COLOR_ORANGE_CORE = 0xFFFFB57F;
    public static final int COLOR_ORANGE_DIM = 0x1EF47721;
    public static final int COLOR_ORANGE_BORDER = 0xFF66300C;

    // Второй, холодный акцент — ТОЛЬКО для live/realtime-состояний (лента
    // Vosk, "слушаю сейчас"). Не смешивается с янтарём — тот остаётся за
    // архивными/уже записанными данными, это — за тем, что происходит
    // прямо сейчас.
    public static final int COLOR_LIVE = 0xFF5EC8D8;
    public static final int COLOR_LIVE_DIM = 0x1E5EC8D8;
    public static final int COLOR_LIVE_BORDER = 0xFF1F5158;

    // Semantic Accents
    public static final int COLOR_IMPORTANT_BG = 0xFF1C130B;
    public static final int COLOR_IMPORTANT_BORDER = 0xFFB3530F;

    public static final int COLOR_GREEN = 0xFF34C77B;
    public static final int COLOR_GREEN_BG = 0x2034C77B;
    public static final int COLOR_RED = 0xFFEF4444;
    public static final int COLOR_RED_BG = 0x22EF4444;
    public static final int COLOR_RED_GRAD_END = 0xFFB91C1C;

    // Studio Typography Hierarchy
    public static final int COLOR_TEXT_TITLE = 0xFFFFFFFF;
    public static final int COLOR_TEXT_PRIMARY = 0xFFF1F3F7;
    public static final int COLOR_TEXT_MUTED = 0xFF969EAE;
    public static final int COLOR_TEXT_SUBTLE = 0xFF5D6574;
    public static final int COLOR_TEXT_ORANGE = 0xFFFFA25F;

    // Единая шкала отступов (4dp-сетка). Раньше отступы подбирались на глаз
    // в каждом файле отдельно — отсюда мелкий визуальный разнобой.
    public static int spaceXs(Context c) { return dp(c, 4); }
    public static int spaceS(Context c)  { return dp(c, 8); }
    public static int spaceM(Context c)  { return dp(c, 16); }
    public static int spaceL(Context c)  { return dp(c, 24); }
    public static int spaceXl(Context c) { return dp(c, 32); }

    private UI() {}

    public static int dp(Context c, int val) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, val, c.getResources().getDisplayMetrics());
    }

    public static GradientDrawable shape(int bgColor, int borderColor, int radiusDp, Context c) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bgColor);
        gd.setCornerRadius(dp(c, radiusDp));
        if (borderColor != 0) {
            gd.setStroke(dp(c, 1), borderColor);
        }
        return gd;
    }

    public static GradientDrawable gradient(int startColor, int endColor, int radiusDp, Context c) {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{startColor, endColor});
        gd.setCornerRadius(dp(c, radiusDp));
        return gd;
    }

    public static RippleDrawable buttonRipple(GradientDrawable content, int rippleColor) {
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, null);
    }

    /**
     * Настоящая приподнятость через View.setElevation вместо имитации
     * бордером. На API 28+ тень тонируется тёплым (SHADOW_WARM) — на плоском
     * "obsidian" фоне это выглядит как мягкое янтарное свечение снизу, а не
     * стандартная серая Material-тень по умолчанию.
     */
    public static void elevate(View v, int dp) {
        float px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, v.getContext().getResources().getDisplayMetrics());
        v.setElevation(px);
        if (Build.VERSION.SDK_INT >= 28) {
            v.setOutlineAmbientShadowColor(SHADOW_WARM);
            v.setOutlineSpotShadowColor(SHADOW_WARM);
        }
    }

    /**
     * Studio App Header with Monolith Mark, Sharp Typography, and Back Navigation.
     */
    public static LinearLayout createHeader(Activity a, String title, String subtitle, boolean showBack) {
        Context c = a;
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.VERTICAL);
        int sbId = c.getResources().getIdentifier("status_bar_height", "dimen", "android");
        int topInset = sbId > 0 ? c.getResources().getDimensionPixelSize(sbId) : dp(c, 24);
        bar.setPadding(0, topInset + dp(c, 8), 0, dp(c, 18));

        if (showBack) {
            LinearLayout backRow = new LinearLayout(c);
            backRow.setOrientation(LinearLayout.HORIZONTAL);
            backRow.setGravity(Gravity.CENTER_VERTICAL);
            backRow.setPadding(0, dp(c, 2), dp(c, 16), dp(c, 10));

            TextView chevron = new TextView(c);
            chevron.setText("‹");
            chevron.setTextColor(COLOR_ORANGE);
            chevron.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            chevron.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            backRow.addView(chevron);

            TextView backText = new TextView(c);
            backText.setText(" Назад");
            backText.setTextColor(COLOR_ORANGE);
            backText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            backText.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            backRow.addView(backText);

            backRow.setOnClickListener(v -> a.finish());
            bar.addView(backRow);
        }

        // Title row with Brand Mark
        LinearLayout titleRow = new LinearLayout(c);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        ImageView mark = new ImageView(c);
        int resId = c.getResources().getIdentifier("blackbox_mark", "drawable", c.getPackageName());
        if (resId != 0) mark.setImageResource(resId);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(c, 44), dp(c, 44));
        mlp.rightMargin = dp(c, 14);
        titleRow.addView(mark, mlp);

        LinearLayout textCol = new LinearLayout(c);
        textCol.setOrientation(LinearLayout.VERTICAL);

        TextView tvTitle = new TextView(c);
        tvTitle.setText(title);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        tvTitle.setTextColor(COLOR_TEXT_TITLE);
        tvTitle.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        textCol.addView(tvTitle);

        if (subtitle != null && !subtitle.isEmpty()) {
            TextView tvSub = new TextView(c);
            tvSub.setText(subtitle);
            tvSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            tvSub.setTextColor(COLOR_TEXT_MUTED);
            tvSub.setPadding(0, dp(c, 2), 0, 0);
            textCol.addView(tvSub);
        }

        titleRow.addView(textCol);
        bar.addView(titleRow);

        return bar;
    }

    public static LinearLayout createCard(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(c, 18);
        l.setPadding(pad, pad, pad, pad);
        // Layered surface: slightly brighter top edge via gradient + stroke
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{COLOR_SURFACE_ELEVATED, COLOR_SURFACE});
        gd.setCornerRadius(dp(c, 18));
        gd.setStroke(dp(c, 1), COLOR_BORDER);
        l.setBackground(gd);
        elevate(l, 3);
        return l;
    }

    /**
     * Карточка для live/realtime-контента (лента Vosk) — использует
     * холодный акцент вместо янтаря, чтобы "прямо сейчас" визуально не
     * путалось с уже сохранёнными записями.
     */
    public static LinearLayout createLiveCard(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(c, 18);
        l.setPadding(pad, pad, pad, pad);
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF151C22, COLOR_SURFACE});
        gd.setCornerRadius(dp(c, 18));
        gd.setStroke(dp(c, 1), COLOR_LIVE_BORDER);
        l.setBackground(gd);
        elevate(l, 4);
        return l;
    }

    public static LinearLayout createImportantCard(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(c, 18);
        l.setPadding(pad, pad, pad, pad);
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF22180F, COLOR_IMPORTANT_BG});
        gd.setCornerRadius(dp(c, 18));
        gd.setStroke(dp(c, 1), COLOR_IMPORTANT_BORDER);
        l.setBackground(gd);
        elevate(l, 4);
        return l;
    }

    /** Лёгкое «сжатие» кнопки при нажатии — динамичный тактильный отклик. */
    public static void attachPressScale(final Button b) {
        b.setOnTouchListener((v, ev) -> {
            int a = ev.getActionMasked();
            if (a == android.view.MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start();
            } else if (a == android.view.MotionEvent.ACTION_UP || a == android.view.MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1f).scaleY(1f).setDuration(110).start();
            }
            return false; // клик должен сработать как обычно
        });
    }

    public static Button primaryButton(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        b.setAllCaps(false);
        GradientDrawable core = gradient(COLOR_ORANGE, COLOR_ORANGE_LIGHT, 14, c);
        b.setBackground(buttonRipple(core, 0x55FFFFFF));
        int padH = dp(c, 22);
        int padV = dp(c, 14);
        b.setPadding(padH, padV, padH, padV);
        elevate(b, 4);
        if (Build.VERSION.SDK_INT >= 28) {
            b.setOutlineAmbientShadowColor(SHADOW_WARM);
            b.setOutlineSpotShadowColor(0xFF3A1800);
        }
        attachPressScale(b);
        return b;
    }

    public static Button secondaryButton(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextColor(COLOR_TEXT_PRIMARY);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        b.setAllCaps(false);
        b.setBackground(buttonRipple(shape(COLOR_SURFACE_ELEVATED, COLOR_BORDER, 12, c), 0x33F47721));
        int padH = dp(c, 16);
        int padV = dp(c, 10);
        b.setPadding(padH, padV, padH, padV);
        attachPressScale(b);
        return b;
    }

    /**
     * Interactive Studio Nav Card with Graphic Icon, High Hierarchy Typography, and Chevron.
     */
    public static LinearLayout navCardButton(Context c, String drawableName, String title, String subtitle, View.OnClickListener onClick) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        int padH = dp(c, 16);
        int padV = dp(c, 16);
        row.setPadding(padH, padV, padH, padV);
        row.setBackground(buttonRipple(shape(COLOR_SURFACE, COLOR_BORDER, 18, c), 0x33F47721));
        elevate(row, 1);

        ImageView iconView = new ImageView(c);
        int iconRes = c.getResources().getIdentifier(drawableName, "drawable", c.getPackageName());
        if (iconRes != 0) {
            iconView.setImageResource(iconRes);
        }
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(c, 34), dp(c, 34));
        ip.rightMargin = dp(c, 14);
        row.addView(iconView, ip);

        LinearLayout textCol = new LinearLayout(c);
        textCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1.0f);
        textCol.setLayoutParams(lp);

        TextView tvTitle = new TextView(c);
        tvTitle.setText(title);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tvTitle.setTextColor(COLOR_TEXT_PRIMARY);
        tvTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        textCol.addView(tvTitle);

        if (subtitle != null && !subtitle.isEmpty()) {
            TextView tvSub = new TextView(c);
            tvSub.setText(subtitle);
            tvSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvSub.setTextColor(COLOR_TEXT_MUTED);
            tvSub.setPadding(0, dp(c, 3), 0, 0);
            textCol.addView(tvSub);
        }
        row.addView(textCol);

        TextView chevron = new TextView(c);
        chevron.setText("›");
        chevron.setTextColor(COLOR_ORANGE);
        chevron.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        chevron.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        chevron.setPadding(dp(c, 6), 0, 0, 0);
        row.addView(chevron);

        row.setOnClickListener(onClick);
        return row;
    }

    public static TextView badge(Context c, String text, int textColor, int bgColor) {
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(textColor);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        int padH = dp(c, 11);
        int padV = dp(c, 5);
        tv.setPadding(padH, padV, padH, padV);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bgColor);
        gd.setCornerRadius(dp(c, 20));
        tv.setBackground(gd);
        return tv;
    }

    /**
     * Индикатор "прямо сейчас" (например, "слушаю в фоне") — живая точка +
     * текст обычным регистром вместо капса с трекингом. Капс-эйбрау —
     * распространённый штамп генеративного дизайна; здесь вместо него
     * пульсирующая точка холодного live-акцента несёт тот же смысл нагляднее.
     */
    public static LinearLayout liveStatusPill(Context c, String text) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        int padH = dp(c, 12);
        int padV = dp(c, 7);
        row.setPadding(padH, padV, padH, padV);
        row.setBackground(shape(COLOR_LIVE_DIM, COLOR_LIVE_BORDER, 20, c));

        View dot = new View(c);
        int dotSize = dp(c, 8);
        GradientDrawable dotShape = new GradientDrawable();
        dotShape.setShape(GradientDrawable.OVAL);
        dotShape.setColor(COLOR_LIVE);
        dot.setBackground(dotShape);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dotSize, dotSize);
        dlp.rightMargin = dp(c, 8);
        row.addView(dot, dlp);

        android.animation.ObjectAnimator pulse = android.animation.ObjectAnimator.ofFloat(dot, "alpha", 1f, 0.35f, 1f);
        pulse.setDuration(1600);
        pulse.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        pulse.start();

        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(COLOR_LIVE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        row.addView(tv);

        return row;
    }

    public static EditText inputField(Context c, String hint) {
        EditText et = new EditText(c);
        et.setHint(hint);
        et.setHintTextColor(COLOR_TEXT_SUBTLE);
        et.setTextColor(COLOR_TEXT_PRIMARY);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        et.setBackground(shape(0xFF0C0E12, COLOR_BORDER, 14, c));
        int pad = dp(c, 16);
        et.setPadding(pad, pad, pad, pad);
        return et;
    }

    public static void copyToClipboard(Context c, String label, String text) {
        ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText(label, text));
            Toast.makeText(c, "Скопировано в буфер обмена ✓", Toast.LENGTH_SHORT).show();
        }
    }
}
