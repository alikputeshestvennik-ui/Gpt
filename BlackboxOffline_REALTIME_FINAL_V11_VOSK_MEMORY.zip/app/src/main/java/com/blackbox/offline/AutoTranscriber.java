package com.blackbox.offline;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.io.File;


/**
 * Intelligent local Whisper transcription pipeline.
 * Features:
 * - Anti-hallucination cleaning
 * - Trash rejection: drops non-speech noise
 * - Voice Stop Keyword detection: stops background recording service
 * - Hands-free Voice Recall: answers questions like "блэкбокс, какой код..." via instant push notification
 */
public final class AutoTranscriber {
    private static final java.util.LinkedList<Runnable> pending = new java.util.LinkedList<>();
    private static final Object queueLock = new Object();
    private static final int MAX_WORKERS = 1;
    private static int activeWorkers = 0;

    private AutoTranscriber() {}


    public static void notifyRecordingStateChanged() {
        synchronized (queueLock) {
            queueLock.notifyAll();
        }
    }

    public static void enqueue(Context c, Entry e) {
        final Context app = c.getApplicationContext();
        synchronized (queueLock) {
            pending.addLast(() -> processOne(app, e));
            // Один финальный worker: native Whisper использует один прогретый
            // context, а realtime-расшифровка живёт отдельно и не блокируется очередью.
            while (activeWorkers < MAX_WORKERS) {
                activeWorkers++;
                new Thread(AutoTranscriber::workerLoop, "blackbox-transcribe-" + activeWorkers).start();
            }
            queueLock.notifyAll();
        }
    }

    // Новые фрагменты обрабатываются ПЕРВЫМИ (LIFO): голосовые команды
    // («блэкбокс, выключись») произносятся последними и реагируют сразу,
    // не дожидаясь всей очереди. Старые заметки не теряются — идут следом.
    //
    // Раньше здесь было `|| RecordingService.isRecordingActive`, то есть
    // Whisper ждал полной остановки фоновой записи, чтобы не грузить CPU
    // одновременно с живым циклом Vosk/VAD. По вашему выбору это отключено:
    // каждая законченная фраза уходит в Whisper сразу же, даже если фон
    // ещё слушает. Если на устройстве при этом начнёт проседать realtime
    // (частые пропуски/заикания в живой ленте Vosk) — можно будет вернуть
    // старое поведение обратно.
    private static void workerLoop() {
        while (true) {
            Runnable job;
            synchronized (queueLock) {
                while (pending.isEmpty()) {
                    try { queueLock.wait(500); } catch (InterruptedException ignored) {}
                }
                job = pending.removeLast();
            }
            try { job.run(); } catch (Throwable ignored) {}
        }
    }

    private static void processOne(Context app, Entry e) {
            try {
                String existing = cleanHallucinations(e.transcript);
                if (existing != null && existing.trim().length() >= 3) {
                    e.transcript = existing.trim();
                    e.status = "Готово";
                    new EntryStore(app).replace(e);
                    app.sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
                    return;
                }

                LocalAiEngine engine = new LocalAiEngine(app);
                if (!engine.whisperReady()) {
                    e.status = "Нет модели: откройте вкладку «Модели» и импортируйте Whisper";
                    new EntryStore(app).replace(e);
                    app.sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
                    return;
                }
                e.status = "Финальная проверка…";
                new EntryStore(app).replace(e);

                String rawText = engine.transcribe(e.path);
                String clean = cleanHallucinations(rawText);

                if (clean.length() < 3) {
                    try {
                        if (e.path != null && !e.path.isEmpty()) {
                            new File(e.path).delete();
                        }
                    } catch (Exception ignored) {}
                    new EntryStore(app).delete(e.id);
                    app.sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
                    return;
                }

                // Одиночный короткий токен без пробелов — почти всегда галлюцинация
                // whisper на кашле/щелчках ("DimaTorzok"). Реальные заметки так не выглядят.
                boolean isNoiseToken = clean.length() <= 10 && !clean.contains(" ")
                        && !clean.contains("!") && !clean.contains("?") && !clean.contains(":");
                if (isNoiseToken) {
                    try {
                        if (e.path != null && !e.path.isEmpty()) {
                            new File(e.path).delete();
                        }
                    } catch (Exception ignored) {}
                    new EntryStore(app).delete(e.id);
                    app.sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
                    return;
                }

                // ВАЖНО: в конвейере расшифровки НЕТ LLM — заметка должна быть
                // готова за 1-3 секунды. LLM-обработка — только по требованию:
                // кнопка «✨ Улучшить» на карточке, вопросы в поиске и памяти.
                e.transcript = clean;

                e.status = "Готово";

                String lower = clean.toLowerCase();

                // 1. Voice Stop Commands
                boolean isStopCommand = lower.contains("блэкбокс стоп")
                        || lower.contains("блэкбокс, стоп")
                        || lower.contains("блэкбокс остановись")
                        || lower.contains("блэкбокс, остановись")
                        || lower.contains("блэкбокс отключись")
                        || lower.contains("блэкбокс, отключись")
                        || lower.contains("блэкбокс хватит")
                        || lower.contains("блэкбокс спать")
                        || lower.contains("блэкбокс выключись")
                        || lower.contains("блэкбокс, выключись")
                        || lower.contains("выключись")
                        || lower.contains("blackbox stop")
                        || lower.contains("останови запись")
                        || lower.contains("стоп запись");

                if (isStopCommand) {
                    Intent stopIntent = new Intent(app, RecordingService.class).setAction(RecordingService.STOP);
                    app.startService(stopIntent);
                    e.important = true;
                    e.category = "Команды";
                    e.summary = "⏹ Остановлено голосовой командой";
                }

                // 2. Hands-Free Voice Recall ("Блэкбокс, какой...", "Блэкбокс, где...")
                boolean isQuestionToMemory = lower.contains("блэкбокс") && (
                        lower.contains("какой") || lower.contains("где") || lower.contains("когда")
                                || lower.contains("куда") || lower.contains("сколько") || lower.contains("напомни")
                                || lower.contains("пароль") || lower.contains("код") || lower.contains("номер")
                );

                if (isQuestionToMemory && !isStopCommand && !e.handsFreeHandled) {
                    processHandsFreeMemoryRecall(app, clean);
                }

                // 3. Important Flag
                boolean isImportant = lower.contains("блэкбокс важно")
                        || lower.contains("blackbox важно")
                        || lower.contains("запомни это")
                        || lower.contains("очень важно")
                        || lower.contains("важная мысль");

                if (isImportant) {
                    e.important = true;
                    e.summary = "ВАЖНО";
                }

                // 4. Smart Categorization
                if (!isStopCommand) {
                    e.category = detectCategory(lower);
                }

                new EntryStore(app).replace(e);
                app.sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
            } catch (Throwable x) {
                String msg = (x.getMessage() == null ? "сбой" : x.getMessage());
                if (msg.toLowerCase().contains("импортируйте")) {
                    e.status = "Нет модели: импортируйте Whisper во вкладке «Модели»";
                } else {
                    e.status = "Ошибка: " + msg;
                }
                new EntryStore(app).replace(e);
                app.sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
            }
    }

    private static volatile long lastRecallAt = 0;
    private static volatile String lastRecallQuery = "";

    /** Detect hands-free memory question from any transcript (Vosk live or Whisper final). */
    public static boolean looksLikeMemoryQuestion(String text) {
        if (text == null) return false;
        String lower = text.toLowerCase(java.util.Locale.ROOT);
        if (!(lower.contains("блэкбокс") || lower.contains("blackbox") || lower.contains("блокбук"))) {
            return false;
        }
        return lower.contains("какой") || lower.contains("где") || lower.contains("когда")
                || lower.contains("куда") || lower.contains("сколько") || lower.contains("напомни")
                || lower.contains("пароль") || lower.contains("код") || lower.contains("номер")
                || lower.contains("что я") || lower.contains("что мы");
    }

    public static boolean looksLikeStopCommand(String text) {
        if (text == null) return false;
        String lower = text.toLowerCase(java.util.Locale.ROOT);
        return lower.contains("блэкбокс стоп") || lower.contains("блэкбокс, стоп")
                || lower.contains("блэкбокс остановись") || lower.contains("blackbox stop")
                || lower.contains("останови запись") || lower.contains("стоп запись")
                || lower.contains("блэкбокс выключись") || lower.contains("блэкбокс хватит");
    }

    /**
     * Voice → LLM memory answer → push notification.
     * Context = diary entries + last 15 min Vosk realtime ring (for speed/recency).
     */
    public static void processHandsFreeMemoryRecall(Context context, String query) {
        if (context == null || query == null) return;
        String q = query.trim();
        if (q.length() < 4) return;
        long now = System.currentTimeMillis();
        // Debounce partial Vosk updates
        if (q.equals(lastRecallQuery) && now - lastRecallAt < 12000) return;
        if (now - lastRecallAt < 2500) return;
        lastRecallAt = now;
        lastRecallQuery = q;

        final Context app = context.getApplicationContext();
        new Thread(() -> {
            try {
                StringBuilder archiveContext = new StringBuilder();

                // 1) Fast recent context from Vosk 15-min ring
                try {
                    java.util.ArrayList<RealtimeRingStore.Item> ring = RealtimeRingStore.snapshot(app);
                    if (!ring.isEmpty()) {
                        archiveContext.append("=== Realtime (последние 15 минут) ===\n");
                        for (RealtimeRingStore.Item it : ring) {
                            if (it.text != null && !it.text.isEmpty()) {
                                archiveContext.append("[").append(it.timeLabel()).append("] ")
                                        .append(it.text.trim()).append("\n");
                            }
                        }
                        archiveContext.append("\n");
                    }
                } catch (Throwable ignored) {}

                // 2) Full diary archive
                archiveContext.append("=== Дневник ===\n");
                for (Entry item : new EntryStore(app).all()) {
                    if (item.transcript != null && !item.transcript.trim().isEmpty()) {
                        archiveContext.append("[").append(item.created).append("] ")
                                      .append(item.transcript.trim())
                                      .append("\n\n");
                    }
                }

                LocalAiEngine ai = new LocalAiEngine(app);
                String answer = ai.answer(q, archiveContext.toString());
                if (answer == null || answer.trim().isEmpty()) {
                    answer = "В памяти пока нет ответа на этот вопрос.";
                }

                NotificationManager nm = (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) {
                    ensureRecallChannel(app);
                    Notification n;
                    if (Build.VERSION.SDK_INT >= 26) {
                        n = new Notification.Builder(app, "memory_recall")
                                .setSmallIcon(android.R.drawable.ic_dialog_info)
                                .setContentTitle("Blackbox Память")
                                .setContentText(answer)
                                .setStyle(new Notification.BigTextStyle().bigText(answer))
                                .setAutoCancel(true)
                                .build();
                    } else {
                        n = new Notification.Builder(app)
                                .setSmallIcon(android.R.drawable.ic_dialog_info)
                                .setContentTitle("Blackbox Память")
                                .setContentText(answer)
                                .setAutoCancel(true)
                                .build();
                    }
                    nm.notify(991, n);
                }
            } catch (Throwable ignored) {}
        }, "blackbox-memory-recall").start();
    }

    /** Apply command/category side effects to a realtime transcript.
     *  Realtime clips no longer enter the final full-file queue, so these
     *  lightweight actions must also run on the live path.
     */
    public static void processRealtimeEntry(Context context, Entry e) {
        if (context == null || e == null) return;
        try {
            String clean = cleanHallucinations(e.transcript);
            e.transcript = clean;
            String lower = clean.toLowerCase(java.util.Locale.ROOT);

            boolean isStopCommand = lower.contains("блэкбокс стоп")
                    || lower.contains("блэкбокс, стоп")
                    || lower.contains("блэкбокс остановись")
                    || lower.contains("блэкбокс, остановись")
                    || lower.contains("блэкбокс отключись")
                    || lower.contains("блэкбокс, отключись")
                    || lower.contains("блэкбокс хватит")
                    || lower.contains("блэкбокс спать")
                    || lower.contains("блэкбокс выключись")
                    || lower.contains("блэкбокс, выключись")
                    || lower.contains("блокбук стоп")
                    || lower.contains("blackbox stop")
                    || lower.contains("останови запись")
                    || lower.contains("стоп запись");

            boolean isImportant = lower.contains("блэкбокс важно")
                    || lower.contains("blackbox важно")
                    || lower.contains("запомни это")
                    || lower.contains("очень важно")
                    || lower.contains("важная мысль");

            if (isStopCommand) {
                e.important = true;
                e.category = "Команды";
                e.summary = "⏹ Остановлено голосовой командой";
                e.status = "Готово";
            } else {
                e.category = detectCategory(lower);
            }
            if (isImportant) {
                e.important = true;
                e.summary = "ВАЖНО";
            }

            new EntryStore(context).upsert(e);
            context.sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(context.getPackageName()));

            if (isStopCommand) {
                try {
                    Intent stopIntent = new Intent(context, RecordingService.class).setAction(RecordingService.STOP);
                    context.startService(stopIntent);
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
    }

    public static String cleanHallucinations(String raw) {
        if (raw == null) return "";
        String s = raw.replaceAll("\\[[^\\]]*\\]", "").replaceAll("\\([^\\)]*\\)", "");
        s = s.replaceAll("(?i)\\b(музыка|звуки|аплодисменты|смех|шум|пение|помехи|звонок|речь не распознана|спасибо за просмотр|субтитры сделал|продолжение следует|кашель|кашляет|откашливается|кхе|кх-кх|чихает|чихание|вздох|зевота|глотает|сглатывает|шепот|субтитры|редактор|корректор)\\b", "");
        // Strip leaked vocabulary-bias / prompt echoes from streaming.
        s = s.replaceAll("(?i)блэкбокс\\s*,\\s*стоп\\s*,\\s*блэкбокс\\s+стоп\\s*,\\s*запомни\\s*,\\s*заметка\\s*,\\s*задача\\s*,\\s*встреча\\s*,\\s*идея\\.?", " ");
        s = s.replaceAll("(?i)(,\\s*)?(запомни|заметка|задача|встреча|идея)(\\s*,\\s*(запомни|заметка|задача|встреча|идея))+\\.?", " ");
        s = s.replaceAll("(?i)\\b(я не произносил данных|слушайте|продолжение следует|спасибо за внимание|до встречи|субтитры делал|редактор субтитров|набодка идет на нижнем уровне)\\b", "");
        s = s.replaceAll("(?i)\\bблокбук\\b(?=\\s*[,\\.\\-]?\\s*стоп\\b)", "Блэкбокс");
        s = s.replaceAll("\\s+", " ").trim();
        s = collapseRepeatLoops(s);
        s = s.replaceAll("^[\\.,\\-\\?!;:\\s]+", "").replaceAll("[\\.,\\-\\?!;:\\s]+$", "").trim();
        String low = s.toLowerCase(java.util.Locale.ROOT);
        String stripped = low.replaceAll("(?i)блэкбокс|стоп|запомни|заметка|задача|встреча|идея|[\\s,\\.]+", "");
        if (stripped.length() < 2 && low.length() > 0 && (low.contains("запомни") || low.contains("заметка") || low.contains("идея"))) {
            return "";
        }
        return s;
    }

    /**
     * Whisper на длинных шумных/тихих кусках иногда зацикливается и выдаёт
     * одно и то же слово подряд десятки раз («We We We We We…», «You You
     * You You…»). Схлопываем любой прогон из 3+ подряд идущих одинаковых
     * слов (без учёта регистра и пунктуации) до одного вхождения.
     */
    private static String collapseRepeatLoops(String s) {
        if (s == null || s.isEmpty()) return s;
        String[] tokens = s.split(" ");
        StringBuilder out = new StringBuilder();
        int i = 0;
        while (i < tokens.length) {
            String cur = tokens[i];
            String curNorm = cur.toLowerCase(java.util.Locale.ROOT).replaceAll("[^\\p{L}\\p{Nd}]", "");
            int j = i + 1;
            while (j < tokens.length) {
                String nextNorm = tokens[j].toLowerCase(java.util.Locale.ROOT).replaceAll("[^\\p{L}\\p{Nd}]", "");
                if (!curNorm.isEmpty() && curNorm.equals(nextNorm)) j++;
                else break;
            }
            if (out.length() > 0) out.append(' ');
            out.append(cur);
            i = (j - i >= 3) ? j : i + 1;
        }
        return out.toString();
    }

    public static String detectCategory(String lower) {
        if (lower.contains("задач") || lower.contains("сделать") || lower.contains("купить")
                || lower.contains("нужно") || lower.contains("надо") || lower.contains("чеклист")
                || lower.contains("список") || lower.contains("напомни")) {
            return "Задачи";
        }
        if (lower.contains("встреч") || lower.contains("созвон") || lower.contains("звонок")
                || lower.contains("договорил") || lower.contains("планёрк") || lower.contains("митинг")
                || lower.contains("в 1") || lower.contains("в 2") || lower.contains("часов")) {
            return "Встречи";
        }
        if (lower.contains("идея") || lower.contains("придумал") || lower.contains("мысль")
                || lower.contains("проект") || lower.contains("концепт") || lower.contains("гипотез")) {
            return "Идеи";
        }
        return "Заметки";
    }

    private static void ensureRecallChannel(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nmg = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nmg != null && nmg.getNotificationChannel("memory_recall") == null) {
                NotificationChannel ch = new NotificationChannel("memory_recall", "Blackbox Память", NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("Голосовые ответы памяти Blackbox");
                ch.enableVibration(true);
                nmg.createNotificationChannel(ch);
            }
        }
    }
}

