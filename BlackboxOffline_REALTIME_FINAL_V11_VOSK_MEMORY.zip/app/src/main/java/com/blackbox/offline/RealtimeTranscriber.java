package com.blackbox.offline;

import android.content.Context;
import android.content.Intent;
import java.util.Locale;

/**
 * Live streaming via Vosk (fast, free). Does NOT write final History cards.
 * After stop, RecordingService queues Whisper Base for polished diary entries.
 */
public final class RealtimeTranscriber {
    public static final String LIVE_TEXT = "com.blackbox.offline.LIVE_TEXT";

    private final Context app;
    private volatile boolean running;
    private volatile boolean cancelRequested;
    private long generation;
    private Thread worker;
    private Entry entry;
    private VoskEngine vosk;
    private String accumulated = "";
    private final Object feedLock = new Object();
    private short[] pendingPcm;
    private int pendingN;
    private boolean hasPending;
    private boolean commandHandled;

    public RealtimeTranscriber(Context c) {
        app = c.getApplicationContext();
    }

    public synchronized void start(Entry e) {
        if (e == null) return;
        if (running || worker != null) cancel();
        final long myGeneration = ++generation;
        entry = e;
        accumulated = "";
        running = true;
        cancelRequested = false;
        hasPending = false;
        pendingPcm = null;
        pendingN = 0;
        worker = new Thread(() -> workerLoop(myGeneration), "blackbox-vosk-realtime");
        worker.start();
    }

    public void feed(short[] pcm, int n) {
        if (!running || pcm == null || n <= 0) return;
        synchronized (feedLock) {
            if (pendingPcm == null || pendingPcm.length < n) {
                pendingPcm = new short[Math.max(n, 16000)];
            }
            System.arraycopy(pcm, 0, pendingPcm, 0, n);
            pendingN = n;
            hasPending = true;
            feedLock.notifyAll();
        }
    }

    private void workerLoop(long myGeneration) {
        vosk = new VoskEngine(app);
        try {
            if (!vosk.isReady()) {
                broadcastLive(myGeneration, "");
                setStatusIfCurrent(myGeneration, ModelManager.voskInstalled(app)
                        ? "Vosk: ошибка загрузки"
                        : "Нет модели Vosk — импортируйте в «Модели»");
                return;
            }
            broadcastLive(myGeneration, "");
            while (true) {
                synchronized (this) {
                    if (myGeneration != generation || cancelRequested) break;
                    if (!running && !hasPending) break;
                }
                short[] chunk;
                int n;
                synchronized (feedLock) {
                    while (!hasPending && running && myGeneration == generation && !cancelRequested) {
                        try {
                            feedLock.wait(200);
                        } catch (InterruptedException ie) {
                            break;
                        }
                    }
                    if (!hasPending) {
                        if (!running) break;
                        continue;
                    }
                    n = pendingN;
                    chunk = new short[n];
                    System.arraycopy(pendingPcm, 0, chunk, 0, n);
                    hasPending = false;
                }
                if (myGeneration != generation || cancelRequested) break;
                String hyp = vosk.accept(chunk, n);
                if (hyp != null && !hyp.isEmpty()) {
                    accumulated = hyp.trim();
                    broadcastLive(myGeneration, accumulated);
                    RealtimeRingStore.append(app, accumulated);
                    // Hands-free: Vosk → LLM memory → push (fast path)
                    if (!commandHandled && AutoTranscriber.looksLikeMemoryQuestion(accumulated)) {
                        commandHandled = true;
                        AutoTranscriber.processHandsFreeMemoryRecall(app, accumulated);
                    }
                    if (!commandHandled && AutoTranscriber.looksLikeStopCommand(accumulated)) {
                        commandHandled = true;
                        try {
                            app.startService(new Intent(app, RecordingService.class).setAction(RecordingService.STOP));
                        } catch (Throwable ignored) {}
                    }
                }
            }
            // Final partial flush when stopping this utterance
            if (myGeneration == generation && !cancelRequested) {
                String fin = vosk.flush();
                if (fin != null && !fin.isEmpty()) {
                    accumulated = fin.trim();
                    broadcastLive(myGeneration, accumulated);
                    RealtimeRingStore.append(app, accumulated);
                }
            }
        } finally {
            if (vosk != null) {
                vosk.release();
                vosk = null;
            }
            synchronized (this) {
                if (myGeneration == generation) {
                    if (Thread.currentThread() == worker) worker = null;
                    entry = null;
                } else if (Thread.currentThread() == worker) {
                    worker = null;
                }
            }
        }
    }

    private void broadcastLive(long myGeneration, String text) {
        if (myGeneration != generation) return;
        try {
            Intent live = new Intent(LIVE_TEXT).setPackage(app.getPackageName());
            live.putExtra("text", text == null ? "" : text);
            app.sendBroadcast(live);
        } catch (Throwable ignored) {}
    }

    private void setStatusIfCurrent(long myGeneration, String status) {
        synchronized (this) {
            if (myGeneration != generation || entry == null) return;
            entry.status = status;
            new EntryStore(app).replace(entry);
        }
        app.sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
    }

    public synchronized void publish() {
        // Vosk text is never the final diary card — Whisper finalizes after stop.
    }

    public synchronized boolean isPublished() {
        return false;
    }

    public synchronized void finish() {
        running = false;
        synchronized (feedLock) {
            feedLock.notifyAll();
        }
        if (worker != null) worker.interrupt();
    }

    public synchronized void cancel() {
        running = false;
        cancelRequested = true;
        generation++;
        synchronized (feedLock) {
            hasPending = false;
            feedLock.notifyAll();
        }
        Thread t = worker;
        if (t != null) t.interrupt();
        entry = null;
        try {
            Intent live = new Intent(LIVE_TEXT).setPackage(app.getPackageName());
            live.putExtra("text", "");
            app.sendBroadcast(live);
        } catch (Throwable ignored) {}
    }

    public synchronized void stop() {
        finish();
    }

    public synchronized String currentText() {
        return accumulated;
    }

    public boolean isBusy() {
        return running;
    }

    static String merge(String oldText, String newText) {
        String a = oldText == null ? "" : oldText.trim();
        String b = newText == null ? "" : newText.trim();
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;
        if (b.startsWith(a)) return b;
        if (a.contains(b)) return a;
        return b.length() >= a.length() ? b : a;
    }

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT)
                .replaceAll("[.,!?;:—–-]+", " ")
                .replaceAll("\\s+", " ").trim();
    }
}
