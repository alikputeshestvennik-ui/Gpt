package com.blackbox.offline;

import android.content.Context;
import android.content.Intent;
import java.util.Locale;

/**
 * Live streaming via Vosk (fast, free). Does NOT write final History cards.
 * After stop, RecordingService queues Whisper Base for polished diary entries.
 */
public final class RealtimeTranscriber {
    public static final String LIVE_TEXT = "com.blackbox.offline.LIVE_TEXT";

    private final Context app;
    private volatile boolean running;
    private volatile boolean cancelRequested;
    private long generation;
    private Thread worker;
    private Entry entry;
    private VoskEngine vosk;
    private String accumulated = "";
    private final java.util.concurrent.ArrayBlockingQueue<short[]> queue =
            new java.util.concurrent.ArrayBlockingQueue<>(150); // ~10 с аудио @16 кГц
    private boolean commandHandled;

    public RealtimeTranscriber(Context c) {
        app = c.getApplicationContext();
    }

    public synchronized void start(Entry e) {
        if (e == null) return;
        if (running || worker != null) cancel();
        final long myGeneration = ++generation;
        entry = e;
        accumulated = "";
        running = true;
        cancelRequested = false;
        queue.clear();
        worker = new Thread(() -> workerLoop(myGeneration), "blackbox-vosk-realtime");
        worker.start();
    }

    public void feed(short[] pcm, int n) {
        if (!running || pcm == null || n <= 0) return;
        short[] copy = new short[n];
        System.arraycopy(pcm, 0, copy, 0, n);
        if (!queue.offer(copy)) {
            queue.poll();          // выбрасываем самый старый, чтобы не отставать от реалтайма
            queue.offer(copy);
        }
    }

    private void workerLoop(long myGeneration) {
        vosk = new VoskEngine(app);
        try {
            if (!vosk.isReady()) {
                broadcastLive(myGeneration, "");
                setStatusIfCurrent(myGeneration, ModelManager.voskInstalled(app)
                        ? "Vosk: ошибка загрузки"
                        : "Нет модели Vosk — импортируйте в «Модели»");
                return;
            }
            broadcastLive(myGeneration, "");
            while (true) {
                synchronized (this) {
                    if (myGeneration != generation || cancelRequested) break;
                    if (!running && queue.isEmpty()) break;
                }
                if (myGeneration != generation || cancelRequested) break;
                // Дренируем очередь пачкой: не теряем ни одного фрейма,
                // но и не дёргаем Vosk на каждые 64 мс.
                java.util.ArrayList<short[]> batch = new java.util.ArrayList<>();
                try {
                    short[] first = queue.poll(200, java.util.concurrent.TimeUnit.MILLISECONDS);
                    if (first == null) {
                        if (!running && queue.isEmpty()) break;
                        continue;
                    }
                    batch.add(first);
                    short[] more;
                    while ((more = queue.poll()) != null && batch.size() < 16) batch.add(more);
                } catch (InterruptedException ie) {
                    break;
                }
                if (myGeneration != generation || cancelRequested) break;
                int n = 0;
                for (short[] c : batch) n += c.length;
                short[] chunk = new short[n];
                int off = 0;
                for (short[] c : batch) { System.arraycopy(c, 0, chunk, off, c.length); off += c.length; }
                VoskEngine.Result result = vosk.acceptDetailed(chunk, n);
                String hyp = result.text;
                if (hyp != null && !hyp.isEmpty()) {
                    accumulated = hyp.trim();
                    broadcastLive(myGeneration, accumulated);
                    // Only finalized, non-command Vosk utterances enter the 15-min ring.
                    // Partial hypotheses stay on the live UI and system commands
                    // never become diary/ring content.
                    boolean systemCommand = EmergencySecurity.matches(app, accumulated)
                            || AutoTranscriber.looksLikeMemoryQuestion(accumulated)
                            || AutoTranscriber.looksLikeMediaRestoreCommand(accumulated)
                            || AutoTranscriber.looksLikeMediaDuckCommand(accumulated)
                            || AutoTranscriber.looksLikeStopCommand(accumulated);
                    if (result.isFinal && !systemCommand) RealtimeRingStore.appendFinal(app, accumulated);
                    // Emergency privacy command always has priority over normal voice commands.
                    if (!commandHandled && EmergencySecurity.matches(app, accumulated)) {
                        commandHandled = true;
                        try {
                            app.startService(new Intent(app, RecordingService.class)
                                    .setAction(RecordingService.EMERGENCY_WIPE));
                        } catch (Throwable ignored) {}
                        return;
                    }
                    // Hands-free: Vosk → LLM memory → push (fast path)
                    if (!commandHandled && AutoTranscriber.looksLikeMemoryQuestion(accumulated)) {
                        commandHandled = true;
                        if (entry != null) entry.handsFreeHandled = true;
                        AutoTranscriber.processHandsFreeMemoryRecall(app, accumulated);
                    }
                    if (!commandHandled && AutoTranscriber.looksLikeMediaRestoreCommand(accumulated)) {
                        commandHandled = true;
                        try {
                            app.startService(new Intent(app, RecordingService.class).setAction(RecordingService.RESTORE_MEDIA));
                            broadcastLive(myGeneration, "🔊 Звук восстановлен");
                        } catch (Throwable ignored) {}
                    }
                    if (!commandHandled && AutoTranscriber.looksLikeMediaDuckCommand(accumulated)) {
                        commandHandled = true;
                        try {
                            app.startService(new Intent(app, RecordingService.class).setAction(RecordingService.DUCK_MEDIA));
                            broadcastLive(myGeneration, "🔇 Медиа приглушено на 10 минут");
                        } catch (Throwable ignored) {}
                    }
                    if (!commandHandled && AutoTranscriber.looksLikeStopCommand(accumulated)) {
                        commandHandled = true;
                        try {
                            app.startService(new Intent(app, RecordingService.class).setAction(RecordingService.STOP));
                        } catch (Throwable ignored) {}
                    }
                }
            }
            // Final partial flush when stopping this utterance
            if (myGeneration == generation && !cancelRequested) {
                String fin = vosk.flush();
                if (fin != null && !fin.isEmpty()) {
                    accumulated = fin.trim();
                    broadcastLive(myGeneration, accumulated);
                    RealtimeRingStore.appendFinal(app, accumulated);
                }
            }
        } finally {
            if (vosk != null) {
                vosk.release();
                vosk = null;
            }
            synchronized (this) {
                if (myGeneration == generation) {
                    if (Thread.currentThread() == worker) worker = null;
                    entry = null;
                } else if (Thread.currentThread() == worker) {
                    worker = null;
                }
            }
        }
    }

    private void broadcastLive(long myGeneration, String text) {
        if (myGeneration != generation) return;
        try {
            Intent live = new Intent(LIVE_TEXT).setPackage(app.getPackageName());
            live.putExtra("text", text == null ? "" : text);
            app.sendBroadcast(live);
        } catch (Throwable ignored) {}
    }

    private void setStatusIfCurrent(long myGeneration, String status) {
        synchronized (this) {
            if (myGeneration != generation || entry == null) return;
            entry.status = status;
            new EntryStore(app).replace(entry);
        }
        app.sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
    }

    public synchronized void publish() {
        // Vosk text is never the final diary card — Whisper finalizes after stop.
    }

    public synchronized boolean isPublished() {
        return false;
    }

    public synchronized void finish() {
        running = false;
        if (worker != null) worker.interrupt();
    }

    public synchronized void cancel() {
        running = false;
        cancelRequested = true;
        generation++;
        queue.clear();
        Thread t = worker;
        if (t != null) t.interrupt();
        entry = null;
        try {
            Intent live = new Intent(LIVE_TEXT).setPackage(app.getPackageName());
            live.putExtra("text", "");
            app.sendBroadcast(live);
        } catch (Throwable ignored) {}
    }

    public synchronized void stop() {
        finish();
    }

    public synchronized String currentText() {
        return accumulated;
    }

    public boolean isBusy() {
        return running;
    }

    static String merge(String oldText, String newText) {
        String a = oldText == null ? "" : oldText.trim();
        String b = newText == null ? "" : newText.trim();
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;
        if (b.startsWith(a)) return b;
        if (a.contains(b)) return a;
        return b.length() >= a.length() ? b : a;
    }

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT)
                .replaceAll("[.,!?;:—–-]+", " ")
                .replaceAll("\\s+", " ").trim();
    }
}
