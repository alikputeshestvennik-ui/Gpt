package com.blackbox.offline;

import android.animation.ValueAnimator;
import android.media.MediaPlayer;
import java.io.File;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.app.*;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.text.TextUtils;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.os.*;
import android.util.TypedValue;
import android.view.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Flagship Monolith Navigation Controller (Single Activity Architecture).
 * Features:
 * - Ultra-responsive Bottom Navigation Bar with glowing amber active indicator
 * - Brutalist Black Screen with classic Blackbox Monolith Logo button (animated pulse/scale)
 * - Native tabs: [Главная] [История] [Сводка] [Поиск] [Модели]
 * - Direct playback suppression in History
 * - Stealth copyright "alim" in Models view
 */
public class MainActivity extends Activity {
    private FrameLayout contentFrame;
    private ImageView logoView;
    private TextView statusDescView;
    private TextView statusBadgeView;
    private TextView livePreviewView;
    private TextView liveDotsView;
    private ObjectAnimator livePulse;
    private final Handler liveAnimHandler = new Handler(Looper.getMainLooper());
    private int liveDotsPhase = 0;
    private boolean liveAnimRunning = false;

    // 3D-style live visualizer under logo
    private LinearLayout visualizerRow;
    private View[] vizBars;
    private ValueAnimator[] vizAnims;
    private boolean vizRunning = false;

    // Bottom Bar Icons & Labels
    private ImageView[] tabIcons;
    private LinearLayout[] tabButtons;
    private View[] tabDots;
    private int currentTab = 0; // 0: Home, 1: History, 2: Summary, 3: Search, 4: Models

    private static final int REQ_IMPORT_WHISPER = 101;
    private static final int REQ_IMPORT_LLM = 102;
    private static final int REQ_IMPORT_VOSK = 103;
    private MediaPlayer player;
    private Button playBtn;

    private boolean isRecording = false;
    private boolean speakerMediaActive = false;
    private boolean mediaDucked = false;
    private long mediaDuckUntil = 0L;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            isRecording = i.getBooleanExtra("active", isRecording);
            updateHomeUi();
        }
    };

    private final BroadcastReceiver audioStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            speakerMediaActive = i.getBooleanExtra("speaker_media", false);
            mediaDucked = i.getBooleanExtra("ducked", false);
            mediaDuckUntil = i.getLongExtra("duck_until", 0L);
            updateHomeUi();
        }
    };

    private final BroadcastReceiver liveTextReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String text = i.getStringExtra("text");
            if (livePreviewView == null) return;
            if (text == null) text = "";
            text = AutoTranscriber.cleanHallucinations(text).trim();
            if (text.isEmpty() || text.length() < 4) {
                if (isRecording && mediaDucked) livePreviewView.setText("приглушено");
                else if (isRecording && speakerMediaActive) livePreviewView.setText("динамики воспроизводят медиа…");
                else livePreviewView.setText(isRecording ? "слушаю…" : "");
            } else {
                // keep last ~3 lines visually compact
                String[] words = text.split("\\s+");
                if (words.length > 36) {
                    StringBuilder sb = new StringBuilder();
                    for (int w = words.length - 36; w < words.length; w++) {
                        if (sb.length() > 0) sb.append(' ');
                        sb.append(words[w]);
                    }
                    text = "…" + sb;
                }
                livePreviewView.setText(text);
            }
            if (isRecording) startLiveAnim();
            else stopLiveAnim();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Warm Whisper during app startup so the first realtime window avoids
        // model/context initialization latency.
        new Thread(() -> LocalAiEngine.warm(this), "blackbox-whisper-warm-ui").start();
        RetentionManager.clean(this);
        resumeStuckTranscriptions();

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, new IntentFilter(RecordingService.STATE), Context.RECEIVER_NOT_EXPORTED);
            registerReceiver(liveTextReceiver, new IntentFilter(RealtimeTranscriber.LIVE_TEXT), Context.RECEIVER_NOT_EXPORTED);
            registerReceiver(audioStateReceiver, new IntentFilter(RecordingService.AUDIO_STATE), Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stateReceiver, new IntentFilter(RecordingService.STATE));
            registerReceiver(liveTextReceiver, new IntentFilter(RealtimeTranscriber.LIVE_TEXT));
            registerReceiver(audioStateReceiver, new IntentFilter(RecordingService.AUDIO_STATE));
        }

        speakerMediaActive = RecordingService.speakerMediaActive;
        mediaDucked = RecordingService.mediaDucked;
        mediaDuckUntil = RecordingService.mediaDuckUntil;
        renderMainShell();
        switchTab(0);
    }

    // Записи, зависшие в «Расшифровка…»/«В очереди» после смерти процесса,
    // снова ставим в очередь — иначе они висят вечно.
    private void resumeStuckTranscriptions() {
        try {
            List<Entry> all = new EntryStore(this).all();
            for (Entry e : all) {
                if (e.transcript != null && !e.transcript.isEmpty()) continue;
                String st = e.status == null ? "" : e.status;
                if (st.contains("Расшифровка") || st.contains("В очереди")) {
                    e.status = "В очереди";
                    new EntryStore(this).replace(e);
                    AutoTranscriber.enqueue(this, e);
                }
            }
        } catch (Exception ignored) {}
    }

    private void renderMainShell() {
        RelativeLayout root = new RelativeLayout(this);
        root.setBackgroundColor(0xFF000000); // Obsidian True Black

        // Content Area (Top)
        contentFrame = new FrameLayout(this);
        contentFrame.setId(View.generateViewId());
        RelativeLayout.LayoutParams clp = new RelativeLayout.LayoutParams(-1, -1);
        clp.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        root.addView(contentFrame, clp);

        // Bottom Navigation Bar — Floating layered glass island (icon-only, no selection dots)
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setId(View.generateViewId());
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER);

        GradientDrawable glassBg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xE01A1E28, 0xD10E1016});
        glassBg.setCornerRadius(dp(26));
        glassBg.setStroke(dp(1), 0x28FFFFFF);
        bottomBar.setBackground(glassBg);
        bottomBar.setPadding(dp(8), dp(8), dp(8), dp(8));
        if (Build.VERSION.SDK_INT >= 28) {
            bottomBar.setElevation(dp(10));
            bottomBar.setOutlineAmbientShadowColor(0xFF0A0600);
            bottomBar.setOutlineSpotShadowColor(0xFF1A0A00);
        }

        RelativeLayout.LayoutParams blp = new RelativeLayout.LayoutParams(-1, dp(58));
        blp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        blp.leftMargin = dp(16);
        blp.rightMargin = dp(16);
        blp.bottomMargin = dp(14);
        root.addView(bottomBar, blp);

        // Make contentFrame sit above bottomBar
        clp.addRule(RelativeLayout.ABOVE, bottomBar.getId());

        // System window insets: content below status bar, bar above nav gestures
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            contentFrame.setPadding(0, insets.getSystemWindowInsetTop(), 0, 0);
            blp.bottomMargin = dp(12) + insets.getSystemWindowInsetBottom();
            bottomBar.setLayoutParams(blp);
            return insets;
        });

        // Setup 5 Bottom Tabs (icons only) — no dots; active state uses soft amber pill + icon scale
        String[] icons = new String[]{"ic_nav_home", "ic_nav_history", "ic_nav_summary", "ic_nav_search", "ic_nav_models"};

        tabIcons = new ImageView[5];
        tabButtons = new LinearLayout[5];
        tabDots = new View[5]; // kept for binary compat but unused

        for (int i = 0; i < 5; i++) {
            final int tabIndex = i;
            LinearLayout btn = new LinearLayout(this);
            btn.setOrientation(LinearLayout.VERTICAL);
            btn.setGravity(Gravity.CENTER);
            btn.setClickable(true);
            btn.setFocusable(true);
            btn.setPadding(dp(6), dp(6), dp(6), dp(6));

            GradientDrawable rippleMask = new GradientDrawable();
            rippleMask.setCornerRadius(dp(16));
            rippleMask.setColor(0xFFFFFFFF);
            btn.setForeground(new RippleDrawable(
                    ColorStateList.valueOf(0x33F47721), null, rippleMask));

            ImageView iv = new ImageView(this);
            int resId = getResources().getIdentifier(icons[i], "drawable", getPackageName());
            if (resId != 0) iv.setImageResource(resId);
            btn.addView(iv, new LinearLayout.LayoutParams(dp(22), dp(22)));

            tabIcons[i] = iv;
            tabButtons[i] = btn;
            tabDots[i] = new View(this); // placeholder, never shown
            btn.setOnClickListener(v -> switchTab(tabIndex));
            bottomBar.addView(btn, new LinearLayout.LayoutParams(0, -1, 1.0f));
        }

        setContentView(root);
    }

    private void switchTab(int index) {
        currentTab = index;

        // Update Bottom Bar: soft amber pill behind active icon, no dots
        for (int i = 0; i < 5; i++) {
            boolean active = (i == index);
            int activeColor = 0xFFF47721;
            int inactiveColor = 0xFF5D6574;

            tabIcons[i].setColorFilter(active ? activeColor : inactiveColor);
            if (active) {
                GradientDrawable pill = new GradientDrawable();
                pill.setCornerRadius(dp(14));
                pill.setColor(0x22F47721);
                pill.setStroke(dp(1), 0x33F47721);
                tabButtons[i].setBackground(pill);
                tabIcons[i].setScaleX(1.08f);
                tabIcons[i].setScaleY(1.08f);
            } else {
                tabButtons[i].setBackground(null);
                tabIcons[i].setScaleX(1f);
                tabIcons[i].setScaleY(1f);
            }
        }

        // Render tab content inside contentFrame
        contentFrame.removeAllViews();
        contentFrame.post(() -> {
            if (contentFrame.getChildCount() > 0) {
                View v = contentFrame.getChildAt(0);
                v.setAlpha(0f);
                v.setTranslationY(dp(14));
                v.animate().alpha(1f).translationY(0f).setDuration(210).start();
            }
        });

        switch (index) {
            case 0:
                renderHomeTab();
                break;
            case 1:
                renderHistoryTab();
                break;
            case 2:
                renderSummaryTab();
                break;
            case 3:
                renderSearchTab();
                break;
            case 4:
                renderModelsTab();
                break;
        }
    }

    // ==========================================
    // TAB 0: HOME SCREEN (BRUTALIST LOGO BUTTON)
    // ==========================================
    private void renderHomeTab() {
        LinearLayout home = new LinearLayout(this);
        home.setOrientation(LinearLayout.VERTICAL);
        home.setGravity(Gravity.CENTER);
        home.setPadding(dp(24), dp(36), dp(24), dp(20));

        // Brand title: vector open-A (no crossbar) + pixel dissolve on trailing letters
        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setOrientation(LinearLayout.HORIZONTAL);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView bl = new TextView(this);
        bl.setText("BL");
        bl.setTextColor(0xFFFFFFFF);
        bl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        bl.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        bl.setLetterSpacing(0.04f);
        brandRow.addView(bl);

        ImageView openA = new ImageView(this);
        int aRes = getResources().getIdentifier("ic_brand_a_open", "drawable", getPackageName());
        if (aRes != 0) openA.setImageResource(aRes);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(22), dp(26));
        alp.leftMargin = dp(1);
        alp.rightMargin = dp(1);
        alp.bottomMargin = dp(1);
        brandRow.addView(openA, alp);

        TextView ck = new TextView(this);
        ck.setText("CK");
        ck.setTextColor(0xFFFFFFFF);
        ck.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        ck.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        ck.setLetterSpacing(0.04f);
        brandRow.addView(ck);

        // Pixel dissolve tail: B O X rendered as successive fading blocks
        String[] pixels = {"B", "O", "X"};
        int[] alphas = {0xE6, 0x99, 0x55};
        for (int p = 0; p < pixels.length; p++) {
            TextView px = new TextView(this);
            px.setText(pixels[p]);
            px.setTextColor((alphas[p] << 24) | 0x00FFFFFF);
            px.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26 - p);
            px.setTypeface(Typeface.create("monospace", Typeface.BOLD));
            px.setLetterSpacing(0.08f);
            if (p > 0) {
                LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-2, -2);
                plp.leftMargin = dp(-2);
                brandRow.addView(px, plp);
            } else {
                brandRow.addView(px);
            }
        }
        home.addView(brandRow);

        // Premium subtitle — elegant tracking under the monolith title
        TextView subtitleRu = new TextView(this);
        subtitleRu.setText("чёрный ящик");
        subtitleRu.setTextColor(0xFF9AA3B2);
        subtitleRu.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        subtitleRu.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        subtitleRu.setLetterSpacing(0.32f);
        subtitleRu.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-2, -2);
        subLp.topMargin = dp(6);
        home.addView(subtitleRu, subLp);

        statusBadgeView = new TextView(this);
        statusBadgeView.setText("Автономный аудио-архив");
        statusBadgeView.setTextColor(UI.COLOR_TEXT_MUTED);
        statusBadgeView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        statusBadgeView.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        statusBadgeView.setPadding(dp(14), dp(7), dp(14), dp(7));
        statusBadgeView.setBackground(UI.shape(UI.COLOR_SURFACE_ELEVATED, UI.COLOR_BORDER, 22, this));
        LinearLayout.LayoutParams sblp = new LinearLayout.LayoutParams(-2, -2);
        sblp.topMargin = dp(14);
        home.addView(statusBadgeView, sblp);

        // Huge interactive animated Logo Button — elevated with soft warm glow
        FrameLayout logoContainer = new FrameLayout(this);
        int containerSize = dp(160);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(containerSize, containerSize);
        clp.topMargin = dp(36);
        clp.bottomMargin = dp(6);
        logoContainer.setLayoutParams(clp);
        if (Build.VERSION.SDK_INT >= 28) {
            logoContainer.setElevation(dp(12));
            logoContainer.setOutlineAmbientShadowColor(0xFF1A0A00);
            logoContainer.setOutlineSpotShadowColor(0xFF3A1400);
        }

        logoView = new ImageView(this);
        logoView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logoView.setClickable(true);
        logoView.setFocusable(true);
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(-1, -1);
        logoContainer.addView(logoView, flp);

        logoView.setOnClickListener(v -> toggleRecordingAnimated());
        home.addView(logoContainer);

        // ═══ 3D Live Visualizer ═══
        // Frame with soft glow disk + perspective bars that pulse & tilt in depth
        FrameLayout vizContainer = new FrameLayout(this);
        LinearLayout.LayoutParams vclp = new LinearLayout.LayoutParams(dp(200), dp(64));
        vclp.topMargin = dp(2);
        vclp.bottomMargin = dp(6);
        vizContainer.setLayoutParams(vclp);

        // Soft ambient glow disk (behind bars)
        View glowDisk = new View(this);
        GradientDrawable glowShape = new GradientDrawable();
        glowShape.setShape(GradientDrawable.OVAL);
        glowShape.setColors(new int[]{0x44F47721, 0x005EC8D8});
        glowShape.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        glowShape.setGradientRadius(dp(90));
        glowDisk.setBackground(glowShape);
        glowDisk.setAlpha(0f);
        FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams(dp(160), dp(40));
        glp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM;
        glp.bottomMargin = dp(4);
        vizContainer.addView(glowDisk, glp);

        visualizerRow = new LinearLayout(this);
        visualizerRow.setOrientation(LinearLayout.HORIZONTAL);
        visualizerRow.setGravity(Gravity.CENTER | Gravity.BOTTOM);
        visualizerRow.setPadding(dp(6), 0, dp(6), 0);
        // Enable 3D camera distance for stronger perspective
        if (Build.VERSION.SDK_INT >= 21) {
            visualizerRow.setCameraDistance(dp(2400));
        }
        int barCount = 11;
        vizBars = new View[barCount];
        vizAnims = new ValueAnimator[barCount];
        // Symmetric mountain profile for 3D depth illusion
        int[] baseHeights = {8, 14, 22, 32, 42, 52, 42, 32, 22, 14, 8};
        int[] elevs = {1, 2, 3, 4, 6, 8, 6, 4, 3, 2, 1};
        for (int i = 0; i < barCount; i++) {
            View bar = new View(this);
            GradientDrawable barShape = new GradientDrawable();
            barShape.setCornerRadius(dp(4));
            // Dual-tone: warm amber base → cool live tip
            barShape.setColors(new int[]{0xFFF47721, 0xFFFFB57F, 0xFF5EC8D8});
            barShape.setOrientation(GradientDrawable.Orientation.BOTTOM_TOP);
            bar.setBackground(barShape);
            int h = dp(baseHeights[i]);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(6), h);
            blp.leftMargin = dp(2);
            blp.rightMargin = dp(2);
            blp.gravity = Gravity.BOTTOM;
            visualizerRow.addView(bar, blp);
            vizBars[i] = bar;
            if (Build.VERSION.SDK_INT >= 28) {
                bar.setElevation(dp(elevs[i]));
                bar.setOutlineAmbientShadowColor(0xFF1A0A00);
                bar.setOutlineSpotShadowColor(0xFF3A1400);
            }
            bar.setAlpha(0.22f);
            bar.setScaleY(0.30f);
            // pivot at bottom so scale grows upward
            bar.setPivotY(h);
        }
        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(-1, -1);
        vizContainer.addView(visualizerRow, rlp);
        // Keep glow reference for live pulse
        vizContainer.setTag(glowDisk);
        home.addView(vizContainer);

        statusDescView = new TextView(this);
        statusDescView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        statusDescView.setTextColor(0xFF8E95A2);
        statusDescView.setGravity(Gravity.CENTER);
        statusDescView.setLineSpacing(dp(3), 1.0f);
        home.addView(statusDescView);

        // Live preview — layered live card style
        livePreviewView = new TextView(this);
        livePreviewView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        livePreviewView.setTextColor(0xFFC8D0DC);
        livePreviewView.setGravity(Gravity.CENTER);
        livePreviewView.setMaxLines(3);
        livePreviewView.setEllipsize(TextUtils.TruncateAt.END);
        livePreviewView.setLineSpacing(dp(2), 1.08f);
        livePreviewView.setPadding(dp(18), dp(16), dp(18), dp(14));
        livePreviewView.setText("");
        livePreviewView.setClickable(true);
        livePreviewView.setFocusable(true);
        GradientDrawable liveBg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF12181E, 0xFF0C1014});
        liveBg.setCornerRadius(dp(16));
        liveBg.setStroke(dp(1), 0xFF1F5158);
        livePreviewView.setBackground(liveBg);
        if (Build.VERSION.SDK_INT >= 28) {
            livePreviewView.setElevation(dp(4));
            livePreviewView.setOutlineAmbientShadowColor(0xFF0A2030);
            livePreviewView.setOutlineSpotShadowColor(0xFF0A2030);
        }
        livePreviewView.setOnClickListener(v -> {
            try {
                startActivity(new Intent(this, RealtimeRingActivity.class));
                overridePendingTransition(0, 0);
            } catch (Exception ignored) {}
        });
        LinearLayout.LayoutParams lplp = new LinearLayout.LayoutParams(-1, -2);
        lplp.topMargin = dp(12);
        home.addView(livePreviewView, lplp);

        liveDotsView = new TextView(this);
        liveDotsView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        liveDotsView.setTextColor(0xFFFFA25F);
        liveDotsView.setGravity(Gravity.CENTER);
        liveDotsView.setPadding(0, dp(2), 0, 0);
        liveDotsView.setText("");
        home.addView(liveDotsView);

        TextView ringHint = new TextView(this);
        ringHint.setText("тап по тексту → лента 15 мин");
        ringHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        ringHint.setTextColor(0xFF4A5260);
        ringHint.setGravity(Gravity.CENTER);
        ringHint.setLetterSpacing(0.06f);
        ringHint.setPadding(0, dp(8), 0, 0);
        home.addView(ringHint);

        if (!ModelManager.installed(this, ModelManager.WHISPER)) {
            TextView warn = new TextView(this);
            warn.setText("⚠ Whisper не установлен — импортируйте модель во вкладке «Модели»");
            warn.setTextColor(0xFFFFA25F);
            warn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            warn.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-1, -2);
            wlp.topMargin = dp(14);
            home.addView(warn, wlp);
        }

        contentFrame.addView(home, new FrameLayout.LayoutParams(-1, -1));

        isRecording = RecordingService.isRecordingActive;
        updateHomeUi();
    }

    private void toggleRecordingAnimated() {
        // Animate scale bounce
        ValueAnimator anim = ValueAnimator.ofFloat(1.0f, 0.90f, 1.05f, 1.0f);
        anim.setDuration(350);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        anim.addUpdateListener(animation -> {
            float s = (float) animation.getAnimatedValue();
            if (logoView != null) {
                logoView.setScaleX(s);
                logoView.setScaleY(s);
            }
        });
        anim.start();

        if (isRecording) {
            startService(new Intent(this, RecordingService.class).setAction(RecordingService.STOP));
        } else {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                startRecordingService();
            } else {
                requestPermissions(new String[]{
                        android.Manifest.permission.RECORD_AUDIO,
                        Build.VERSION.SDK_INT >= 33 ? android.Manifest.permission.POST_NOTIFICATIONS : android.Manifest.permission.RECORD_AUDIO
                }, 42);
            }
        }
    }

    private void startRecordingService() {
        Intent i = new Intent(this, RecordingService.class).setAction(RecordingService.START);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
        isRecording = true;
        updateHomeUi();
    }

    private void updateHomeUi() {
        if (logoView == null || statusDescView == null) return;

        if (isRecording) {
            int logoRes = getResources().getIdentifier("blackbox_mark", "drawable", getPackageName());
            if (logoRes != 0) logoView.setImageResource(logoRes);
            if (mediaDucked) {
                statusBadgeView.setText("●  Приглушено");
                statusBadgeView.setTextColor(0xFFFFA25F);
                statusBadgeView.setBackground(UI.shape(0x22FF8A3D, 0xFF5A321F, 20, this));
                statusDescView.setText("Медиа приглушено на 10 минут.\nСкажите «Блэкбокс, стоп» для завершения.");
            } else if (speakerMediaActive) {
                statusBadgeView.setText("●  Динамики заняты");
                statusBadgeView.setTextColor(0xFF5EC8D8);
                statusBadgeView.setBackground(UI.shape(0x2230B7C8, 0xFF1D4D55, 20, this));
                statusDescView.setText("Динамики воспроизводят медиа…\nСкажите «отключи микрофон» — приглушить на 10 минут.");
            } else {
                statusBadgeView.setText("●  Слушаю в фоне");
                statusBadgeView.setTextColor(0xFFEF4444);
                statusBadgeView.setBackground(UI.shape(0x22EF4444, 0xFF5A1F1F, 20, this));
                statusDescView.setText("Фоновая запись активна.\nСкажите «Блэкбокс, стоп» или «отключи микрофон».");
            }
            if (livePreviewView != null) {
                if (mediaDucked) livePreviewView.setText("приглушено");
                else if (speakerMediaActive) livePreviewView.setText("динамики воспроизводят медиа…");
                else if (livePreviewView.getText() == null || livePreviewView.getText().length() == 0) livePreviewView.setText("слушаю…");
            }
            startLiveAnim();
        } else {
            int monoRes = getResources().getIdentifier("blackbox_mark_mono", "drawable", getPackageName());
            if (monoRes != 0) logoView.setImageResource(monoRes);
            statusBadgeView.setText("Запись остановлена");
            statusBadgeView.setTextColor(UI.COLOR_TEXT_MUTED);
            statusBadgeView.setBackground(UI.shape(UI.COLOR_SURFACE_ELEVATED, UI.COLOR_BORDER, 20, this));
            statusDescView.setText("Коснитесь логотипа для включения\nфонового прослушивания.");
            if (livePreviewView != null) livePreviewView.setText("");
            if (liveDotsView != null) liveDotsView.setText("");
            stopLiveAnim();
        }
    }

    private void startLiveAnim() {
        if (liveAnimRunning) return;
        liveAnimRunning = true;
        // breathing alpha on preview text
        if (livePreviewView != null) {
            if (livePulse != null) livePulse.cancel();
            livePulse = ObjectAnimator.ofFloat(livePreviewView, View.ALPHA, 0.30f, 1.0f);
            livePulse.setDuration(1100);
            livePulse.setRepeatMode(ValueAnimator.REVERSE);
            livePulse.setRepeatCount(ValueAnimator.INFINITE);
            livePulse.start();
        }
        liveDotsPhase = 0;
        liveAnimHandler.removeCallbacksAndMessages(null);
        liveAnimHandler.post(liveDotsRunnable);
        startVisualizer();
    }

    private void stopLiveAnim() {
        liveAnimRunning = false;
        liveAnimHandler.removeCallbacksAndMessages(null);
        if (livePulse != null) {
            livePulse.cancel();
            livePulse = null;
        }
        if (livePreviewView != null) livePreviewView.setAlpha(1f);
        if (liveDotsView != null) liveDotsView.setText("");
        stopVisualizer();
    }

    private void startVisualizer() {
        if (vizBars == null || vizRunning) return;
        vizRunning = true;

        // Fade in ambient glow disk
        if (visualizerRow != null && visualizerRow.getParent() instanceof FrameLayout) {
            Object tag = ((FrameLayout) visualizerRow.getParent()).getTag();
            if (tag instanceof View) {
                ((View) tag).animate().alpha(0.85f).setDuration(400).start();
            }
        }

        // Whole row slight continuous Y-tilt for floating 3D presence
        if (visualizerRow != null && Build.VERSION.SDK_INT >= 21) {
            visualizerRow.setCameraDistance(dp(2400));
            ObjectAnimator tilt = ObjectAnimator.ofFloat(visualizerRow, "rotationY", -8f, 8f);
            tilt.setDuration(2800);
            tilt.setRepeatMode(ValueAnimator.REVERSE);
            tilt.setRepeatCount(ValueAnimator.INFINITE);
            tilt.setInterpolator(new AccelerateDecelerateInterpolator());
            tilt.start();
            visualizerRow.setTag(tilt); // store to cancel later
        }

        for (int i = 0; i < vizBars.length; i++) {
            final View bar = vizBars[i];
            if (bar == null) continue;
            bar.setAlpha(1f);
            if (vizAnims[i] != null) vizAnims[i].cancel();

            // Staggered organic pulse — different phase & amplitude
            float minS = 0.32f + (i % 3) * 0.05f;
            float maxS = 0.92f + (i % 5) * 0.06f;
            if (maxS > 1.25f) maxS = 1.25f;

            ValueAnimator va = ValueAnimator.ofFloat(minS, maxS);
            va.setDuration(320 + (i * 47) % 180);
            va.setRepeatMode(ValueAnimator.REVERSE);
            va.setRepeatCount(ValueAnimator.INFINITE);
            va.setInterpolator(new AccelerateDecelerateInterpolator());
            va.setStartDelay(i * 35L);

            final int idx = i;
            final int center = vizBars.length / 2;
            va.addUpdateListener(a -> {
                float s = (float) a.getAnimatedValue();
                bar.setScaleY(s);
                // Stronger 3D: rotationX + slight rotationZ for depth parallax
                if (Build.VERSION.SDK_INT >= 21) {
                    float dist = Math.abs(idx - center);
                    bar.setRotationX((1f - s) * (18f - dist * 1.5f) * ((idx % 2 == 0) ? 1f : -1f));
                    bar.setRotation((1f - s) * 3f * ((idx < center) ? -1f : 1f));
                    // Dynamic elevation pulse
                    if (Build.VERSION.SDK_INT >= 28) {
                        bar.setElevation(dp(2) + s * dp(8));
                    }
                }
            });
            va.start();
            vizAnims[i] = va;
        }
    }

    private void stopVisualizer() {
        vizRunning = false;
        if (vizBars == null) return;

        // Fade out glow
        if (visualizerRow != null && visualizerRow.getParent() instanceof FrameLayout) {
            Object tag = ((FrameLayout) visualizerRow.getParent()).getTag();
            if (tag instanceof View) {
                ((View) tag).animate().alpha(0f).setDuration(350).start();
            }
            // Cancel row tilt
            Object tiltTag = visualizerRow.getTag();
            if (tiltTag instanceof ObjectAnimator) {
                ((ObjectAnimator) tiltTag).cancel();
                visualizerRow.setRotationY(0f);
            }
        }

        for (int i = 0; i < vizBars.length; i++) {
            if (vizAnims[i] != null) {
                vizAnims[i].cancel();
                vizAnims[i] = null;
            }
            View bar = vizBars[i];
            if (bar != null) {
                bar.animate()
                        .scaleY(0.30f)
                        .alpha(0.22f)
                        .rotationX(0f)
                        .rotation(0f)
                        .setDuration(320)
                        .start();
                if (Build.VERSION.SDK_INT >= 28) {
                    bar.setElevation(dp(1));
                }
            }
        }
    }

    private final Runnable liveDotsRunnable = new Runnable() {
        @Override public void run() {
            if (!liveAnimRunning || liveDotsView == null) return;
            String[] frames = {"● ○ ○", "○ ● ○", "○ ○ ●"};
            liveDotsView.setText(frames[liveDotsPhase % 3]);
            liveDotsPhase++;
            liveAnimHandler.postDelayed(this, 380);
        }
    };

    // ==========================================
    // TAB 1: HISTORY (WITH AUDIO GATE ON PLAY)
    // ==========================================
    private void renderHistoryTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int padH = dp(18);
        int padV = dp(22);
        content.setPadding(padH, padV, padH, dp(96));

        // Header row: title left + realtime ring button top-right
        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("История событий");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1f);
        headerRow.addView(title, tlp);

        // Top-right design button → 15-min realtime ring (works even when listening is off)
        Button ringBtn = new Button(this);
        ringBtn.setText("◎  Лента");
        ringBtn.setTextColor(UI.COLOR_LIVE);
        ringBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        ringBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        ringBtn.setAllCaps(false);
        GradientDrawable ringBg = new GradientDrawable();
        ringBg.setCornerRadius(dp(16));
        ringBg.setColor(0x1A5EC8D8);
        ringBg.setStroke(dp(1), UI.COLOR_LIVE_BORDER);
        ringBtn.setBackground(new RippleDrawable(
                ColorStateList.valueOf(0x405EC8D8), ringBg, null));
        int rPadH = dp(14);
        int rPadV = dp(9);
        ringBtn.setPadding(rPadH, rPadV, rPadH, rPadV);
        if (Build.VERSION.SDK_INT >= 28) {
            ringBtn.setElevation(dp(4));
            ringBtn.setOutlineAmbientShadowColor(0xFF0A2030);
            ringBtn.setOutlineSpotShadowColor(0xFF0A2030);
        }
        UI.attachPressScale(ringBtn);
        ringBtn.setOnClickListener(v -> {
            try {
                startActivity(new Intent(this, RealtimeRingActivity.class));
                overridePendingTransition(0, 0);
            } catch (Exception ignored) {}
        });
        headerRow.addView(ringBtn, new LinearLayout.LayoutParams(-2, -2));

        content.addView(headerRow);

        ArrayList<Entry> allEntries = new EntryStore(this).all();
        ArrayList<Entry> entries = new ArrayList<>();
        int pending = 0;
        for (Entry e : allEntries) {
            String clean0 = AutoTranscriber.cleanHallucinations(e.transcript);
            boolean ready = clean0 != null && clean0.trim().length() >= 3
                    && (e.status == null || !e.status.contains("Расшифр") && !e.status.contains("очеред")
                        && !e.status.contains("Обработка") && !e.status.contains("Финальн"));
            // Prefer explicit Готово; also accept any polished text without intermediate status
            if (clean0 != null && clean0.trim().length() >= 3
                    && (e.status == null || "Готово".equals(e.status)
                        || (!e.status.contains("Расшифр") && !e.status.contains("очеред")
                            && !e.status.contains("Обработка") && !e.status.contains("Финальн")
                            && !e.status.contains("Нет модели")))) {
                entries.add(e);
            } else if (e.status != null && (e.status.contains("Расшифр") || e.status.contains("очеред")
                    || e.status.contains("Обработка") || e.status.contains("Финальн"))) {
                pending++;
            } else if (clean0 == null || clean0.trim().length() < 3) {
                pending++;
            }
        }

        TextView countView = new TextView(this);
        String countText = "Готовых фрагментов: " + entries.size();
        if (pending > 0) countText += " · ещё обрабатывается " + pending;
        countView.setText(countText);
        countView.setTextColor(0xFF8E95A2);
        countView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        countView.setPadding(0, dp(3), 0, dp(16));
        content.addView(countView);

        if (entries.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(pending > 0
                    ? "Архив дополняется. Готовых карточек пока нет — дождитесь обработки."
                    : "В архиве пока нет записей. Включите запись на главном экране или часах.");
            empty.setTextColor(0xFF5D6574);
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            empty.setPadding(0, dp(40), 0, 0);
            content.addView(empty);
        } else {
            for (Entry e : entries) {
                String clean = AutoTranscriber.cleanHallucinations(e.transcript);
                boolean hasText = clean.length() >= 2;

                LinearLayout card = UI.createCard(this);

                LinearLayout meta = new LinearLayout(this);
                meta.setOrientation(LinearLayout.HORIZONTAL);
                meta.setGravity(Gravity.CENTER_VERTICAL);

                TextView timeBadge = UI.badge(this, e.created, 0xFFFFA25F, 0xFF221710);
                meta.addView(timeBadge);

                TextView catBadge = UI.badge(this, e.category, Color.WHITE, 0xFF191D24);
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
                clp.leftMargin = dp(8);
                meta.addView(catBadge, clp);

                card.addView(meta);

                TextView tv = new TextView(this);
                if (hasText) {
                    tv.setText(QwenEngine.polishSpokenRussian(clean));
                    tv.setTextColor(0xFFF1F3F7);
                } else {
                    String st = (e.status == null || e.status.isEmpty()) ? "В очереди" : e.status;
                    boolean modelMissing = !ModelManager.installed(this, ModelManager.WHISPER);
                    tv.setText(modelMissing
                            ? st + "\nИмпортируйте модель Whisper во вкладке «Модели», чтобы расшифровка работала."
                            : st);
                    tv.setTextColor(0xFF8E95A2);
                }
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
                tv.setLineSpacing(dp(3), 1.0f);
                tv.setPadding(0, dp(10), 0, dp(12));
                card.addView(tv);

                LinearLayout actRow = new LinearLayout(this);
                actRow.setOrientation(LinearLayout.HORIZONTAL);

                File af = (e.path != null && !e.path.isEmpty()) ? new File(e.path) : null;
                if (af != null && af.isFile()) {
                    Button listenBtn = UI.secondaryButton(this, "Слушать");
                    listenBtn.setOnClickListener(v -> togglePlayback(listenBtn, af));
                    actRow.addView(listenBtn);
                }

                Button copyBtn = UI.secondaryButton(this, "Копировать");
                copyBtn.setOnClickListener(v -> UI.copyToClipboard(this, "Запись", clean));
                actRow.addView(copyBtn);

                Button delBtn = UI.secondaryButton(this, "Удалить");
                delBtn.setTextColor(0xFFEF4444);
                LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-2, -2);
                dlp.leftMargin = dp(8);
                delBtn.setOnClickListener(v -> {
                    new EntryStore(this).delete(e.id);
                    switchTab(1);
                });
                                    if (hasText) {
                        actRow.addView(delBtn, dlp);
                    }

                if (hasText) {
                    TextView improve = new TextView(this);
                    improve.setText("✨ Улучшить текст (LLM)");
                    improve.setTextColor(0xFF8E95A2);
                    improve.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                    improve.setPadding(0, dp(8), 0, 0);
                    improve.setOnClickListener(v -> {
                        improve.setText("Нейро-ядро обрабатывает…");
                        new Thread(() -> {
                            int maxTok = Math.max(80, Math.min(256, clean.length() / 3));
                            String prompt = "Вот автоматическая расшифровка речи:\n«" + clean + "»\n\n"
                                    + "Приведи её в порядок: исправь очевидные ошибки распознавания слов, "
                                    + "расставь знаки препинания, убери слова-паразиты и ложные повторы. "
                                    + "Сохрани смысл, имена и термины без изменений, ничего не добавляй. "
                                    + "Ответ строго одним текстом — только обработанная расшифровка.";
                            String out = LlmEngine.generate(this, prompt, maxTok, 0.0f);
                            boolean ok = out != null && !out.startsWith("LLM-") && !out.trim().isEmpty();
                            if (ok) {
                                e.transcript = out.trim();
                                new EntryStore(this).replace(e);
                            }
                            boolean okF = ok;
                            runOnUiThread(() -> {
                                Toast.makeText(this, okF ? "Текст улучшен нейро-ядром" : "Нейро-ядро недоступно", Toast.LENGTH_SHORT).show();
                                switchTab(1);
                            });
                        }).start();
                    });
                    card.addView(improve);
                }

                if (!hasText) {
                    LinearLayout row2 = new LinearLayout(this);
                    row2.setOrientation(LinearLayout.HORIZONTAL);

                    Button retryBtn = UI.secondaryButton(this, "Повторить");
                    retryBtn.setOnClickListener(v -> {
                        e.status = "В очереди";
                        new EntryStore(this).replace(e);
                        AutoTranscriber.enqueue(this, e);
                        Toast.makeText(this, "Запись снова в очереди на расшифровку", Toast.LENGTH_SHORT).show();
                        switchTab(1);
                    });
                    row2.addView(retryBtn);

                    Button delBtn2 = UI.secondaryButton(this, "Удалить");
                    delBtn2.setTextColor(0xFFEF4444);
                    LinearLayout.LayoutParams dlp2 = new LinearLayout.LayoutParams(-2, -2);
                    dlp2.leftMargin = dp(8);
                    delBtn2.setOnClickListener(v -> {
                        new EntryStore(this).delete(e.id);
                        switchTab(1);
                    });
                    row2.addView(delBtn2, dlp2);

                    LinearLayout.LayoutParams r2lp = new LinearLayout.LayoutParams(-2, -2);
                    r2lp.topMargin = dp(8);
                    card.addView(row2, r2lp);
                }

                card.addView(actRow);

                LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
                cardLp.bottomMargin = dp(12);
                card.setAlpha(0f);
                card.setTranslationY(dp(22));
                card.animate().alpha(1f).translationY(0f)
                        .setDuration(210)
                        .setStartDelay(Math.abs((e.id == null ? "x" : e.id).hashCode() % 6) * 35L)
                        .start();
                content.addView(card, cardLp);
            }
        }

        scroll.addView(content);
        contentFrame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
    }

    // ==========================================
    // TAB 2: SUMMARY (BRUTALIST EXECUTIVE BRIEF)
    // ==========================================
    private void renderSummaryTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int padH = dp(18);
        int padV = dp(24);
        content.setPadding(padH, padV, padH, dp(80));

        TextView title = new TextView(this);
        title.setText("Аналитический отчёт");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        content.addView(title);

        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        List<Entry> dayEntries = new ArrayList<>();
        for (Entry e : new EntryStore(this).all()) {
            if (e.created != null && e.created.startsWith(today)
                    && e.transcript != null && !e.transcript.trim().isEmpty()) {
                dayEntries.add(e);
            }
        }

        if (dayEntries.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("За сегодня (" + today + ") пока нет готовых записей для синтеза.");
            empty.setTextColor(0xFF5D6574);
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            empty.setPadding(0, dp(30), 0, 0);
            content.addView(empty);
        } else {
            LocalAiEngine ai = new LocalAiEngine(this);
            QwenEngine.DaySummary summary = ai.summarizeDay(dayEntries, today);

            LinearLayout briefCard = UI.createCard(this);
            TextView bTitle = new TextView(this);
            bTitle.setText("ФОКУС ДНЯ");
            bTitle.setTextColor(0xFFFFA25F);
            bTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            bTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            briefCard.addView(bTitle);

            TextView bText = new TextView(this);
            bText.setText(summary.executiveBrief);
            bText.setTextColor(0xFFF1F3F7);
            bText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            bText.setLineSpacing(dp(3), 1.0f);
            bText.setPadding(0, dp(8), 0, 0);
            briefCard.addView(bText);

            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
            blp.topMargin = dp(14);
            blp.bottomMargin = dp(16);
            content.addView(briefCard, blp);

            // Priorities & Tasks
            renderSummaryList(content, "КЛЮЧЕВЫЕ ЗАДАЧИ", summary.tasks);
            renderSummaryList(content, "ДОГОВОРЁННОСТИ И ВСТРЕЧИ", summary.meetings);
            renderSummaryList(content, "ХРОНИКА", summary.chronicle);
        }

        scroll.addView(content);
        contentFrame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
    }

    private void renderSummaryList(LinearLayout root, String header, List<QwenEngine.SummaryItem> items) {
        if (items == null || items.isEmpty()) return;

        TextView h = new TextView(this);
        h.setText(header);
        h.setTextColor(0xFF8E95A2);
        h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        h.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        h.setPadding(dp(4), dp(10), 0, dp(6));
        root.addView(h);

        for (QwenEngine.SummaryItem it : items) {
            LinearLayout itemCard = UI.createCard(this);
            itemCard.setOrientation(LinearLayout.HORIZONTAL);
            itemCard.setGravity(Gravity.CENTER_VERTICAL);
            int pad = dp(12);
            itemCard.setPadding(pad, pad, pad, pad);

            TextView timeView = UI.badge(this, it.time, 0xFFFFA25F, 0xFF221710);
            itemCard.addView(timeView);

            TextView text = new TextView(this);
            text.setText(it.refinedText);
            text.setTextColor(0xFFF1F3F7);
            text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1.0f);
            tlp.leftMargin = dp(10);
            itemCard.addView(text, tlp);

            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
            cardLp.bottomMargin = dp(8);
            root.addView(itemCard, cardLp);
        }
    }

    // ==========================================
    // TAB 3: SEARCH & NATURAL ASSISTANT
    // ==========================================
    private void renderSearchTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int padH = dp(18);
        int padV = dp(24);
        content.setPadding(padH, padV, padH, dp(80));

        TextView title = new TextView(this);
        title.setText("Поиск в памяти");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        content.addView(title);

        EditText input = UI.inputField(this, "Какой код от домофона? О чём говорили?");
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
        ilp.topMargin = dp(14);
        ilp.bottomMargin = dp(12);
        content.addView(input, ilp);

        TextView resView = new TextView(this);
        resView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        resView.setTextColor(0xFFF1F3F7);
        resView.setLineSpacing(dp(3), 1.0f);
        resView.setPadding(dp(12), dp(16), dp(12), dp(16));
        resView.setBackground(UI.shape(0xFF12141A, 0xFF232733, 14, this));
        resView.setVisibility(View.GONE);

        Button askBtn = UI.primaryButton(this, "Найти в архиве");
        askBtn.setOnClickListener(v -> {
            String q = input.getText().toString().trim();
            if (q.isEmpty()) return;

            StringBuilder archive = new StringBuilder();
            for (Entry e : new EntryStore(this).all()) {
                if (e.transcript != null && !e.transcript.trim().isEmpty()) {
                    archive.append("[").append(e.created).append("] ")
                           .append(e.transcript.trim()).append("\n\n");
                }
            }

            LocalAiEngine ai = new LocalAiEngine(this);
            String ans = ai.answer(q, archive.toString());
            resView.setText(ans);
            resView.setVisibility(View.VISIBLE);
        });
        content.addView(askBtn);

        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
        rlp.topMargin = dp(16);
        content.addView(resView, rlp);

        scroll.addView(content);
        contentFrame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
    }

    // ==========================================
    // TAB 4: MODELS & STEALTH COPYRIGHT "ALIM"
    // ==========================================
    private void renderModelsTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int padH = dp(18);
        int padV = dp(22);
        content.setPadding(padH, padV, padH, dp(96));

        // Header with depth
        TextView title = new TextView(this);
        title.setText("Нейросетевые ядра");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        content.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Локальные модели · без облака · полный контроль");
        subtitle.setTextColor(UI.COLOR_TEXT_MUTED);
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        subtitle.setPadding(0, dp(4), 0, 0);
        content.addView(subtitle);

        // Status summary strip
        LinearLayout summaryStrip = new LinearLayout(this);
        summaryStrip.setOrientation(LinearLayout.HORIZONTAL);
        summaryStrip.setGravity(Gravity.CENTER_VERTICAL);
        summaryStrip.setPadding(dp(14), dp(12), dp(14), dp(12));
        summaryStrip.setBackground(UI.shape(UI.COLOR_SURFACE_HIGH, UI.COLOR_BORDER_BRIGHT, 16, this));
        UI.elevate(summaryStrip, 2);
        LinearLayout.LayoutParams sslp = new LinearLayout.LayoutParams(-1, -2);
        sslp.topMargin = dp(18);
        sslp.bottomMargin = dp(8);
        content.addView(summaryStrip, sslp);

        boolean voskOk = ModelManager.voskInstalled(this);
        boolean whisperOk = ModelManager.installed(this, ModelManager.WHISPER);
        boolean llmOk = ModelManager.installed(this, ModelManager.LLM);
        int readyCount = (voskOk ? 1 : 0) + (whisperOk ? 1 : 0) + (llmOk ? 1 : 0);

        TextView readyLabel = new TextView(this);
        readyLabel.setText(readyCount + " / 3 готовы");
        readyLabel.setTextColor(readyCount == 3 ? UI.COLOR_GREEN : UI.COLOR_ORANGE);
        readyLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        readyLabel.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        summaryStrip.addView(readyLabel);

        TextView readyHint = new TextView(this);
        readyHint.setText("  ·  импорт из файлового менеджера");
        readyHint.setTextColor(UI.COLOR_TEXT_SUBTLE);
        readyHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        summaryStrip.addView(readyHint);

        // Vosk Card (live realtime) — elevated live style
        LinearLayout vCard = UI.createLiveCard(this);
        LinearLayout vHead = new LinearLayout(this);
        vHead.setOrientation(LinearLayout.HORIZONTAL);
        vHead.setGravity(Gravity.CENTER_VERTICAL);

        TextView vTitle = new TextView(this);
        vTitle.setText("Vosk · Realtime");
        vTitle.setTextColor(Color.WHITE);
        vTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        vTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        LinearLayout.LayoutParams vtlp = new LinearLayout.LayoutParams(0, -2, 1f);
        vHead.addView(vTitle, vtlp);

        TextView vBadge = UI.badge(this,
                voskOk ? "активен" : "нет",
                voskOk ? UI.COLOR_LIVE : 0xFFEF4444,
                voskOk ? UI.COLOR_LIVE_DIM : UI.COLOR_RED_BG);
        vHead.addView(vBadge);
        vCard.addView(vHead);

        TextView vStatus = new TextView(this);
        vStatus.setText(ModelManager.voskSize(this));
        vStatus.setTextColor(UI.COLOR_LIVE);
        vStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        vStatus.setPadding(0, dp(8), 0, 0);
        vCard.addView(vStatus);

        TextView vHint = new TextView(this);
        vHint.setText("Быстрый live-STT. Импорт: vosk-model-small-ru.zip\nИспользуется для мгновенной ленты на главном экране.");
        vHint.setTextColor(UI.COLOR_TEXT_MUTED);
        vHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        vHint.setLineSpacing(dp(2), 1.05f);
        vHint.setPadding(0, dp(8), 0, 0);
        vCard.addView(vHint);

        Button vImport = UI.primaryButton(this, voskOk ? "Заменить Vosk (.zip)" : "Импортировать Vosk (.zip)");
        vImport.setOnClickListener(v -> pickModelFile(REQ_IMPORT_VOSK));
        LinearLayout.LayoutParams vilp = new LinearLayout.LayoutParams(-1, -2);
        vilp.topMargin = dp(14);
        vCard.addView(vImport, vilp);

        Button vDiag = UI.secondaryButton(this, "Полная диагностика Vosk");
        vDiag.setOnClickListener(v -> VoskDiagnostics.run(this));
        LinearLayout.LayoutParams vdlp = new LinearLayout.LayoutParams(-1, -2);
        vdlp.topMargin = dp(8);
        vCard.addView(vDiag, vdlp);

        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(-1, -2);
        vlp.topMargin = dp(18);
        vlp.bottomMargin = dp(10);
        content.addView(vCard, vlp);

        // Whisper Card (final quality)
        LinearLayout wCard = UI.createCard(this);
        LinearLayout wHead = new LinearLayout(this);
        wHead.setOrientation(LinearLayout.HORIZONTAL);
        wHead.setGravity(Gravity.CENTER_VERTICAL);

        TextView wTitle = new TextView(this);
        wTitle.setText("Whisper · Финальная точность");
        wTitle.setTextColor(Color.WHITE);
        wTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        wTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        LinearLayout.LayoutParams wtlp = new LinearLayout.LayoutParams(0, -2, 1f);
        wHead.addView(wTitle, wtlp);

        TextView wBadge = UI.badge(this,
                whisperOk ? "готов" : "требуется",
                whisperOk ? UI.COLOR_GREEN : 0xFFEF4444,
                whisperOk ? UI.COLOR_GREEN_BG : UI.COLOR_RED_BG);
        wHead.addView(wBadge);
        wCard.addView(wHead);

        TextView wStatus = new TextView(this);
        wStatus.setText(ModelManager.size(this, ModelManager.WHISPER));
        wStatus.setTextColor(UI.COLOR_ORANGE_CORE);
        wStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        wStatus.setPadding(0, dp(8), 0, 0);
        wCard.addView(wStatus);

        if (!whisperOk) {
            TextView wWarn = new TextView(this);
            wWarn.setText("Без этой модели финальная расшифровка недоступна.");
            wWarn.setTextColor(0xFFFF8A8A);
            wWarn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            wWarn.setPadding(0, dp(6), 0, 0);
            wCard.addView(wWarn);
        } else {
            TextView wOk = new TextView(this);
            wOk.setText("Используется после остановки записи для чистого текста.");
            wOk.setTextColor(UI.COLOR_TEXT_MUTED);
            wOk.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            wOk.setPadding(0, dp(6), 0, 0);
            wCard.addView(wOk);
        }

        Button wImport = UI.primaryButton(this, whisperOk ? "Заменить Whisper (.bin)" : "Импортировать Whisper (.bin)");
        wImport.setOnClickListener(v -> pickModelFile(REQ_IMPORT_WHISPER));
        LinearLayout.LayoutParams wilp = new LinearLayout.LayoutParams(-1, -2);
        wilp.topMargin = dp(14);
        wCard.addView(wImport, wilp);

        TextView engineLine = new TextView(this);
        engineLine.setText(LlmEngine.available()
                ? "llama.cpp · native активен"
                : "llama.cpp · шаблонный режим (сборка без native)");
        engineLine.setTextColor(LlmEngine.available() ? UI.COLOR_GREEN : UI.COLOR_TEXT_SUBTLE);
        engineLine.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(-1, -2);
        elp.topMargin = dp(12);
        wCard.addView(engineLine, elp);

        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-1, -2);
        wlp.topMargin = dp(12);
        wlp.bottomMargin = dp(10);
        content.addView(wCard, wlp);

        // Qwen LLM Card
        LinearLayout qCard = UI.createCard(this);
        LinearLayout qHead = new LinearLayout(this);
        qHead.setOrientation(LinearLayout.HORIZONTAL);
        qHead.setGravity(Gravity.CENTER_VERTICAL);

        TextView qTitle = new TextView(this);
        qTitle.setText("Qwen 2.5 · Intelligence");
        qTitle.setTextColor(Color.WHITE);
        qTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        qTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        LinearLayout.LayoutParams qtlp = new LinearLayout.LayoutParams(0, -2, 1f);
        qHead.addView(qTitle, qtlp);

        TextView qBadge = UI.badge(this,
                llmOk ? "готов" : "опционально",
                llmOk ? UI.COLOR_GREEN : UI.COLOR_TEXT_MUTED,
                llmOk ? UI.COLOR_GREEN_BG : 0x22FFFFFF);
        qHead.addView(qBadge);
        qCard.addView(qHead);

        TextView qStatus = new TextView(this);
        qStatus.setText(ModelManager.size(this, ModelManager.LLM));
        qStatus.setTextColor(UI.COLOR_ORANGE_CORE);
        qStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        qStatus.setPadding(0, dp(8), 0, 0);
        qCard.addView(qStatus);

        TextView qHint = new TextView(this);
        qHint.setText("GGUF-модель для сводок и вопросов к дневнику.\nМожно добавить позже — базовый функционал работает без неё.");
        qHint.setTextColor(UI.COLOR_TEXT_MUTED);
        qHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        qHint.setLineSpacing(dp(2), 1.05f);
        qHint.setPadding(0, dp(6), 0, 0);
        qCard.addView(qHint);

        Button qImport = UI.secondaryButton(this, llmOk ? "Заменить qwen.gguf" : "Импортировать Qwen GGUF");
        qImport.setOnClickListener(v -> pickModelFile(REQ_IMPORT_LLM));
        LinearLayout.LayoutParams qilp = new LinearLayout.LayoutParams(-1, -2);
        qilp.topMargin = dp(14);
        qCard.addView(qImport, qilp);

        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(-1, -2);
        qlp.bottomMargin = dp(28);
        content.addView(qCard, qlp);

        // Stealth signature — deeper, less generic
        TextView copyright = new TextView(this);
        copyright.setText("BLACKBOX  ·  CORE 2.4.0  ·  OFFLINE");
        copyright.setTextColor(0xFF252A35);
        copyright.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        copyright.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        copyright.setLetterSpacing(0.14f);
        copyright.setGravity(Gravity.CENTER);
        content.addView(copyright);

        scroll.addView(content);
        contentFrame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
    }

    private void pickModelFile(int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            Toast.makeText(this, "Нет приложения для выбора файла", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        Toast.makeText(this, "Копирование весов модели…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                if (req == REQ_IMPORT_VOSK) {
                    ModelManager.importVoskZip(this, uri);
                } else {
                    String target;
                    if (req == REQ_IMPORT_WHISPER) target = ModelManager.WHISPER;
                    else if (req == REQ_IMPORT_LLM) target = ModelManager.LLM;
                    else return;
                    ModelManager.importFile(this, uri, target);
                }
                runOnUiThread(() -> {
                    Toast.makeText(this, "Модель успешно установлена!", Toast.LENGTH_SHORT).show();
                    switchTab(4);
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this,
                        "Ошибка импорта: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void togglePlayback(Button btn, File f) {
        try {
            if (player != null && player.isPlaying()) {
                player.stop();
                player.release();
                player = null;
                RecordingService.isAppPlayingAudio = false;
                resetPlayButtons();
                return;
            }
            resetPlayButtons();
            player = new MediaPlayer();
            RecordingService.isAppPlayingAudio = true;
            player.setDataSource(f.getAbsolutePath());
            player.setOnCompletionListener(mp -> {
                mp.release();
                player = null;
                resetPlayButtons();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                try { mp.release(); } catch (Exception ignored) {}
                player = null;
                RecordingService.isAppPlayingAudio = false;
                resetPlayButtons();
                Toast.makeText(this, "Не удалось воспроизвести запись", Toast.LENGTH_SHORT).show();
                return true;
            });
            player.prepare();
            player.start();
            playBtn = btn;
            btn.setText("■ Стоп");
        } catch (Exception ex) {
            try { if (player != null) player.release(); } catch (Exception ignored) {}
            player = null;
            RecordingService.isAppPlayingAudio = false;
            Toast.makeText(this, "Не удалось воспроизвести запись", Toast.LENGTH_SHORT).show();
        }
    }

    private void resetPlayButtons() {
        if (contentFrame == null) return;
        java.util.ArrayList<Button> found = new java.util.ArrayList<>();
        java.util.ArrayDeque<android.view.View> stack = new java.util.ArrayDeque<>();
        stack.add(contentFrame);
        while (!stack.isEmpty()) {
            android.view.View v = stack.poll();
            if (v instanceof Button) {
                CharSequence cs = ((Button) v).getText();
                if (cs != null && ("■ Стоп".contentEquals(cs) || "Слушать".contentEquals(cs))) {
                    found.add((Button) v);
                }
            } else if (v instanceof android.view.ViewGroup) {
                android.view.ViewGroup g = (android.view.ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) stack.add(g.getChildAt(i));
            }
        }
        for (Button b : found) b.setText("Слушать");
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) {
            try { player.stop(); player.release(); } catch (Exception ignored) {}
            player = null;
            resetPlayButtons();
        }
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(liveTextReceiver); } catch (Exception ignored) {}
        stopLiveAnim();
        try { unregisterReceiver(stateReceiver); } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
