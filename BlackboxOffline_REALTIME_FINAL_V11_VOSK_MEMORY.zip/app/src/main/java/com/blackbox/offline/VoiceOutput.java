package com.blackbox.offline;

import android.content.Context;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import java.util.Locale;

/** Local voice output through Android's installed TTS engine. */
public final class VoiceOutput {
    private static volatile TextToSpeech tts;
    private static volatile boolean ready;
    private static final Object LOCK = new Object();

    private VoiceOutput() {}

    private static void ensure(Context context) {
        if (tts != null) return;
        synchronized (LOCK) {
            if (tts != null) return;
            Context app = context.getApplicationContext();
            tts = new TextToSpeech(app, status -> {
                if (status == TextToSpeech.SUCCESS) {
                    TextToSpeech engine = tts;
                    int result = engine.setLanguage(new Locale("ru", "RU"));
                    ready = result != TextToSpeech.LANG_MISSING_DATA
                            && result != TextToSpeech.LANG_NOT_SUPPORTED;
                    if (ready && Build.VERSION.SDK_INT >= 21) {
                        Voice best = null;
                        for (Voice v : engine.getVoices()) {
                            if (v == null || v.isNetworkConnectionRequired()) continue;
                            Locale l = v.getLocale();
                            if (l != null && "ru".equalsIgnoreCase(l.getLanguage())) {
                                best = v;
                                break;
                            }
                        }
                        if (best != null) engine.setVoice(best);
                    }
                } else {
                    ready = false;
                }
            });
        }
    }

    public static void warmup(Context context) {
        ensure(context);
    }

    public static boolean isOfflineVoiceAvailable(Context context) {
        ensure(context);
        TextToSpeech engine = tts;
        if (!ready || engine == null || Build.VERSION.SDK_INT < 21) return false;
        try {
            for (Voice v : engine.getVoices()) {
                if (v != null && !v.isNetworkConnectionRequired()
                        && v.getLocale() != null
                        && "ru".equalsIgnoreCase(v.getLocale().getLanguage())) return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    public static void speak(Context context, String text) {
        if (text == null || text.trim().isEmpty()) return;
        final String value = text.trim();
        ensure(context);
        new Thread(() -> {
            try {
                TextToSpeech engine = tts;
                if (engine == null) return;
                // Only speak when an installed non-network Russian voice exists.
                if (!isOfflineVoiceAvailable(context)) return;
                engine.speak(value, TextToSpeech.QUEUE_FLUSH, null, "blackbox-memory-answer");
            } catch (Throwable ignored) {}
        }, "blackbox-tts").start();
    }

    public static void stop() {
        try { if (tts != null) tts.stop(); } catch (Throwable ignored) {}
    }
}
