package com.blackbox.offline;

import android.content.Context;
import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;
import java.io.File;

/**
 * Offline streaming ASR via Vosk (free). Used only for live Home indicator.
 * Final diary cards are produced by Whisper Base after recording stops.
 */
public final class VoskEngine {
    private static final Object LOCK = new Object();
    private static Model sharedModel;
    private static String loadedPath = "";

    private Recognizer recognizer;
    private boolean ready;

    public VoskEngine(Context c) {
        ready = ensureModel(c.getApplicationContext());
        if (ready) {
            try {
                synchronized (LOCK) {
                    recognizer = new Recognizer(sharedModel, 16000.0f);
                    recognizer.setWords(false);
                    recognizer.setPartialWords(false);
                }
            } catch (Throwable t) {
                ready = false;
                recognizer = null;
            }
        }
    }

    public static boolean ensureModel(Context app) {
        synchronized (LOCK) {
            File dir = ModelManager.voskModelRoot(app);
            try {
                if (!ModelManager.voskInstalled(app)) {
                    android.util.Log.w("BlackboxVosk", "voskInstalled()=false, dir=" + dir.getAbsolutePath());
                    return false;
                }
                String path = dir.getAbsolutePath();
                if (sharedModel != null && path.equals(loadedPath)) return true;
                if (sharedModel != null) {
                    try { sharedModel.close(); } catch (Throwable ignored) {}
                    sharedModel = null;
                }
                sharedModel = new Model(path);
                loadedPath = path;
                android.util.Log.d("BlackboxVosk", "Model loaded OK from " + path);
                return true;
            } catch (Throwable t) {
                android.util.Log.e("BlackboxVosk", "Model load FAILED from " + dir.getAbsolutePath(), t);
                sharedModel = null;
                loadedPath = "";
                return false;
            }
        }
    }

    public boolean isReady() {
        return ready && recognizer != null;
    }

    /** Feed 16-bit mono PCM @ 16 kHz. Returns latest partial/final hypothesis or "". */
    public synchronized String accept(short[] pcm, int n) {
        if (!isReady() || pcm == null || n <= 0) return "";
        try {
            byte[] bytes = new byte[n * 2];
            for (int i = 0; i < n; i++) {
                short s = pcm[i];
                bytes[i * 2] = (byte) (s & 0xff);
                bytes[i * 2 + 1] = (byte) ((s >> 8) & 0xff);
            }
            if (recognizer.acceptWaveForm(bytes, bytes.length)) {
                return extractText(recognizer.getResult());
            }
            return extractText(recognizer.getPartialResult());
        } catch (Throwable t) {
            return "";
        }
    }

    public synchronized String flush() {
        if (!isReady()) return "";
        try {
            return extractText(recognizer.getFinalResult());
        } catch (Throwable t) {
            return "";
        }
    }

    public synchronized void reset() {
        if (!isReady()) return;
        try {
            recognizer.reset();
        } catch (Throwable ignored) {}
    }

    public synchronized void release() {
        try {
            if (recognizer != null) recognizer.close();
        } catch (Throwable ignored) {}
        recognizer = null;
        ready = false;
    }

    private static String extractText(String json) {
        if (json == null || json.isEmpty()) return "";
        try {
            JSONObject o = new JSONObject(json);
            if (o.has("text")) return o.optString("text", "").trim();
            if (o.has("partial")) return o.optString("partial", "").trim();
        } catch (Throwable ignored) {}
        return "";
    }
}
