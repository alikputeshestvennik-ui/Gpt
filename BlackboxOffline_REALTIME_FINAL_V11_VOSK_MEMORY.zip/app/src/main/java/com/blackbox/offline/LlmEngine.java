package com.blackbox.offline;

import android.content.Context;
import java.io.File;

/**
 * AI Core (Gemini Nano style) bridge via llama.cpp.
 * Availability is probed at runtime: if the native library was built without
 * llama.cpp, every call degrades gracefully and falls back to template answers.
 */
final class LlmEngine {
    private LlmEngine() {}

    private static native int nativePing();
    private static native String nativeGenerate(String modelPath, String prompt, int maxTokens, float temp);

    private static volatile Boolean availableCache = null;

    static boolean available() {
        if (availableCache == null) {
            synchronized (LlmEngine.class) {
                if (availableCache == null) {
                    try {
                        System.loadLibrary("blackbox_llm");
                        availableCache = (nativePing() == 1);
                    } catch (Throwable t) {
                        availableCache = false;
                    }
                }
            }
        }
        return availableCache;
    }

    /** Генерация ответа. Блокирует вызывающий поток — вызывать только из фона. */
    static String generate(Context c, String prompt, int maxTokens, float temp) {
        File f = ModelManager.file(c, ModelManager.LLM);
        if (!f.isFile()) return "LLM-ошибка: GGUF-модель AI Core не установлена";
        try {
            return nativeGenerate(f.getAbsolutePath(), prompt, maxTokens, temp);
        } catch (Throwable t) {
            return "LLM-ошибка: " + (t.getMessage() == null ? "сбой нативного ядра" : t.getMessage());
        }
    }
}
