package com.blackbox.offline;

import android.content.Context;
import com.google.mlkit.genai.common.FeatureStatus;
import com.google.mlkit.genai.prompt.GenerateContentResponse;
import com.google.mlkit.genai.prompt.Generation;
import com.google.mlkit.genai.prompt.java.GenerativeModelFutures;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Google Gemini Nano bridge through Android AICore / ML Kit GenAI Prompt API.
 * All inference stays on-device. Availability is checked at runtime, so the
 * app can expose the feature only on supported phones.
 */
public final class GeminiNanoEngine {
    public static final int AVAILABLE = FeatureStatus.AVAILABLE;
    public static final int DOWNLOADABLE = FeatureStatus.DOWNLOADABLE;
    public static final int DOWNLOADING = FeatureStatus.DOWNLOADING;
    public static final int UNAVAILABLE = FeatureStatus.UNAVAILABLE;

    private static volatile GenerativeModelFutures model;
    private static volatile boolean initialized;
    private static final Object LOCK = new Object();

    private GeminiNanoEngine() {}

    private static GenerativeModelFutures model() {
        if (model == null) {
            synchronized (LOCK) {
                if (model == null) {
                    model = GenerativeModelFutures.from(Generation.INSTANCE.getClient());
                }
            }
        }
        return model;
    }

    public static int status(Context context) {
        try {
            return model().checkStatus().get(12, TimeUnit.SECONDS);
        } catch (Throwable t) {
            return UNAVAILABLE;
        }
    }

    public static boolean isAvailable(Context context) {
        return status(context) == AVAILABLE;
    }

    /** Non-streaming call: the UI only receives the completed answer. */
    public static String generate(Context context, String prompt, int maxOutputTokens) {
        if (prompt == null || prompt.trim().isEmpty()) return "";
        try {
            GenerativeModelFutures m = model();
            if (m.checkStatus().get(12, TimeUnit.SECONDS) != AVAILABLE) return "";
            GenerateContentResponse response = m.generateContent(prompt).get(90, TimeUnit.SECONDS);
            if (response == null) return "";
            List<com.google.mlkit.genai.prompt.Candidate> candidates = response.getCandidates();
            if (candidates == null || candidates.isEmpty()) return "";
            String text = candidates.get(0).getText();
            if (text == null) return "";
            return text.trim();
        } catch (Throwable ignored) {
            return "";
        }
    }

    public static void warmup(Context context) {
        try {
            if (status(context) == AVAILABLE) model().warmup();
        } catch (Throwable ignored) {}
    }

    public static String statusLabel(Context context) {
        int s = status(context);
        if (s == AVAILABLE) return "доступен";
        if (s == DOWNLOADABLE) return "доступен к загрузке";
        if (s == DOWNLOADING) return "загружается";
        return "недоступен на этом устройстве";
    }
}
