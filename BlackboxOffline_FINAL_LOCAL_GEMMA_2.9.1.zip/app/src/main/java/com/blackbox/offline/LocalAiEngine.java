package com.blackbox.offline;

import android.content.Context;
import java.io.File;
import java.util.List;

/**
 * Blackbox local intelligence bridge.
 * ASR is handled separately; Gemma is the only LLM in the active chains.
 * Qwen is no longer a runtime fallback.
 */
public class LocalAiEngine {
    private final Context app;
    private static volatile boolean whisperLoaded = false;
    private static volatile boolean attempted = false;
    private static final Object WARM_LOCK = new Object();
    private static volatile boolean warmed = false;

    public LocalAiEngine(Context c) {
        this.app = c.getApplicationContext();
    }

    private static synchronized void ensureNative() {
        if (!attempted) {
            attempted = true;
            try {
                System.loadLibrary("blackbox_ai");
                whisperLoaded = true;
            } catch (Throwable t) {
                whisperLoaded = false;
            }
        }
    }

    public boolean whisperReady() {
        ensureNative();
        return whisperLoaded && ModelManager.installed(app, ModelManager.WHISPER);
    }

    public boolean gemmaReady() { return GemmaEngine.ready(app); }
    public boolean ready() { return whisperReady(); }

    private static native boolean nativeWarm(String modelPath);

    public static boolean warm(Context c) {
        boolean ok = false;
        try {
            Context app = c.getApplicationContext();
            ensureNative();
            if (whisperLoaded && ModelManager.installed(app, ModelManager.WHISPER)) {
                if (!warmed) {
                    synchronized (WARM_LOCK) {
                        if (!warmed) warmed = nativeWarm(ModelManager.file(app, ModelManager.WHISPER).getAbsolutePath());
                    }
                }
                ok = warmed;
            }
        } catch (Throwable ignored) {}
        // Gemma is warmed separately so a missing Gemma model never blocks ASR startup.
        try { GemmaEngine.warm(c); } catch (Throwable ignored) {}
        return ok;
    }

    public String transcribe(String path) throws Exception {
        if (!ModelManager.installed(app, ModelManager.WHISPER)) {
            throw new IllegalStateException("Импортируйте ggml-base.bin в разделе AI-модели.");
        }
        ensureNative();
        if (!whisperLoaded) throw new IllegalStateException("Нативная библиотека whisper не загружена.");
        File model = ModelManager.file(app, ModelManager.WHISPER);
        return nativeTranscribePcm(PcmDecoder.decode16kMono(path), model.getAbsolutePath());
    }

    /** Gemma answers memory questions using only the supplied local context. */
    public String answer(String question, String context) {
        String prompt = "Ты локальный интеллектуальный помощник Blackbox. "
                + "Отвечай только по данным дневника ниже. Не придумывай факты, имена, даты или действия. "
                + "Если данных недостаточно, прямо скажи об этом. Отвечай по-русски естественно и кратко.\n\n"
                + "ВОПРОС:\n" + question.trim() + "\n\nДАННЫЕ ДНЕВНИКА:\n" + context;
        String out = GemmaEngine.generate(app, prompt, 360);
        return out == null ? "" : out.trim();
    }

    /** Deterministic structure for the summary UI; the deep narrative is Gemma-generated below. */
    public DaySummaryEngine.DaySummary summarizeDay(List<Entry> entries, String date) {
        return new DaySummaryEngine().buildStructuredSummary(entries, date);
    }

    public String analyticalDayReport(List<Entry> entries, String date) {
        StringBuilder ctx = new StringBuilder();
        int count = 0;
        for (Entry e : entries) {
            if (e == null || e.transcript == null || e.transcript.trim().isEmpty()) continue;
            if (count++ >= 45) break;
            ctx.append("[").append(e.created == null ? "" : e.created).append("] ")
                    .append(e.transcript.trim()).append("\n");
        }
        String prompt = "Ты локальный аналитический интеллект Blackbox. Составь пересказ дня за " + date + ". "
                + "Используй только готовые отредактированные фрагменты ниже. Не придумывай сведения. "
                + "Сделай связный краткий пересказ событий дня, отдельно выдели задачи, договорённости и идеи, "
                + "если они действительно присутствуют. Сохраняй имена, факты и время. Не упоминай, что ты ИИ. "
                + "Ответ только на русском, без служебных пояснений.\n\nФРАГМЕНТЫ:\n" + ctx;
        String out = GemmaEngine.generate(app, prompt, 650);
        return out == null ? "" : out.trim();
    }

    public String neuralDayBrief(List<Entry> entries, String date) {
        return analyticalDayReport(entries, date);
    }

    public String summarize(String context, String date) {
        String prompt = "Сделай краткий пересказ дневника. Только факты из текста. Русский язык.\n\n" + context;
        return GemmaEngine.generate(app, prompt, 500);
    }

    public String summarize(String context) { return summarize(context, null); }

    public String transcribeRealtimePcm(float[] pcm) {
        if (pcm == null || pcm.length == 0) return "";
        ensureNative();
        if (!whisperLoaded || !ModelManager.installed(app, ModelManager.WHISPER)) return "";
        try {
            File model = ModelManager.file(app, ModelManager.WHISPER);
            return nativeTranscribeRealtimePcm(pcm, model.getAbsolutePath());
        } catch (Throwable ignored) { return ""; }
    }

    private native String nativeTranscribePcm(float[] pcm, String whisperModel);
    private static native String nativeTranscribeRealtimePcm(float[] pcm, String whisperModel);
}
