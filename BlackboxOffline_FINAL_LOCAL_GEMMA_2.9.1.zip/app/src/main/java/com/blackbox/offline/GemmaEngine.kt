package com.blackbox.offline

import android.content.Context
import android.os.Build
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.ThinkingConfig
import java.io.File

/** Real LiteRT-LM Gemma bridge. GPU first, CPU fallback. */
object GemmaEngine {
    private val lock = Any()
    private var engine: Engine? = null
    private var backend = "не запущен"
    private var error = ""

    @JvmStatic fun modelPresent(c: Context): Boolean = ModelManager.installed(c, ModelManager.GEMMA)
    @JvmStatic fun modelSize(c: Context): String = ModelManager.size(c, ModelManager.GEMMA)
    @JvmStatic fun backendName(): String = synchronized(lock) { backend }
    @JvmStatic fun lastError(): String = synchronized(lock) { error }

    @JvmStatic fun warm(c: Context): Boolean = synchronized(lock) {
        if (!modelPresent(c)) return false
        if (engine != null) return true
        val model = ModelManager.file(c.applicationContext, ModelManager.GEMMA)
        try {
            val e = Engine(EngineConfig(modelPath = model.absolutePath, backend = Backend.GPU(), cacheDir = c.cacheDir.absolutePath))
            e.initialize()
            engine = e
            backend = "GPU"
            error = ""
            true
        } catch (gpu: Throwable) {
            error = shortError(gpu)
            try {
                val e = Engine(EngineConfig(modelPath = model.absolutePath, backend = Backend.CPU(), cacheDir = c.cacheDir.absolutePath))
                e.initialize()
                engine = e
                backend = "CPU · fallback"
                true
            } catch (cpu: Throwable) {
                error = shortError(cpu)
                backend = "ошибка"
                false
            }
        }
    }

    @JvmStatic fun ready(c: Context): Boolean = modelPresent(c) && synchronized(lock) { engine != null }

    @JvmStatic fun generate(c: Context, prompt: String, maxTokens: Int): String {
        if (prompt.isBlank()) return ""
        if (!warm(c)) return ""
        synchronized(lock) {
            val e = engine ?: return ""
            var conversation: AutoCloseable? = null
            return try {
                val cfg = ConversationConfig(systemInstruction = Contents.of(
                    "Ты локальная модель Gemma внутри Blackbox. Отвечай только на основании переданного контекста, если он дан."
                ))
                val conv = e.createConversation(cfg)
                conversation = conv
                val response = conv.sendMessage(
                    prompt,
                    emptyMap(),
                    null,
                    null,
                    null,
                    maxTokens,
                    ThinkingConfig(enableThinking = false, thinkingTokenBudget = 0),
                    null
                )
                response.toString().trim()
            } catch (t: Throwable) {
                error = shortError(t)
                ""
            } finally {
                try { conversation?.close() } catch (_: Throwable) {}
            }
        }
    }

    @JvmStatic fun probeBackend(c: Context, name: String): String {
        if (!modelPresent(c)) return "Модель Gemma не установлена"
        if (!name.equals("GPU", true) && !name.equals("CPU", true) && !name.equals("NPU", true)) return "Неизвестный backend"
        if (name.equals("NPU", true)) {
            return try {
                val model = ModelManager.file(c, ModelManager.GEMMA)
                val e = Engine(EngineConfig(modelPath = model.absolutePath, backend = Backend.NPU(c.applicationInfo.nativeLibraryDir)))
                val t0 = System.currentTimeMillis(); e.initialize(); val ms = System.currentTimeMillis() - t0
                e.close(); "Доступен · инициализация ${ms} мс"
            } catch (t: Throwable) { "Недоступен · ${shortError(t)}" }
        }
        return try {
            val model = ModelManager.file(c, ModelManager.GEMMA)
            val b = if (name.equals("GPU", true)) Backend.GPU() else Backend.CPU()
            val e = Engine(EngineConfig(modelPath = model.absolutePath, backend = b, cacheDir = c.cacheDir.absolutePath))
            val t0 = System.currentTimeMillis(); e.initialize(); val ms = System.currentTimeMillis() - t0
            e.close(); "Доступен · инициализация ${ms} мс"
        } catch (t: Throwable) { "Недоступен · ${shortError(t)}" }
    }

    @JvmStatic fun deviceInfo(): String = "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE}"

    @JvmStatic fun shutdown() = synchronized(lock) {
        try { engine?.close() } catch (_: Throwable) {}
        engine = null
        backend = "не запущен"
    }

    private fun shortError(t: Throwable): String {
        var x = t
        while (x.cause != null && x.cause !== x) x = x.cause!!
        return (x.message ?: x::class.java.simpleName).replace('\n', ' ').trim()
    }
}
