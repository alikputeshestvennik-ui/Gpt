package com.blackbox.offline;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Realtime transcription selector.
 *
 * Priority:
 * 1) Android on-device SpeechRecognizer when the device exposes it.
 * 2) Existing local Vosk pipeline as a fully local fallback.
 *
 * Realtime ring stores only finalized raw ASR utterances. Partial hypotheses are
 * displayed live but never saved to History or the 15-minute ring.
 * The same raw text is handed to AutoTranscriber for the History -> Gemini Nano
 * editing stage, so Whisper is only a fallback when no on-device recognizer is
 * available or it produced no usable text.
 */
public final class RealtimeTranscriber {
    public static final String LIVE_TEXT = "com.blackbox.offline.LIVE_TEXT";

    private final Context app;
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile boolean running;
    private volatile boolean cancelRequested;
    private long generation;
    private Thread worker;
    private Entry entry;

    private VoskEngine vosk;
    private SpeechRecognizer onDeviceRecognizer;
    private boolean usingOnDevice;
    private boolean restartScheduled;
    private boolean commandHandled;
    private volatile boolean finishRequested;
    private String accumulated = "";
    private String lastPartial = "";

    private final java.util.concurrent.ArrayBlockingQueue<short[]> queue =
            new java.util.concurrent.ArrayBlockingQueue<>(150);

    public RealtimeTranscriber(Context c) {
        app = c.getApplicationContext();
    }

    public static boolean isOnDeviceAvailable(Context c) {
        if (Build.VERSION.SDK_INT < 31) return false;
        try {
            return SpeechRecognizer.isOnDeviceRecognitionAvailable(c.getApplicationContext());
        } catch (Throwable ignored) {
            return false;
        }
    }

    public synchronized boolean isUsingOnDevice() {
        return usingOnDevice;
    }

    /** Start a new speech segment. The newest segment replaces the previous one. */
    public synchronized void start(Entry e) {
        if (e == null) return;
        if (running || worker != null || onDeviceRecognizer != null) cancel();

        final long myGeneration = ++generation;
        entry = e;
        accumulated = "";
        lastPartial = "";
        commandHandled = false;
        finishRequested = false;
        restartScheduled = false;
        running = true;
        cancelRequested = false;
        queue.clear();

        // Continuous background recording already owns the microphone through
        // RecordingService/AudioRecord. Android SpeechRecognizer also tries to
        // own the microphone, so running both at once causes empty realtime,
        // recognizer restarts and audible system start/stop sounds on some
        // Samsung recognition services. Keep SpeechRecognizer for the explicit
        // diagnostics probe, but use the single local Vosk stream for the
        // continuous 15-minute realtime path. Both paths remain fully local.
        usingOnDevice = false;
        broadcastLive(myGeneration, "");
        worker = new Thread(() -> workerLoop(myGeneration), "blackbox-vosk-realtime");
        worker.start();
    }

    public void feed(short[] pcm, int n) {
        // Android's on-device recognizer owns its own short dictation stream.
        // AudioRecord frames are still retained for the WAV/history fallback and
        // for Vosk when on-device recognition is unavailable.
        if (usingOnDevice || !running || pcm == null || n <= 0) return;
        short[] copy = new short[n];
        System.arraycopy(pcm, 0, copy, 0, n);
        if (!queue.offer(copy)) {
            queue.poll();
            queue.offer(copy);
        }
    }

    private void startOnDevice(long myGeneration) {
        if (!isCurrent(myGeneration) || !usingOnDevice) return;
        try {
            if (onDeviceRecognizer != null) {
                try { onDeviceRecognizer.destroy(); } catch (Throwable ignored) {}
                onDeviceRecognizer = null;
            }
            onDeviceRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(app);
            onDeviceRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) {
                    broadcastLive(myGeneration, lastPartial);
                }
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float rmsdB) {}
                @Override public void onBufferReceived(byte[] buffer) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onError(int error) {
                    if (!isCurrent(myGeneration)) return;
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        // Do not spin forever if microphone permission was revoked.
                        setStatusIfCurrent(myGeneration, "On-device распознавание: нет доступа к микрофону");
                        return;
                    }
                    // SpeechRecognizer is a short-dictation API. Re-arm it after
                    // each utterance/error so a 15-minute Blackbox session remains
                    // a continuous rolling feed without sending audio to a server.
                    if (!finishRequested) scheduleOnDeviceRestart(myGeneration, 250L);
                }
                @Override public void onResults(Bundle results) {
                    if (!isCurrent(myGeneration)) return;
                    String text = firstResult(results);
                    if (!text.isEmpty()) handleOnDeviceFinal(myGeneration, text);
                    lastPartial = "";
                    broadcastLive(myGeneration, accumulated);
                    if (!finishRequested) scheduleOnDeviceRestart(myGeneration, 120L);
                }
                @Override public void onPartialResults(Bundle partialResults) {
                    if (!isCurrent(myGeneration)) return;
                    String text = firstResult(partialResults);
                    if (!text.isEmpty()) {
                        lastPartial = text.trim();
                        // Live preview is raw ASR; it is intentionally not passed
                        // through Gemini and is not persisted in the ring.
                        broadcastLive(myGeneration, lastPartial);
                    }
                }
                @Override public void onEvent(int eventType, Bundle params) {}
            });

            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            onDeviceRecognizer.startListening(intent);
        } catch (Throwable t) {
            // If the advertised on-device recognizer cannot actually start on this
            // firmware, fall back to Vosk for this segment instead of breaking the
            // diary pipeline.
            usingOnDevice = false;
            worker = new Thread(() -> workerLoop(myGeneration), "blackbox-vosk-realtime-fallback");
            worker.start();
        }
    }

    private void scheduleOnDeviceRestart(long myGeneration, long delayMs) {
        main.postDelayed(() -> {
            if (!isCurrent(myGeneration) || !usingOnDevice) return;
            try {
                if (onDeviceRecognizer != null) onDeviceRecognizer.startListening(buildIntent());
            } catch (Throwable t) {
                // Some recognition services require a fresh instance after an error.
                try { if (onDeviceRecognizer != null) onDeviceRecognizer.destroy(); } catch (Throwable ignored) {}
                onDeviceRecognizer = null;
                startOnDevice(myGeneration);
            }
        }, delayMs);
    }

    private Intent buildIntent() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        return intent;
    }

    private String firstResult(Bundle b) {
        if (b == null) return "";
        try {
            ArrayList<String> values = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (values != null && !values.isEmpty() && values.get(0) != null) return values.get(0).trim();
        } catch (Throwable ignored) {}
        return "";
    }

    private void handleOnDeviceFinal(long myGeneration, String text) {
        String clean = AutoTranscriber.cleanHallucinations(text).trim();
        if (clean.length() < 2) return;

        // Accumulate raw final ASR segments for this recording clip. This is the
        // source Gemini receives for History when on-device recognition is active.
        accumulated = merge(accumulated, clean);
        broadcastLive(myGeneration, clean);

        boolean systemCommand = EmergencySecurity.matches(app, clean)
                || AutoTranscriber.looksLikeMemoryQuestion(clean)
                || AutoTranscriber.looksLikeMediaRestoreCommand(clean)
                || AutoTranscriber.looksLikeMediaDuckCommand(clean)
                || AutoTranscriber.looksLikeStopCommand(clean);
        if (!systemCommand) RealtimeRingStore.appendFinal(app, clean);

        if (!commandHandled && EmergencySecurity.matches(app, clean)) {
            commandHandled = true;
            try { app.startService(new Intent(app, RecordingService.class).setAction(RecordingService.EMERGENCY_WIPE)); }
            catch (Throwable ignored) {}
            return;
        }
        if (!commandHandled && AutoTranscriber.looksLikeMemoryQuestion(clean)) {
            commandHandled = true;
            if (entry != null) entry.handsFreeHandled = true;
            AutoTranscriber.processHandsFreeMemoryRecall(app, clean);
            return;
        }
        if (!commandHandled && AutoTranscriber.looksLikeMediaRestoreCommand(clean)) {
            commandHandled = true;
            try {
                app.startService(new Intent(app, RecordingService.class).setAction(RecordingService.RESTORE_MEDIA));
                broadcastLive(myGeneration, "🔊 Звук восстановлен");
            } catch (Throwable ignored) {}
            return;
        }
        if (!commandHandled && AutoTranscriber.looksLikeMediaDuckCommand(clean)) {
            commandHandled = true;
            try {
                app.startService(new Intent(app, RecordingService.class).setAction(RecordingService.DUCK_MEDIA));
                broadcastLive(myGeneration, "🔇 Медиа приглушено на 10 минут");
            } catch (Throwable ignored) {}
            return;
        }
        if (!commandHandled && AutoTranscriber.looksLikeStopCommand(clean)) {
            commandHandled = true;
            try { app.startService(new Intent(app, RecordingService.class).setAction(RecordingService.STOP)); }
            catch (Throwable ignored) {}
        }
    }

    private void workerLoop(long myGeneration) {
        vosk = new VoskEngine(app);
        try {
            if (!vosk.isReady()) {
                broadcastLive(myGeneration, "");
                setStatusIfCurrent(myGeneration, ModelManager.voskInstalled(app)
                        ? "Vosk: ошибка загрузки"
                        : "Нет модели Vosk — импортируйте в «Модели»");
                return;
            }
            broadcastLive(myGeneration, "");
            while (true) {
                synchronized (this) {
                    if (myGeneration != generation || cancelRequested) break;
                    if (!running && queue.isEmpty()) break;
                }
                if (myGeneration != generation || cancelRequested) break;
                java.util.ArrayList<short[]> batch = new java.util.ArrayList<>();
                try {
                    short[] first = queue.poll(200, java.util.concurrent.TimeUnit.MILLISECONDS);
                    if (first == null) {
                        if (!running && queue.isEmpty()) break;
                        continue;
                    }
                    batch.add(first);
                    short[] more;
                    while ((more = queue.poll()) != null && batch.size() < 16) batch.add(more);
                } catch (InterruptedException ie) { break; }
                if (myGeneration != generation || cancelRequested) break;
                int n = 0;
                for (short[] c : batch) n += c.length;
                short[] chunk = new short[n];
                int off = 0;
                for (short[] c : batch) { System.arraycopy(c, 0, chunk, off, c.length); off += c.length; }
                VoskEngine.Result result = vosk.acceptDetailed(chunk, n);
                String hyp = result.text;
                if (hyp != null && !hyp.isEmpty()) {
                    String clean = AutoTranscriber.cleanHallucinations(hyp).trim();
                    if (!clean.isEmpty()) {
                        accumulated = result.isFinal ? merge(accumulated, clean) : clean;
                        broadcastLive(myGeneration, clean);
                        boolean systemCommand = EmergencySecurity.matches(app, clean)
                                || AutoTranscriber.looksLikeMemoryQuestion(clean)
                                || AutoTranscriber.looksLikeMediaRestoreCommand(clean)
                                || AutoTranscriber.looksLikeMediaDuckCommand(clean)
                                || AutoTranscriber.looksLikeStopCommand(clean);
                        if (result.isFinal && !systemCommand) RealtimeRingStore.appendFinal(app, clean);
                        handleCommandIfNeeded(myGeneration, clean);
                    }
                }
            }
            if (myGeneration == generation && !cancelRequested) {
                String fin = vosk.flush();
                if (fin != null && !fin.isEmpty()) {
                    String clean = AutoTranscriber.cleanHallucinations(fin).trim();
                    if (!clean.isEmpty()) {
                        accumulated = merge(accumulated, clean);
                        broadcastLive(myGeneration, clean);
                        if (!isSystemCommand(clean)) RealtimeRingStore.appendFinal(app, clean);
                        handleCommandIfNeeded(myGeneration, clean);
                    }
                }
            }
        } finally {
            if (vosk != null) { try { vosk.release(); } catch (Throwable ignored) {} vosk = null; }
            synchronized (this) {
                if (Thread.currentThread() == worker) worker = null;
                if (myGeneration == generation) entry = null;
            }
        }
    }

    private void handleCommandIfNeeded(long myGeneration, String clean) {
        if (!commandHandled && EmergencySecurity.matches(app, clean)) {
            commandHandled = true;
            try { app.startService(new Intent(app, RecordingService.class).setAction(RecordingService.EMERGENCY_WIPE)); } catch (Throwable ignored) {}
            return;
        }
        if (!commandHandled && AutoTranscriber.looksLikeMemoryQuestion(clean)) {
            commandHandled = true;
            if (entry != null) entry.handsFreeHandled = true;
            AutoTranscriber.processHandsFreeMemoryRecall(app, clean);
            return;
        }
        if (!commandHandled && AutoTranscriber.looksLikeMediaRestoreCommand(clean)) {
            commandHandled = true;
            try { app.startService(new Intent(app, RecordingService.class).setAction(RecordingService.RESTORE_MEDIA)); } catch (Throwable ignored) {}
            return;
        }
        if (!commandHandled && AutoTranscriber.looksLikeMediaDuckCommand(clean)) {
            commandHandled = true;
            try { app.startService(new Intent(app, RecordingService.class).setAction(RecordingService.DUCK_MEDIA)); } catch (Throwable ignored) {}
            return;
        }
        if (!commandHandled && AutoTranscriber.looksLikeStopCommand(clean)) {
            commandHandled = true;
            try { app.startService(new Intent(app, RecordingService.class).setAction(RecordingService.STOP)); } catch (Throwable ignored) {}
        }
    }

    private boolean isSystemCommand(String clean) {
        return EmergencySecurity.matches(app, clean)
                || AutoTranscriber.looksLikeMemoryQuestion(clean)
                || AutoTranscriber.looksLikeMediaRestoreCommand(clean)
                || AutoTranscriber.looksLikeMediaDuckCommand(clean)
                || AutoTranscriber.looksLikeStopCommand(clean);
    }

    private boolean isCurrent(long myGeneration) {
        return running && !cancelRequested && myGeneration == generation;
    }

    private void broadcastLive(long myGeneration, String text) {
        if (myGeneration != generation) return;
        try {
            Intent live = new Intent(LIVE_TEXT).setPackage(app.getPackageName());
            live.putExtra("text", text == null ? "" : text);
            live.putExtra("on_device", usingOnDevice);
            app.sendBroadcast(live);
        } catch (Throwable ignored) {}
    }

    private void setStatusIfCurrent(long myGeneration, String status) {
        synchronized (this) {
            if (myGeneration != generation || entry == null) return;
            entry.status = status;
            new EntryStore(app).replace(entry);
        }
        app.sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
    }

    /** Returns raw final ASR for the current clip, before Gemini editing. */
    public synchronized String currentFinalText() {
        return accumulated == null ? "" : accumulated.trim();
    }

    /** Kept for compatibility: Vosk/System ASR never publishes directly to History. */
    public synchronized void publish() {}
    public synchronized boolean isPublished() { return false; }

    public synchronized void finish() {
        running = false;
        main.post(this::stopOnDeviceRecognizer);
        if (worker != null) worker.interrupt();
    }

    /** Stop recognition and return the raw text already received for this clip. */
    public String finishAndGetText() {
        String before;
        synchronized (this) {
            before = currentFinalText();
            finishRequested = true;
        }
        if (usingOnDevice) {
            // stopListening() normally delivers the final result asynchronously.
            // Give the main thread a short window to deliver that callback before
            // reading the raw clip text; this avoids losing the last sentence.
            main.post(() -> {
                try { if (onDeviceRecognizer != null) onDeviceRecognizer.stopListening(); } catch (Throwable ignored) {}
            });
            try { Thread.sleep(350L); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            String after = currentFinalText();
            if (!after.isEmpty()) before = after;
        } else if (worker != null) {
            worker.interrupt();
        }
        synchronized (this) {
            running = false;
            finishRequested = false;
        }
        main.post(this::stopOnDeviceRecognizer);
        return before;
    }

    private void stopOnDeviceRecognizer() {
        try { if (onDeviceRecognizer != null) onDeviceRecognizer.stopListening(); } catch (Throwable ignored) {}
        try { if (onDeviceRecognizer != null) onDeviceRecognizer.cancel(); } catch (Throwable ignored) {}
        try { if (onDeviceRecognizer != null) onDeviceRecognizer.destroy(); } catch (Throwable ignored) {}
        onDeviceRecognizer = null;
    }

    public synchronized void cancel() {
        running = false;
        finishRequested = false;
        cancelRequested = true;
        generation++;
        queue.clear();
        main.removeCallbacksAndMessages(null);
        main.post(this::stopOnDeviceRecognizer);
        Thread t = worker;
        if (t != null) t.interrupt();
        entry = null;
        accumulated = "";
        lastPartial = "";
        try {
            Intent live = new Intent(LIVE_TEXT).setPackage(app.getPackageName());
            live.putExtra("text", "");
            live.putExtra("on_device", usingOnDevice);
            app.sendBroadcast(live);
        } catch (Throwable ignored) {}
    }

    public synchronized void stop() { finish(); }
    public synchronized String currentText() { return accumulated; }
    public boolean isBusy() { return running; }

    static String merge(String oldText, String newText) {
        String a = oldText == null ? "" : oldText.trim();
        String b = newText == null ? "" : newText.trim();
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;
        if (b.equalsIgnoreCase(a)) return a;
        if (b.startsWith(a)) return b;
        if (a.contains(b)) return a;
        // Avoid duplicating overlapping tails when the recognizer restarts.
        String[] aw = a.split("\\s+");
        String[] bw = b.split("\\s+");
        int max = Math.min(8, Math.min(aw.length, bw.length));
        for (int k = max; k >= 1; k--) {
            boolean same = true;
            for (int i = 0; i < k; i++) {
                if (!aw[aw.length - k + i].equalsIgnoreCase(bw[i])) { same = false; break; }
            }
            if (same) {
                StringBuilder sb = new StringBuilder(a);
                for (int i = k; i < bw.length; i++) sb.append(' ').append(bw[i]);
                return sb.toString().trim();
            }
        }
        return a + " " + b;
    }
}
