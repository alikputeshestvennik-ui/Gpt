package com.blackbox.offline;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.method.ScrollingMovementMethod;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.Locale;

/** Device-local capability diagnostics. No network calls. */
public class AiDiagnosticsActivity extends Activity {
    private LinearLayout root;
    private TextView report;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        build();
        runQuickDiagnostics();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI.COLOR_BG);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UI.dp(this, 18), UI.dp(this, 20), UI.dp(this, 18), UI.dp(this, 24));
        root.addView(UI.createHeader(this, "Диагностика AI", "ASR · Gemma · TTS · аппаратное ускорение", true));

        TextView intro = new TextView(this);
        intro.setText("Проверяем реальные возможности этого телефона. Диагностика не использует интернет и не отправляет аудио или текст наружу.");
        intro.setTextColor(UI.COLOR_TEXT_MUTED);
        intro.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        intro.setLineSpacing(UI.dp(this, 2), 1f);
        intro.setPadding(0, 0, 0, UI.dp(this, 14));
        root.addView(intro);

        report = new TextView(this);
        report.setTextColor(UI.COLOR_TEXT_PRIMARY);
        report.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        report.setLineSpacing(UI.dp(this, 3), 1f);
        report.setMovementMethod(new ScrollingMovementMethod());
        LinearLayout card = UI.createCard(this);
        card.addView(report);
        root.addView(card);

        Button refresh = UI.primaryButton(this, "Проверить заново");
        refresh.setOnClickListener(v -> runQuickDiagnostics());
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = UI.dp(this, 14);
        root.addView(refresh, rp);

        Button gpu = UI.secondaryButton(this, "Тест Gemma · GPU");
        gpu.setOnClickListener(v -> runBackendProbe("GPU"));
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2);
        gp.topMargin = UI.dp(this, 10);
        root.addView(gpu, gp);

        Button cpu = UI.secondaryButton(this, "Тест Gemma · CPU");
        cpu.setOnClickListener(v -> runBackendProbe("CPU"));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = UI.dp(this, 10);
        root.addView(cpu, cp);

        Button asr = UI.secondaryButton(this, "Проверить русский on-device ASR");
        asr.setOnClickListener(v -> testAsrSupport());
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.topMargin = UI.dp(this, 10);
        root.addView(asr, ap);

        scroll.addView(root);
        setContentView(scroll);
    }

    private void runQuickDiagnostics() {
        report.setText("Проверка…");
        new Thread(() -> {
            StringBuilder s = new StringBuilder();
            s.append("Устройство\n").append(GemmaEngine.deviceInfo()).append("\n\n");

            boolean asr = SpeechRecognizer.isOnDeviceRecognitionAvailable(this);
            s.append(status(asr)).append("  On-device ASR\n");
            s.append(asr ? "  Android предоставляет локальный SpeechRecognizer.\n" : "  Локальный SpeechRecognizer недоступен; нужен Vosk fallback.\n");

            boolean tts = VoiceOutput.isOfflineVoiceAvailable(this);
            s.append(status(tts)).append("  Offline TTS · русский\n");
            s.append(tts ? "  Системный русский голос не требует сети.\n" : "  Установите русский офлайн-голос в настройках синтеза речи.\n");

            boolean gemma = GemmaEngine.modelPresent(this);
            s.append(status(gemma)).append("  Gemma · модель\n");
            s.append("  ").append(GemmaEngine.modelSize(this)).append("\n");
            s.append("  Файл: ").append(ModelManager.file(this, ModelManager.GEMMA).getAbsolutePath()).append("\n");

            boolean runtime = hasClass("com.google.ai.edge.litertlm.Engine");
            s.append(status(runtime)).append("  LiteRT-LM runtime\n");
            s.append(runtime ? "  Android API подключён.\n" : "  Runtime не попал в APK.\n");

            s.append("⚡  NPU · Samsung System LSI\n");
            s.append("  Публичный LiteRT NPU delegate для Samsung System LSI пока не заявлен; Blackbox не будет притворяться, что NPU работает.\n");
            s.append("  GPU/CPU проверяются отдельными реальными probe-тестами.\n");

            s.append("\nGemma backend сейчас: ").append(GemmaEngine.backendName()).append("\n");
            String err = GemmaEngine.lastError();
            if (err != null && !err.isEmpty()) s.append("Последняя ошибка: ").append(err).append("\n");

            runOnUiThread(() -> report.setText(s.toString()));
        }).start();
    }

    private void runBackendProbe(String backend) {
        report.append("\n⏳ Проверяю Gemma на " + backend + "…\n");
        new Thread(() -> {
            String result = GemmaEngine.probeBackend(this, backend);
            runOnUiThread(() -> report.append("\n" + backend + ": " + result + "\n"));
        }, "blackbox-gemma-probe-" + backend.toLowerCase(Locale.US)).start();
    }

    private void testAsrSupport() {
        new Thread(() -> {
            String result;
            try {
                if (!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                    result = "❌ On-device ASR недоступен.";
                } else {
                    SpeechRecognizer r = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
                    r.destroy();
                    result = "✅ On-device SpeechRecognizer создан успешно.\nРусский язык дополнительно проверяется системой при выборе модели/языка.";
                }
            } catch (Throwable t) {
                result = "❌ ASR probe: " + t.getMessage();
            }
            String out = result;
            runOnUiThread(() -> report.append("\nASR probe:\n" + out + "\n"));
        }, "blackbox-asr-probe").start();
    }

    private static boolean hasClass(String name) {
        try { Class.forName(name); return true; } catch (Throwable t) { return false; }
    }

    private static String status(boolean ok) { return ok ? "✅" : "❌"; }
}
