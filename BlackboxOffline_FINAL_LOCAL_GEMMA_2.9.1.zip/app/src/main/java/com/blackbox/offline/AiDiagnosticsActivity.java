package com.blackbox.offline;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.Manifest;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.text.method.ScrollingMovementMethod;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.Locale;

/** Device-local capability diagnostics. No network calls. */
public class AiDiagnosticsActivity extends Activity {
    private LinearLayout root;
    private TextView report;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        build();
        runQuickDiagnostics();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI.COLOR_BG);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UI.dp(this, 18), UI.dp(this, 20), UI.dp(this, 18), UI.dp(this, 24));
        root.addView(UI.createHeader(this, "Диагностика AI", "ASR · Gemma · TTS · аппаратное ускорение", true));

        TextView intro = new TextView(this);
        intro.setText("Проверяем реальные возможности этого телефона. Диагностика не использует интернет и не отправляет аудио или текст наружу.");
        intro.setTextColor(UI.COLOR_TEXT_MUTED);
        intro.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        intro.setLineSpacing(UI.dp(this, 2), 1f);
        intro.setPadding(0, 0, 0, UI.dp(this, 14));
        root.addView(intro);

        report = new TextView(this);
        report.setTextColor(UI.COLOR_TEXT_PRIMARY);
        report.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        report.setLineSpacing(UI.dp(this, 3), 1f);
        report.setMovementMethod(new ScrollingMovementMethod());
        LinearLayout card = UI.createCard(this);
        card.addView(report);
        root.addView(card);

        Button refresh = UI.primaryButton(this, "Проверить заново");
        refresh.setOnClickListener(v -> runQuickDiagnostics());
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = UI.dp(this, 14);
        root.addView(refresh, rp);

        Button gpu = UI.secondaryButton(this, "Тест Gemma · GPU");
        gpu.setOnClickListener(v -> runBackendProbe("GPU"));
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2);
        gp.topMargin = UI.dp(this, 10);
        root.addView(gpu, gp);

        Button cpu = UI.secondaryButton(this, "Тест Gemma · CPU");
        cpu.setOnClickListener(v -> runBackendProbe("CPU"));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = UI.dp(this, 10);
        root.addView(cpu, cp);

        Button asr = UI.secondaryButton(this, "Проверить русский on-device ASR");
        asr.setOnClickListener(v -> testAsrSupport());
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.topMargin = UI.dp(this, 10);
        root.addView(asr, ap);

        scroll.addView(root);
        setContentView(scroll);
    }

    private void runQuickDiagnostics() {
        report.setText("Проверка…");
        new Thread(() -> {
            StringBuilder s = new StringBuilder();
            s.append("Устройство\n").append(GemmaEngine.deviceInfo()).append("\n\n");

            boolean asr = SpeechRecognizer.isOnDeviceRecognitionAvailable(this);
            s.append(status(asr)).append("  On-device ASR\n");
            s.append(asr ? "  Android предоставляет локальный SpeechRecognizer.\n" : "  Локальный SpeechRecognizer недоступен; нужен Vosk fallback.\n");

            boolean tts = VoiceOutput.isOfflineVoiceAvailable(this);
            s.append(status(tts)).append("  Offline TTS · русский\n");
            s.append(tts ? "  Системный русский голос не требует сети.\n" : "  Установите русский офлайн-голос в настройках синтеза речи.\n");

            boolean gemma = GemmaEngine.modelPresent(this);
            s.append(status(gemma)).append("  Gemma · модель\n");
            s.append("  ").append(GemmaEngine.modelSize(this)).append("\n");
            s.append("  Файл: ").append(ModelManager.file(this, ModelManager.GEMMA).getAbsolutePath()).append("\n");

            boolean runtime = hasClass("com.google.ai.edge.litertlm.Engine");
            s.append(status(runtime)).append("  LiteRT-LM runtime\n");
            s.append(runtime ? "  Android API подключён.\n" : "  Runtime не попал в APK.\n");

            s.append("⚡  NPU · Samsung System LSI\n");
            s.append("  Публичный LiteRT NPU delegate для Samsung System LSI пока не заявлен; Blackbox не будет притворяться, что NPU работает.\n");
            s.append("  GPU/CPU проверяются отдельными реальными probe-тестами.\n");

            s.append("\nGemma backend сейчас: ").append(GemmaEngine.backendName()).append("\n");
            String err = GemmaEngine.lastError();
            if (err != null && !err.isEmpty()) s.append("Последняя ошибка: ").append(err).append("\n");

            runOnUiThread(() -> report.setText(s.toString()));
        }).start();
    }

    private void runBackendProbe(String backend) {
        report.append("\n⏳ Проверяю Gemma на " + backend + "…\n");
        new Thread(() -> {
            String result = GemmaEngine.probeBackend(this, backend);
            runOnUiThread(() -> report.append("\n" + backend + ": " + result + "\n"));
        }, "blackbox-gemma-probe-" + backend.toLowerCase(Locale.US)).start();
    }

    private static final int REQ_ASR_PERMISSION = 7401;
    private SpeechRecognizer asrProbe;

    private void testAsrSupport() {
        // SpeechRecognizer must be created/used on the application's main thread.
        // The previous diagnostic incorrectly created it from a worker thread,
        // which produced: "SpeechRecognizer should be used only from the application's main thread".
        if (!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            report.append("\nASR probe:\n❌ On-device ASR недоступен на этом устройстве.\n");
            return;
        }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            report.append("\nASR probe:\n⏳ Нужен доступ к микрофону…\n");
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_ASR_PERMISSION);
            return;
        }

        startAsrProbeOnMainThread();
    }

    private void startAsrProbeOnMainThread() {
        if (!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            report.append("\nASR probe:\n❌ On-device ASR недоступен.\n");
            return;
        }

        try {
            if (asrProbe != null) {
                try { asrProbe.cancel(); } catch (Throwable ignored) {}
                try { asrProbe.destroy(); } catch (Throwable ignored) {}
                asrProbe = null;
            }

            asrProbe = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            asrProbe.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(android.os.Bundle params) {
                    report.append("\nASR probe:\n🎙️ Скажите фразу по-русски…\n");
                }
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float rmsdB) {}
                @Override public void onBufferReceived(byte[] buffer) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onPartialResults(android.os.Bundle partialResults) {}
                @Override public void onEvent(int eventType, android.os.Bundle params) {}

                @Override public void onResults(android.os.Bundle results) {
                    java.util.ArrayList<String> values =
                            results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String text = (values != null && !values.isEmpty()) ? values.get(0) : "";
                    report.append("\nASR probe:\n" +
                            (text.isEmpty()
                                    ? "⚠️ Распознавание завершено, текст не получен."
                                    : "✅ On-device ASR работает.\nРаспознано: «" + text + "»") + "\n");
                    destroyAsrProbe();
                }

                @Override public void onError(int error) {
                    report.append("\nASR probe:\n❌ Ошибка распознавания: " + asrError(error) + "\n");
                    destroyAsrProbe();
                }
            });

            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ru-RU");
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);

            report.append("\nASR probe:\n⏳ Запускаю on-device русский ASR…\n");
            asrProbe.startListening(intent);
        } catch (Throwable t) {
            report.append("\nASR probe:\n❌ " + t.getMessage() + "\n");
            destroyAsrProbe();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_ASR_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startAsrProbeOnMainThread();
            } else {
                report.append("\nASR probe:\n❌ Доступ к микрофону не предоставлен.\n");
            }
        }
    }

    private void destroyAsrProbe() {
        // Called from RecognitionListener callbacks, which are delivered on the main thread.
        if (asrProbe != null) {
            try { asrProbe.destroy(); } catch (Throwable ignored) {}
            asrProbe = null;
        }
    }

    @Override protected void onDestroy() {
        destroyAsrProbe();
        super.onDestroy();
    }

    private static String asrError(int code) {
        switch (code) {
            case SpeechRecognizer.ERROR_AUDIO: return "ERROR_AUDIO";
            case SpeechRecognizer.ERROR_CLIENT: return "ERROR_CLIENT";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "ERROR_INSUFFICIENT_PERMISSIONS";
            case SpeechRecognizer.ERROR_NETWORK: return "ERROR_NETWORK (для offline-теста неожиданно)";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "ERROR_NETWORK_TIMEOUT";
            case SpeechRecognizer.ERROR_NO_MATCH: return "ERROR_NO_MATCH — речь не распознана";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "ERROR_RECOGNIZER_BUSY";
            case SpeechRecognizer.ERROR_SERVER: return "ERROR_SERVER";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "ERROR_SPEECH_TIMEOUT — не было речи";
            default: return "код " + code;
        }
    }

    private static boolean hasClass(String name) {
        try { Class.forName(name); return true; } catch (Throwable t) { return false; }
    }

    private static String status(boolean ok) { return ok ? "✅" : "❌"; }
}
