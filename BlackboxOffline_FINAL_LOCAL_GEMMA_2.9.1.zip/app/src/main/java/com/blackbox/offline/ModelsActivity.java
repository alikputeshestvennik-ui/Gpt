package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.*;
import android.util.TypedValue;
import android.view.*;
import android.widget.*;

public class ModelsActivity extends Activity {
    private static final int REQ_WHISPER = 1;
    private static final int REQ_GEMMA = 2;
    private LinearLayout container;

    @Override public void onCreate(Bundle b) { super.onCreate(b); draw(); }

    private void draw() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI.COLOR_BG);
        container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(UI.dp(this,18), UI.dp(this,20), UI.dp(this,18), UI.dp(this,24));
        container.addView(UI.createHeader(this, "AI-Модели", "On-device ASR · Local Gemma · Offline TTS", true));

        boolean asr = RealtimeTranscriber.isOnDeviceAvailable(this);
        boolean tts = VoiceOutput.isOfflineVoiceAvailable(this);
        boolean gemma = ModelManager.installed(this, ModelManager.GEMMA);

        LinearLayout status = UI.createCard(this);
        TextView st = new TextView(this);
        st.setText("СИСТЕМА\n" + (asr ? "✅ On-device ASR" : "❌ On-device ASR") + "\n"
                + (gemma ? "✅ Gemma" : "❌ Gemma — импортируйте .litertlm") + "\n"
                + (tts ? "✅ Offline TTS · русский" : "❌ Offline TTS · русский голос не найден"));
        st.setTextColor(UI.COLOR_TEXT_PRIMARY);
        st.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        st.setLineSpacing(UI.dp(this,3),1f);
        status.addView(st);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1,-2);
        slp.bottomMargin = UI.dp(this,16);
        container.addView(status, slp);

        Button diag = UI.primaryButton(this, "Открыть полную диагностику AI");
        diag.setOnClickListener(v -> startActivity(new Intent(this, AiDiagnosticsActivity.class)));
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1,-2);
        dlp.bottomMargin = UI.dp(this,16);
        container.addView(diag, dlp);

        addGemmaCard(gemma);
        addWhisperCard();

        scroll.addView(container);
        setContentView(scroll);
    }

    private void addGemmaCard(boolean installed) {
        LinearLayout card = UI.createCard(this);
        if (installed) card.setBackground(UI.shape(0xFF131915, 0xFF1F4426, 18, this));
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(UI.badge(this, "LOCAL LLM", UI.COLOR_ORANGE, UI.COLOR_ORANGE_DIM));
        View sp = new View(this);
        top.addView(sp, new LinearLayout.LayoutParams(0,1,1f));
        top.addView(UI.badge(this, installed ? "УСТАНОВЛЕНА" : "НУЖНА", installed ? UI.COLOR_GREEN : UI.COLOR_RED,
                installed ? UI.COLOR_GREEN_BG : 0x22EF4444));
        card.addView(top);

        TextView title = new TextView(this);
        title.setText("Gemma · LiteRT-LM");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP,18);
        title.setTextColor(UI.COLOR_TEXT_TITLE);
        title.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
        title.setPadding(0,UI.dp(this,10),0,UI.dp(this,4));
        card.addView(title);

        TextView desc = new TextView(this);
        desc.setText("Единый локальный интеллект Blackbox: редактирование ASR, вопросы к памяти, пересказ дня и сложные текстовые/голосовые запросы. Интернет для генерации не нужен.");
        desc.setTextColor(UI.COLOR_TEXT_MUTED);
        desc.setTextSize(TypedValue.COMPLEX_UNIT_SP,13);
        desc.setLineSpacing(UI.dp(this,2),1f);
        card.addView(desc);

        TextView size = new TextView(this);
        size.setText("Файл: " + GemmaEngine.modelSize(this));
        size.setTextColor(installed ? UI.COLOR_TEXT_ORANGE : UI.COLOR_TEXT_SUBTLE);
        size.setTextSize(TypedValue.COMPLEX_UNIT_SP,12);
        size.setPadding(0,UI.dp(this,8),0,UI.dp(this,14));
        card.addView(size);

        TextView backend = new TextView(this);
        backend.setText(installed ? "Backend: " + GemmaEngine.backendName() + " · GPU → CPU fallback" : "Рекомендуется мобильный Gemma .litertlm, например Gemma 4 E2B-it в квантованном мобильном формате.");
        backend.setTextColor(UI.COLOR_TEXT_MUTED);
        backend.setTextSize(TypedValue.COMPLEX_UNIT_SP,12);
        backend.setPadding(0,0,0,UI.dp(this,12));
        card.addView(backend);

        Button importBtn = UI.primaryButton(this, installed ? "Заменить Gemma .litertlm" : "Импортировать Gemma .litertlm");
        importBtn.setOnClickListener(v -> pickFile(REQ_GEMMA));
        card.addView(importBtn);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2);
        lp.bottomMargin = UI.dp(this,16);
        container.addView(card,lp);
    }

    private void addWhisperCard() {
        boolean installed = ModelManager.installed(this, ModelManager.WHISPER);
        LinearLayout card = UI.createCard(this);
        TextView title = new TextView(this);
        title.setText("Whisper Base · fallback ASR");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP,17);
        title.setTextColor(UI.COLOR_TEXT_TITLE);
        title.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
        card.addView(title);
        TextView desc = new TextView(this);
        desc.setText("Оставлен как локальный fallback для случаев, когда системный on-device ASR недоступен.");
        desc.setTextColor(UI.COLOR_TEXT_MUTED);
        desc.setTextSize(TypedValue.COMPLEX_UNIT_SP,13);
        desc.setPadding(0,UI.dp(this,6),0,UI.dp(this,12));
        card.addView(desc);
        TextView size = new TextView(this);
        size.setText("Файл: " + ModelManager.size(this, ModelManager.WHISPER));
        size.setTextColor(UI.COLOR_TEXT_SUBTLE);
        size.setTextSize(TypedValue.COMPLEX_UNIT_SP,12);
        card.addView(size);
        Button btn = UI.secondaryButton(this, installed ? "Заменить Whisper .bin" : "Импортировать Whisper .bin");
        btn.setOnClickListener(v -> pickFile(REQ_WHISPER));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1,-2);
        blp.topMargin = UI.dp(this,12);
        card.addView(btn,blp);
        container.addView(card);
    }

    private void pickFile(int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, req);
    }

    @Override protected void onActivityResult(int req,int res,Intent data) {
        super.onActivityResult(req,res,data);
        if(res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        Toast.makeText(this,"Копирование модели во внутреннюю память…",Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                String target = req == REQ_GEMMA ? ModelManager.GEMMA : ModelManager.WHISPER;
                ModelManager.importFile(this, uri, target);
                runOnUiThread(() -> { Toast.makeText(this,"Модель установлена.",Toast.LENGTH_SHORT).show(); draw(); });
            } catch(Exception e) {
                runOnUiThread(() -> Toast.makeText(this,"Ошибка импорта: " + e.getMessage(),Toast.LENGTH_LONG).show());
            }
        }).start();
    }
}
