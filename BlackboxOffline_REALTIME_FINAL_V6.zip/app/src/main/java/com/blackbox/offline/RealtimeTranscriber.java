package com.blackbox.offline;

import android.content.Context;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.Locale;

/**
 * Low-latency Whisper streaming adapter.
 * Audio is supplied directly from AudioRecord; no WAV round-trip is used for
 * realtime text. A small overlapping window is decoded on a single persistent
 * Whisper context and merged into the live Entry.
 */
public final class RealtimeTranscriber {
    private static final int SAMPLE_RATE = 16000;
    private static final int WINDOW_SAMPLES = (int)(SAMPLE_RATE * 2.5f); // 2.5 s: better Base accuracy
    private static final int STEP_SAMPLES = (int)(SAMPLE_RATE * 1.25f); // 1.25 s: still responsive
    private static final int MAX_BUFFER_SAMPLES = SAMPLE_RATE * 4; // 4 s safety buffer

    private final Context app;
    private final BlockingQueue<float[]> latest = new ArrayBlockingQueue<>(1);
    private volatile boolean running;
    private volatile boolean busy;
    private volatile boolean cancelRequested;
    private volatile boolean finishing;
    private long generation;
    private Thread worker;
    private Entry entry;
    private float[] ring = new float[MAX_BUFFER_SAMPLES];
    private int ringWrite;
    private int ringCount;
    private int samplesSinceSubmit;
    private String accumulated = "";
    private boolean published;
    private boolean commandHandled;

    public RealtimeTranscriber(Context c) {
        app = c.getApplicationContext();
    }

    public synchronized void start(Entry e) {
        if (e == null) return;
        if (running || worker != null) cancel();
        final long myGeneration = ++generation;
        entry = e;
        accumulated = e.transcript == null ? "" : e.transcript;
        ringWrite = 0;
        ringCount = 0;
        samplesSinceSubmit = 0;
        running = true;
        cancelRequested = false;
        finishing = false;
        published = false;
        commandHandled = false;
        worker = new Thread(() -> workerLoop(myGeneration), "blackbox-whisper-realtime");
        worker.start();
    }

    public void feed(short[] pcm, int n) {
        if (!running || pcm == null || n <= 0) return;
        synchronized (this) {
            for (int i = 0; i < n; i++) {
                ring[ringWrite] = pcm[i] / 32768.0f;
                ringWrite = (ringWrite + 1) % ring.length;
                if (ringCount < ring.length) ringCount++;
            }
            samplesSinceSubmit += n;
            if (ringCount >= WINDOW_SAMPLES && samplesSinceSubmit >= STEP_SAMPLES) {
                samplesSinceSubmit = 0;
                float[] snapshot = snapshotLocked(WINDOW_SAMPLES);
                latest.poll();
                latest.offer(snapshot);
            }
        }
    }

    private float[] snapshotLocked(int count) {
        float[] out = new float[count];
        int start = (ringWrite - count + ring.length) % ring.length;
        for (int i = 0; i < count; i++) out[i] = ring[(start + i) % ring.length];
        return out;
    }

    private void workerLoop(long myGeneration) {
        LocalAiEngine engine = new LocalAiEngine(app);
        try {
            if (!engine.whisperReady()) {
                setStatusIfCurrent(myGeneration, "Нет модели Whisper");
                return;
            }
            while (true) {
                synchronized (this) {
                    if (myGeneration != generation || cancelRequested) break;
                    if (!running && latest.isEmpty() && !busy) break;
                }
                try {
                    float[] chunk = latest.poll(250, java.util.concurrent.TimeUnit.MILLISECONDS);
                    if (chunk == null) continue;
                    synchronized (this) {
                        if (myGeneration != generation || cancelRequested) break;
                        busy = true;
                    }
                    String part = engine.transcribeRealtimePcm(chunk);
                    synchronized (this) { if (myGeneration == generation) busy = false; }
                    if (myGeneration != generation || cancelRequested) continue;
                    if (part != null && !part.trim().isEmpty()) {
                        synchronized (this) {
                            accumulated = merge(accumulated, AutoTranscriber.cleanHallucinations(part));
                            if (myGeneration == generation && entry != null && published) {
                                entry.transcript = accumulated.trim();
                                entry.status = "Расшифровка в реальном времени…";
                                new EntryStore(app).upsert(entry);
                                if (!commandHandled) {
                                    String live = entry.transcript;
                                    String low = live == null ? "" : live.toLowerCase(Locale.ROOT);
                                    if (low.contains("стоп") && (low.contains("блэкбокс") || low.contains("блокбук") || low.contains("blackbox"))) {
                                        commandHandled = true;
                                        AutoTranscriber.processRealtimeEntry(app, entry);
                                    } else if (low.contains("блэкбокс важно") || low.contains("запомни это") || low.contains("очень важно")) {
                                        AutoTranscriber.processRealtimeEntry(app, entry);
                                    }
                                }
                            }
                        }
                        broadcast();
                    }
                } catch (InterruptedException ignored) {
                    if (!running || cancelRequested) break;
                } catch (Throwable ignored) {
                    synchronized (this) { if (myGeneration == generation) busy = false; }
                }
            }
        } finally {
            synchronized (this) {
                if (myGeneration == generation) {
                    busy = false;
                    if (finishing && entry != null) {
                        entry.status = "Готово";
                        new EntryStore(app).replace(entry);
                    }
                    if (Thread.currentThread() == worker) worker = null;
                    entry = null;
                } else if (Thread.currentThread() == worker) {
                    // A cancelled generation may still return from native Whisper.
                    // Do not leave a dead Thread reference behind.
                    worker = null;
                }
            }
        }
    }

    private void setStatusIfCurrent(long myGeneration, String status) {
        synchronized (this) {
            if (myGeneration != generation || entry == null) return;
            entry.status = status;
            new EntryStore(app).replace(entry);
        }
        broadcast();
    }

    private void broadcast() {
        app.sendBroadcast(new android.content.Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
    }

    /** Finish the current clip without discarding an in-flight Whisper decode. */
    public synchronized void publish() {
        if (entry == null) return;
        published = true;
        entry.transcript = accumulated == null ? "" : accumulated.trim();
        new EntryStore(app).upsert(entry);
        broadcast();
    }

    public synchronized boolean isPublished() { return published; }

    public synchronized void finish() {
        running = false;
        finishing = true;
        // Do not clear latest: let the worker finish the newest snapshot.
        // Do not interrupt a native decode: Java interruption cannot stop whisper_full().
        if (!busy && worker != null) worker.interrupt();
    }

    /** Abort the current clip and explicitly discard its realtime state. */
    public synchronized void cancel() {
        running = false;
        finishing = false;
        generation++;
        cancelRequested = true;
        latest.clear();
        Thread t = worker;
        if (t != null) t.interrupt();
        entry = null;
        // If native Whisper is already running, busy stays true until it returns.
        // This prevents a second clip from treating the old decoder as idle.
    }

    /** Backward-compatible alias: normal stop now drains instead of dropping the result. */
    public synchronized void stop() { finish(); }

    public synchronized String currentText() {
        return accumulated;
    }

    public boolean isBusy() { return busy; }

    /** Merge overlapping Whisper windows without duplicating the overlap. */
    static String merge(String oldText, String newText) {
        String a = oldText == null ? "" : oldText.trim();
        String b = newText == null ? "" : newText.trim();
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;

        String[] aw = a.split("\\s+");
        String[] bw = b.split("\\s+");
        int max = Math.min(12, Math.min(aw.length, bw.length));
        int best = 0;
        for (int n = max; n >= 1; n--) {
            boolean ok = true;
            for (int i = 0; i < n; i++) {
                if (!norm(aw[aw.length - n + i]).equals(norm(bw[i]))) { ok = false; break; }
            }
            if (ok) { best = n; break; }
        }
        if (best > 0) {
            StringBuilder sb = new StringBuilder(a);
            for (int i = best; i < bw.length; i++) sb.append(' ').append(bw[i]);
            return sb.toString().trim();
        }

        // If Whisper returns exactly the same short phrase, don't append it.
        if (norm(a).equals(norm(b))) return a;
        return (a + " " + b).trim();
    }

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT)
                .replaceAll("[.,!?;:—–-]+", " ")
                .replaceAll("\\s+", " ").trim();
    }
}
