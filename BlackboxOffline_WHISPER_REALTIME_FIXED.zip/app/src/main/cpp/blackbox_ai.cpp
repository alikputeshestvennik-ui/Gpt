#include <jni.h>
#include <android/log.h>
#include <string>
#include <mutex>
#include <thread>
#include <algorithm>
#include "whisper.h"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,"BlackboxAI",__VA_ARGS__)

// One persistent context is deliberately used. Two simultaneous Whisper
// decoders fight for the same mobile CPU/cache and often make latency worse.
static whisper_context* g_ctx = nullptr;
static std::mutex g_mu;
static std::string g_path;

static whisper_context* load_ctx(const std::string& model) {
    whisper_context_params cp = whisper_context_default_params();
#if defined(__aarch64__)
    cp.use_gpu = false; // CPU/NEON is the portable Android path; keep it deterministic.
#else
    cp.use_gpu = false;
#endif
    cp.flash_attn = true;
    return whisper_init_from_file_with_params(model.c_str(), cp);
}

static whisper_context* ensure_ctx(const std::string& model) {
    std::lock_guard<std::mutex> lock(g_mu);
    if (!g_ctx || g_path != model) {
        if (g_ctx) whisper_free(g_ctx);
        g_ctx = load_ctx(model);
        g_path = model;
    }
    return g_ctx;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_blackbox_offline_LocalAiEngine_nativeWarm(JNIEnv *env, jobject, jstring modelPath) {
    const char *path = env->GetStringUTFChars(modelPath, nullptr);
    std::string model(path);
    env->ReleaseStringUTFChars(modelPath, path);
    return ensure_ctx(model) ? JNI_TRUE : JNI_FALSE;
}

static int choose_threads() {
    unsigned int hc = std::thread::hardware_concurrency();
    if (hc == 0) return 2;
    // Leave at least one core for AudioRecord/Android. Avoid two decoders.
    return (int)std::max(2u, std::min(6u, hc > 1 ? hc - 1 : 2u));
}

static std::string decode(whisper_context* ctx, const float* audio, int n, bool streaming) {
    whisper_full_params p = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    p.print_progress = false;
    p.print_realtime = false;
    p.print_timestamps = false;
    p.translate = false;
    p.language = "ru";
    p.detect_language = false;
    p.no_timestamps = true;
    p.no_context = true;
    p.single_segment = streaming;
    p.n_threads = choose_threads();
    p.max_tokens = streaming ? 96 : 0;
    p.temperature = 0.0f;

    int rc = whisper_full(ctx, p, audio, n);
    if (rc != 0) return "";

    std::string result;
    for (int i = 0; i < whisper_full_n_segments(ctx); ++i) {
        const char* s = whisper_full_get_segment_text(ctx, i);
        if (s) result += s;
    }
    return result;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_blackbox_offline_LocalAiEngine_nativeTranscribeRealtimePcm(
        JNIEnv *env, jobject, jfloatArray pcm, jstring modelPath) {
    const char *path = env->GetStringUTFChars(modelPath, nullptr);
    std::string model(path);
    env->ReleaseStringUTFChars(modelPath, path);

    std::lock_guard<std::mutex> lock(g_mu);
    if (!g_ctx || g_path != model) {
        if (g_ctx) whisper_free(g_ctx);
        g_ctx = load_ctx(model);
        g_path = model;
    }
    if (!g_ctx) return env->NewStringUTF("");

    jsize n = env->GetArrayLength(pcm);
    if (n <= 0) return env->NewStringUTF("");
    jfloat* audio = env->GetFloatArrayElements(pcm, nullptr);
    std::string result = decode(g_ctx, audio, n, true);
    env->ReleaseFloatArrayElements(pcm, audio, JNI_ABORT);
    return env->NewStringUTF(result.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_blackbox_offline_LocalAiEngine_nativeTranscribePcm(
        JNIEnv *env, jobject, jfloatArray pcm, jstring modelPath) {
    const char *path = env->GetStringUTFChars(modelPath, nullptr);
    std::string model(path);
    env->ReleaseStringUTFChars(modelPath, path);

    std::lock_guard<std::mutex> lock(g_mu);
    if (!g_ctx || g_path != model) {
        if (g_ctx) whisper_free(g_ctx);
        g_ctx = load_ctx(model);
        g_path = model;
    }
    if (!g_ctx) return env->NewStringUTF("Ошибка: не удалось открыть Whisper-модель.");

    jsize n = env->GetArrayLength(pcm);
    jfloat *audio = env->GetFloatArrayElements(pcm, nullptr);
    std::string result = decode(g_ctx, audio, n, false);
    env->ReleaseFloatArrayElements(pcm, audio, JNI_ABORT);
    if (result.empty()) result = "[Речь не распознана]";
    return env->NewStringUTF(result.c_str());
}
